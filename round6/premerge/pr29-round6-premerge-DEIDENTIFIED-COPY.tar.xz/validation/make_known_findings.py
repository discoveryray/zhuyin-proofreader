"""Private evidence cross-check; not a PR gate input or historical resolution."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

C = "bcf93bf1e0f8a670d840694545f0c3749d96135c"
N = "0249c44636857739a262d10bd7f4e7ed1f713d1c"
ROOT = Path(__file__).resolve().parent
ROUND5 = ROOT.parents[2] / "round5" / "candidate-evidence" / "continuation-20260925T163424.632702Z-0249c4463685"
MAPPING = ROUND5 / "sources" / "02b244019eed6241-test-id-mapping.json"
FIFTH = ROUND5 / "continuation-state.json"
JUNIT = ROOT / "ci-pytest.xml"

ADDITIONAL = {
    "KF-04": (
        "test_submitted_expected_variables_release_on_main_before_save_worker_gc",
        "test_submit_cancel_and_owner_destroy_release_dialog_variables_and_photos",
        "test_lazy_peer_rotation_and_owner_destroy_release_images_and_only_owned_timers",
        "test_native_tcl_owner_destroy_cancels_only_owned_preview_callbacks",
        "test_owner_close_releases_preview_before_pending_save_worker_collects",
        "test_real_root_and_prior_dialogs_release_before_expected_or_actual_worker_gc",
        "test_sample_positions_are_individual_failed_sample_cannot_be_checked",
        "test_all_owned_resize_and_locate_callbacks_cancel_on_destruction",
    ),
    "RC-01": (
        "test_one_real_button_invoke_saves_without_dialog_and_duplicate_cannot_apply_next",
        "test_ctrl_enter_dialog_repetition_and_busy_action_save_only_one_item",
        "test_saved_event_survives_native_show_failure_and_reopens",
        "test_next_preview_failure_after_save_does_not_enable_fast_confirmation",
    ),
    "RC-02": (
        "test_sample_positions_are_individual_failed_sample_cannot_be_checked",
        "test_fixed_char_order_both_lanes_defer_stage_and_revisit",
        "test_difference_stage_removes_only_pending_comparison_and_navigates",
        "test_neutral_tone_front_and_back_are_equal",
    ),
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> str:
    return subprocess.run(["git", *args], check=True, capture_output=True, text=True).stdout.strip()


def main() -> None:
    mapping = json.loads(MAPPING.read_text(encoding="utf-8"))
    fifth = json.loads(FIFTH.read_text(encoding="utf-8"))
    prior_by_id = {f["id"]: f for f in fifth["continuation"]["known_findings"]}
    cases: dict[str, list[dict[str, str]]] = {}
    for case in ET.parse(JUNIT).iter("testcase"):
        identity = (case.get("classname") or "").removeprefix("tests.") + "." + (case.get("name") or "")
        outcome = "passed" if not any(case.find(kind) is not None for kind in ("failure", "error", "skipped")) else "not_passed"
        cases.setdefault(identity, []).append({"identity": identity, "outcome": outcome})
    changed = git("diff", "--name-only", f"{N}..{C}").splitlines()
    expected = {
        ".github/workflows/ci.yml", "docs/PR29_MERGE_CONTINUATION_CONTRACT.md",
        "docs/evidence/pr29_round6_user_adopted_contract.md", "scripts/pr29_review_gate.py",
        "tests/test_pr29_review_gate.py",
    }
    if set(changed) != expected:
        raise RuntimeError("N-to-C source set changed; cannot reuse product or benchmark conclusions")
    rows = []
    for mapped in mapping["rows"]:
        identifier = mapped["id"]
        prior = prior_by_id[identifier]
        required = []
        for item in mapped["required_retained_test_ids"]:
            test_id = item["test_id"]
            matches = cases.get(test_id, [])
            required.append({"test_id": test_id, "junit_count": len(matches),
                             "junit_outcomes": [match["outcome"] for match in matches]})
        extra = []
        for name in ADDITIONAL.get(identifier, ()):
            matches = [entry for identity, values in cases.items() if identity.endswith("." + name)
                       for entry in values]
            extra.append({"test_name": name, "junit_count": len(matches),
                          "junit_outcomes": [match["outcome"] for match in matches]})
        local_ok = all(item["junit_count"] == 1 and item["junit_outcomes"] == ["passed"]
                       for item in (*required, *extra))
        rows.append({
            "id": identifier,
            "title": mapped["title"],
            "original_source_ref": prior["source_ref"],
            "N_verification_ref": prior["verification_ref"],
            "C_required_junit": required,
            "C_additional_junit": extra,
            "C_local_test_ids_all_passed": local_ok,
            "status_for_coordinator": (
                "pending_pr_ci_even_if_local_tests_pass" if identifier == "KF-07" else
                "N_performance_reuse_impact_review_required" if identifier == "RC-04" else
                "C_local_evidence_available_coordinator_must_verify"
            ),
            "historical_resolution_claimed": False,
        })
    if len(rows) != 11 or not all(row["C_local_test_ids_all_passed"] for row in rows):
        raise RuntimeError("C JUnit is missing a retained or additional finding test")
    record = {
        "schema": "pr29-round6-known-findings-impact/1",
        "candidate": C,
        "source_mapping_ref": str(MAPPING),
        "source_mapping_sha256": sha(MAPPING),
        "retained_fifth_state_ref": str(FIFTH),
        "retained_fifth_state_sha256": sha(FIFTH),
        "C_junit_ref": str(JUNIT),
        "C_junit_sha256": sha(JUNIT),
        "N_to_C_changed_files": changed,
        "production_and_benchmark_harness_unchanged": True,
        "performance_source": "N D-versus-N same-fixture benchmark; C was not remeasured",
        "performance_impact_ref": str(ROOT / "performance-reuse-impact.txt"),
        "candidate_findings": rows,
        "remaining_known_finding_gap": "KF-07 requires the new C Windows 3.12/3.13 PR CI run/attempt/raw logs",
        "unknown_historical_report_contents_remain_unknown": True,
    }
    out = ROOT / "known-findings-C.json"
    out.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(out, sha(out))


if __name__ == "__main__":
    main()
