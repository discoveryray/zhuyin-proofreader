# PR #29 第五輪證據：去識別化副本 / DE-IDENTIFIED COPY

這不是原始 bytes。原始封存與逐檔原件→副本 SHA256 對照只在私人交接紀錄。INDEX.json 是本副本的逐檔 SHA256 與遮蔽替代文字清冊。

本副本保留正式 R1/R2 審查結論、固定 Git SHA、CI run/attempt、測試結果與 gate 決策。原始報告文字所述的原件 hash 不表示本副本具有相同 bytes；核對本副本請使用 INDEX.json。某些來源路徑的 SHA 前綴檔名已改為 source-NNN，且內部引用同步改寫。歷史缺件未補造，gate STOP（merge 未授權）仍保留。PR 維持 draft／未合併。
