# PR29 evidence publication selection（待 CI／R2 補齊）

此檔只說明截至本次選取時已有的原件；不宣稱完整交付或新 PASS。publication-selection.json 的 files 是 package_evidence.py 可讀的 relative-E 明確清單。原件未修改。

建議最少取回集合：固定 N 的 portable-reconstruction.zip、benchmark-replay-v5.zip、benchmark aggregate，以及最後含本 selection 加上 CI／R2／final gate 的一個 solid tar.xz。固定祖先 N1 的 checksum 另由 Git 取回。各 Git SHA256／blob／URL 和唯一省略的 aggregate source 還原路徑已放在 git_references。既有索引保留原 C 槽 path，閱讀時以 Archive evidence/ 對應 E；勿以新目錄重寫原記錄。

候選 index 的 aggregate source 被省略以避免重複 2.39 MB；先從指定 N Git object 讀出原始 bytes、核對 hash，再還原到 git_references.restore_to_relative_E 的新 evidence extraction 根目錄。這不更動受審 checkout。只有索引需要此一補還原 source；其餘選定 snapshot sources 都直接包含。

pre-review-validation-history.zip 不重複包入；其 38 records 的 76 份 raw record/log 與完整 manifest／摘要直接選取，全部七個已結束非零 validation 原件逐 byte 對照相同。N2 default-fd／sys 控制與 native owner 修正前後保持原始 SHA，沒有改稱 N3。

R1 全文／JSON、failed audit attempts／auditors／results；indexer quoted filename、array-pointer、active-boolean 三種外部工具原件、失敗 snapshot 和修復 provenance；有效 prepush gate 及普通 push／postpush 初始 PR／refs 原件均選取。有效 prepush action 原文是 PUSH_CANDIDATE，並非完整交付 gate。

待追加：CI run/attempt + all jobs/logs/artifacts、R2 全文與原始來源、最新 postpush/final gate、真正發佈與回讀紀錄。新增資料前保留本次 selection snapshot。先 append 選取檔案、核對當前 bytes，再由協調者執行 package_evidence.py；本任務不封裝或發佈。

建議 solid tar.xz：保留小型重複 source paths 有助原引用直接回查，solid 壓縮可消除多數重複。不要為縮包刪除失敗 raw record/log、審查原文或新增偽造 success metadata。可從 B/D/N Git objects 重建 patch，不重複包入大型 binary diff。
