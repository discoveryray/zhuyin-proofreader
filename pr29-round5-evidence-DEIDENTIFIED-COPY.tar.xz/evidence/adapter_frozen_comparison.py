from pathlib import Path
import ast, hashlib, json, subprocess, sys
root = Path(sys.argv[1])
base = "1593e7af65596d320b4427f1b15bb2bc0bdc949c"
develop = "502414b3b38e004a6d8d9cb693cf21b65148765a"
old_source = subprocess.check_output(["git", "show", base + ":scripts/pr_review_gate.py"], cwd=root).decode("utf-8")
new_source = (root / "scripts/pr29_review_gate.py").read_text(encoding="utf-8")
def functions(source):
    return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(source).body if isinstance(n, ast.FunctionDef)}
old, new = functions(old_source), functions(new_source)
result = {"kind": "implementation_self_check_not_independent_review", "baseline": base, "develop": develop,
          "adapter_lf_text_sha256": hashlib.sha256(new_source.encode()).hexdigest(),
          "adapter_raw_sha256": hashlib.sha256((root / "scripts/pr29_review_gate.py").read_bytes()).hexdigest(),
          "unchanged_helpers": [name for name in old if name in new and old[name] == new[name]],
          "changed_helpers": [name for name in old if name in new and old[name] != new[name]],
          "removed_paths": [name for name in old if name not in new], "unchanged_develop_files": {}}
for name in ("scripts/pr_review_gate.py", "AGENTS.md", "docs/PR_REVIEW_GATE.md", "global_exact_glyph_library.py"):
    expected = subprocess.check_output(["git", "show", develop + ":" + name], cwd=root).decode("utf-8").replace("\r\n", "\n")
    actual = (root / name).read_text(encoding="utf-8").replace("\r\n", "\n")
    result["unchanged_develop_files"][name] = actual == expected
print(json.dumps(result, indent=2))
