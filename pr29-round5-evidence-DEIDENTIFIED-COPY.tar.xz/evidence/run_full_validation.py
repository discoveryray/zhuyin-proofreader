"""Candidate-bound Windows acceptance driver; evidence only, never edits source."""
import argparse,json,pathlib,subprocess,sys,datetime
p=argparse.ArgumentParser();p.add_argument('--head',required=True);a=p.parse_args()
E=pathlib.Path(__file__).resolve().parent
W=pathlib.Path(r'<LOCAL_REPOSITORY>\tmp\pr29-round5-worktree')
P=sys.executable
B='1593e7af65596d320b4427f1b15bb2bc0bdc949c';D='502414b3b38e004a6d8d9cb693cf21b65148765a'
def git(*args):return subprocess.check_output(['git',*args],cwd=W,text=True,encoding='utf-8').strip()
assert git('rev-parse','HEAD')==a.head
assert not git('status','--porcelain=v1')
steps=[
('candidate-develop-oracle',[P,'-X','utf8',str(E/'develop_oracle_probe.py')]),
('candidate-runtime',[P,'-X','utf8','-m','pytest','tests/test_runtime_asset_manifest_integrity_v562.py','-q']),
('candidate-inventory',[P,'-X','utf8','scripts/test_entrypoint_audit.py','collect',str(E/'candidate-test-inventory.json')]),
('candidate-unittest',[P,'-X','utf8','-m','unittest','discover','-s','tests','-p','test_*.py']),
('candidate-pytest',[P,'-X','utf8','-m','pytest','tests/','-q','-rs','--junitxml='+str(E/'candidate-pytest.xml'),'--basetemp='+str(W/'tmp/candidate-pytest-tmp'),'-o','cache_dir='+str(W/'tmp/candidate-pytest-cache')]),
('candidate-gui-audit',[P,'-X','utf8','scripts/test_entrypoint_audit.py','verify-gui',str(E/'candidate-test-inventory.json'),'--junit',str(E/'candidate-pytest.xml')]),
('candidate-compile',[P,'-X','utf8','-m','compileall','-q','-x',r'(^|[\\/])(\.venv|tmp)([\\/]|$)','.']),
('candidate-diff-baseline',['git','diff','--check',B+'..'+a.head]),
('candidate-diff-develop',['git','diff','--check',D+'..'+a.head]),
('candidate-status',['git','status','--porcelain=v1']),
]
results=[]
for label,cmd in steps:
    assert git('rev-parse','HEAD')==a.head
    print('START '+label,flush=True)
    r=subprocess.run([P,'-X','utf8',str(E/'run_validation.py'),'--cwd',str(W),'--label',label,'--',*cmd])
    record=json.loads((E/'validation'/label/'record.json').read_text(encoding='utf-8'))
    results.append({'label':label,'exit_code':r.returncode,'source_bytes_unchanged':record['source_bytes_unchanged']})
    print('END '+label+' '+str(r.returncode),flush=True)
(E/'candidate-acceptance-summary.json').write_text(json.dumps({'head':a.head,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results,'final_head':git('rev-parse','HEAD'),'final_status':git('status','--porcelain=v1')},indent=2),encoding='utf-8')
sys.exit(0 if all(x['exit_code']==0 and x['source_bytes_unchanged'] for x in results) else 1)
