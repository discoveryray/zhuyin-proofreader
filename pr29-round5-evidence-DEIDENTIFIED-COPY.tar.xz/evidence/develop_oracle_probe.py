"""Independent D Git-object oracle; temporary synthetic fixtures only."""
from __future__ import annotations
import ast, copy, hashlib, json, pathlib, subprocess, sys
from unittest.mock import patch
repo=pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0,str(repo))
import standalone_proofread as sp
import actual_review as ar
from tests.test_review_save_service import ReviewSaveServiceTests
D="502414b3b38e004a6d8d9cb693cf21b65148765a"
raw=subprocess.check_output(["git","show",D+":standalone_proofread.py"],cwd=repo)
text=raw.decode("utf-8-sig"); module=ast.parse(text)
functions={n.name:n for n in module.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
roots={"materialize_ledger","manual_actual_staging_summary"}
selected=set(roots); pending=list(roots)
while pending:
    name=pending.pop()
    deps={n.id for n in ast.walk(functions[name]) if isinstance(n,ast.Name)} & functions.keys()
    for dep in deps-selected: selected.add(dep);pending.append(dep)
namespace=dict(vars(sp))
fragment=ast.Module(body=[ast.ImportFrom(module="__future__",names=[ast.alias(name="annotations")],level=0)]
 +[n for n in module.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in selected],type_ignores=[])
exec(compile(ast.fix_missing_locations(fragment),"<D-frozen-oracle>","exec"),namespace)
for name in ("actual_review.py","occurrence_ledger.py"):
    expected=subprocess.check_output(["git","show",D+":"+name],cwd=repo)
    actual=(repo/name).read_bytes()
    if expected.replace(b"\r\n",b"\n")!=actual.replace(b"\r\n",b"\n"):
        raise AssertionError("oracle imported dependency differs from D: "+name)
case_count=0; summaries=[]
ReviewSaveServiceTests.setUpClass()
try:
 for scenario in ("absent","valid","invalid"):
    tc=ReviewSaveServiceTests();tc.setUp()
    try:
        if scenario!="absent":
            sp.stage_manual_actual_correction(tc.output,tc.row()["review_id"],"ㄎㄢ")
        if scenario=="invalid":
            path=ar.manual_actual_staging_path(sp.project_actual_evidence_root(tc.output))
            doc=sp.json_load_strict(path);doc["staged_groups"][0]["group_snapshot"]="0"*64
            sp.json_save(path,doc)
        original=[sp.actual_confirmation_snapshot(x) for x in tc.manifest["records"]]
        for i in range(12):
            n=i%3
            event=None if i%4==3 else tc.event(n,reading="ㄎㄢ" if i%2 else "ㄎㄢˋ")
            result=tc.save(event,n)
            expected=namespace["materialize_ledger"](tc.manifest,result.db)
            assert result.ledger==expected,(scenario,i,"ledger")
            assert [sp.actual_confirmation_snapshot(x) for x in result.ledger]==original
            summary=namespace["manual_actual_staging_summary"](tc.output,ledger=expected)
            assert result.staging_summary==summary,(scenario,i,"staging",result.staging_summary,summary)
            assert result.db==sp.json_load_strict(tc.output/"人工判定資料庫.json")
            if scenario=="invalid":
                assert summary.get("staging_error") and summary["staged_checked_occurrence_ids"]==[]
            if n==2 and event is not None:
                assert result.resolved_entry["actual_status"]=="UNRESOLVED"
                assert result.resolved_entry["expected_status"]=="RESOLVED"
            case_count+=1
        summaries.append({"scenario":scenario,"operations":12,"matched":True})
    finally: tc.doCleanups()
finally: ReviewSaveServiceTests.tearDownClass()
print(json.dumps({"oracle_commit":D,"oracle_source_sha256":hashlib.sha256(raw).hexdigest(),
 "frozen_function_closure":sorted(selected),"independently_compiled_git_objects":True,
 "operations":case_count,"scenarios":summaries,"fixture":"temporary synthetic; no real-book claim"},ensure_ascii=False,indent=2))
