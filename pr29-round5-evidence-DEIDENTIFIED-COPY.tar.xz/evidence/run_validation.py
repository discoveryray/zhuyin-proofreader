"""Run one authorized validation in an isolated process and retain raw evidence."""
import argparse, datetime, hashlib, json, os, pathlib, subprocess, sys, time
p=argparse.ArgumentParser()
p.add_argument("--cwd",required=True);p.add_argument("--label",required=True)
p.add_argument("command",nargs=argparse.REMAINDER)
a=p.parse_args(); command=a.command[1:] if a.command[:1]==["--"] else a.command
if not command: p.error("command required")
root=pathlib.Path(__file__).resolve().parent
out=root/"validation";out.mkdir(exist_ok=True)
isolation=out/a.label;isolation.mkdir(exist_ok=False)
env=os.environ.copy()
for name,part in [("LOCALAPPDATA","localappdata"),("TEMP","temp"),("TMP","temp")]:
    target=isolation/part;target.mkdir(exist_ok=True);env[name]=str(target)
env.update(PYTHONUTF8="1",PYTHONIOENCODING="utf-8",
 TCL_LIBRARY=r"<WINDOWS_USER_HOME>\AppData\Local\Programs\Python\Python313\tcl\tcl8.6",
 TK_LIBRARY=r"<WINDOWS_USER_HOME>\AppData\Local\Programs\Python\Python313\tcl\tk8.6")
def git(*args):
    r=subprocess.run(["git",*args],cwd=a.cwd,capture_output=True,text=True,encoding="utf-8",errors="replace")
    return {"exit":r.returncode,"stdout":r.stdout,"stderr":r.stderr}
def witness():
    files=(git("ls-files","-z")["stdout"] + git("ls-files","--others","--exclude-standard","-z")["stdout"]).split("\0")
    hashes={}
    for f in sorted(set(files)):
        path=pathlib.Path(a.cwd)/f
        if f and path.is_file(): hashes[f]=hashlib.sha256(path.read_bytes()).hexdigest()
    return {"head":git("rev-parse","HEAD"),"status":git("status","--porcelain=v1"),"files_sha256":hashes}
record={"label":a.label,"command":command,"cwd":a.cwd,"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "environment":{k:env[k] for k in ["LOCALAPPDATA","TEMP","TMP","PYTHONUTF8","PYTHONIOENCODING","TCL_LIBRARY","TK_LIBRARY"]},
        "before":witness()}
meta=isolation/"record.json"
meta.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
started=time.perf_counter()
with (isolation/"raw.log").open("wb") as log:
    process=subprocess.run(command,cwd=a.cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=process.returncode,elapsed_seconds=time.perf_counter()-started,
              ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),after=witness())
record["source_bytes_unchanged"]=record["before"]["files_sha256"]==record["after"]["files_sha256"]
record["log_sha256"]=hashlib.sha256((isolation/"raw.log").read_bytes()).hexdigest()
meta.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps({k:record[k] for k in ["label","exit_code","elapsed_seconds","source_bytes_unchanged"]}))
print(str(meta))
sys.exit(process.returncode)
