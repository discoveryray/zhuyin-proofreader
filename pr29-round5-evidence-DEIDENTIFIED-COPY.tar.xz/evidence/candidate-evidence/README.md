# PR29 候選證據索引工具（僅準備，尚無候選結果）

只寫本 candidate-evidence/；不修改 reconstruction、production/tests/docs/workflow，不執行產品測試、不發 REVIEW verdict 或 gate decision。

test-id-mapping.json 由原重建矩陣的固定 H 測試原文 AST 建立 11 個 KF/RC 項目、45 個 retained test references。這是身份定位，不表示新版本已執行；新 N 新增的 native destroy/owner/timer cases 另從 exact N AST 列出，仍須人工判斷覆蓋，不靠名稱猜成通過。

待協調者提供固定 N 及已結束驗證後執行（參數路徑以實際 record 為準）：

python -X utf8 index_candidate_evidence.py --repo <exact-clean-N-worktree> --candidate <full-N-SHA> --junit <candidate-pytest.xml> --inventory <candidate-test-inventory.json> --record pytest=<candidate-pytest-record.json> --record unittest=<candidate-unittest-record.json> --record inventory=<candidate-inventory-record.json> --record gui-verifier=<candidate-gui-verifier-record.json> --record runtime=<candidate-runtime-record.json> --record compile=<candidate-compile-record.json> --record diff=<candidate-diff-record.json> --record oracle=<validation/candidate-develop-oracle/record.json> --benchmark-index <benchmark/paired-final-v5/run-index.json> --benchmark-aggregate <final-active-batch-aggregate.json>

必要檢查：

- 候選 checkout HEAD 精確等於 N 且 clean。沒有 N、不清楚候選或還在寫入時不能索引成候選證據。
- record 的 before/after HEAD、status、完整 tracked source raw hashes、source_bytes_unchanged、結束時間、exit code、raw.log hash。舊 H/dirty 診斷可保留但不算 exact-N 執行。
- pytest command 的 --junitxml 與 inventory collect 目標必須綁定所選檔案；inventory/JUnit 身份逐一相符，重複、缺失、skip/error/failure 全列。
- testcase success 只表示該 ID 在綁定版本執行成功，不宣稱 requirement 語意完整、歷史 finding 解除、審查或 gate 通過。
- 工具不選「最新檔」或自動 fallback。benchmark-index 必須明確指定 final active batch；本輪預計 paired-final-v5。aggregate 中 previous_source_measurements/v4 不能替代 active batch。
- benchmark 原結果／logs 及 hash、source manifest 對 N bytes、fixture/env、cold/steady metrics 逐筆保留。D 的來源適用性、pair equality、median/P95 重算、卡頓與記憶體退化判讀仍需實際查核，工具不自動認定效能達標。
- candidate-develop-oracle 要在 N 固定後由 root 執行；先前 develop-oracle-01 的 H/dirty record 保留為前置診斷，不冒稱 N。
- 每次收集產生唯一 timestamp/N 子目錄，保存所選 raw inputs、index.json/md；不覆寫先前 snapshot。
- 本機索引不包含完整雙版本 CI 審查；第二輪必須另核實 run/attempt/tested SHA/parents/tree/jobs/logs。
- 七份缺失早期報告維持 unknown；無任何舊 resolution 或新 REVIEW verdict。

目前狀態：工具與模板 ready；candidate_head=null；未執行收集，等待 N 與最終完整驗證。
