"""Construct evidence-only PR29 gate input; never fabricate prerequisite truth.

Reads only explicitly supplied sources plus Git objects/status of supplied N.
Writes timestamped append-only output under this script's directory.
Does not run gate, tests, Git writes, network calls, or PR operations.
"""
from __future__ import annotations
import argparse,ast,copy
from datetime import datetime,timezone
import hashlib,json,re,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parent
B="1593e7af65596d320b4427f1b15bb2bc0bdc949c"
H="a38bdf1c84889c52e7281a0c23c9458e3762afa8"
D="502414b3b38e004a6d8d9cb693cf21b65148765a"
CHAIN=["e53f44d2da29b46dfe0bd0f2c06af9919808b99f","89e0297bd6e5b9b08d077b2216029fb6224976fc",
       "bb4c136fbc49c706fecfd48d1dacf81b4d97584e","bd6b4789a646f8bed075c256447f54922a5c4f90",H]
AUTH_SHA="53790b7433d64197d046dbaad0e61c6ebb0ad5775a1d5ad3ec36e142371a0b26"
CHECK_ROLES={"unittest":["unittest"],"pytest":["pytest"],"gui":["pytest","inventory","gui-verifier"],
             "runtime":["runtime"],"compile":["compile"],"diff":["diff"],"performance":[]}
REVIEW_FIELDS=set("round reviewer baseline base head scope verdict independent full_diff_reviewed findings report_ref ci blocker_kind supersedes_report_ref resolution_evidence_ref".split())

def sha(raw): return hashlib.sha256(raw).hexdigest()
def unique(pairs):
    result={}
    for k,v in pairs:
        if k in result: raise ValueError("duplicate JSON key: "+k)
        result[k]=v
    return result
def loads(raw): return json.loads(raw.decode("utf-8-sig"),object_pairs_hook=unique)
def git(repo,*args):
    p=subprocess.run(["git","-C",str(repo),*args],capture_output=True)
    return dict(args=list(args),exit_code=p.returncode,stdout=p.stdout.decode("utf-8",errors="replace"),stderr=p.stderr.decode("utf-8",errors="replace"))
def pointer(data,path):
    if not path: return data
    if not path.startswith("/"): raise ValueError("JSON pointer must start with /")
    for part in path.split("/")[1:]:
        part=part.replace("~1","/").replace("~0","~")
        data=data[int(part)] if isinstance(data,list) else data[part]
    return data

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest",type=Path)
    args=parser.parse_args()
    config=loads(args.manifest.read_bytes())
    candidate=config.get("candidate")
    if not isinstance(candidate,str) or not re.fullmatch(r"[0-9a-f]{40}",candidate): parser.error("explicit full candidate N required")
    repo=Path(config["repo"]).resolve()
    now=datetime.now(timezone.utc)
    out=ROOT/("continuation-"+now.strftime("%Y%m%dT%H%M%S.%fZ")+"-"+candidate[:12])
    out.mkdir(exist_ok=False)
    (out/"sources").mkdir()
    unavailable=[]; notes=[]; provenance={}; values={}
    def problem(name,detail):
        unavailable.append(dict(prerequisite=name,detail=detail))
    def write(name,value):
        (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
    def source_ref(key):
        src=provenance.get(key)
        return ("sources/"+src["saved_name"]) if src else "construction-provenance.json#unavailable:"+key
    for key,desc in config.get("sources",{}).items():
        if not isinstance(desc,dict) or not desc.get("path") or not re.fullmatch(r"[0-9a-f]{64}",desc.get("sha256","")):
            problem(key,"source requires explicit path and expected SHA256");continue
        path=Path(desc["path"])
        if not path.is_absolute(): path=args.manifest.parent/path
        if not path.is_file(): problem(key,"supplied source not available");continue
        raw=path.read_bytes()
        actual=sha(raw)
        if actual!=desc["sha256"]: problem(key,"SHA256 mismatch; source rejected");continue
        saved=actual[:16]+"-"+path.name
        (out/"sources"/saved).write_bytes(raw)
        provenance[key]=dict(original_path=str(path.resolve()),sha256=actual,saved_name=saved,
                             json_pointer=desc.get("json_pointer"),source_ref=desc.get("source_ref"),
                             captured_at_utc=desc.get("captured_at_utc"),read_at_utc=now.isoformat(),
                             authenticity_verified=False)
        try:
            values[key]=pointer(loads(raw),desc.get("json_pointer","")) if desc.get("format","json")=="json" else raw.decode("utf-8-sig")
        except Exception as exc: problem(key,"source parse/pointer error: "+str(exc))
    # Record manifest and builder raw bytes, explicitly labelled reconstruction inputs.
    for key,path in [("construction_manifest",args.manifest),("builder_source",Path(__file__))]:
        raw=path.read_bytes();saved=sha(raw)[:16]+"-"+path.name
        (out/"sources"/saved).write_bytes(raw)
        provenance[key]=dict(original_path=str(path.resolve()),sha256=sha(raw),saved_name=saved,read_at_utc=now.isoformat(),
                             source_ref="current evidence construction input",authenticity_verified=False)
    def required(key,kind=dict):
        value=values.get(key)
        if not isinstance(value,kind):
            problem(key,"missing or incorrect type");return {} if kind is dict else None
        return value
    def supplied_refs(keys,label):
        if not isinstance(keys,list) or not keys:
            problem(label,"nonempty explicit verification source keys required");return False
        if any(key not in provenance for key in keys):
            problem(label,"verification references missing/rejected source");return False
        return True
    # No fixture values. Exact source is retained as schema guidance, never executed.
    gate_cmd=git(repo,"show",candidate+":scripts/pr29_review_gate.py")
    gate_text=gate_cmd["stdout"]
    gate_constants={}
    if gate_cmd["exit_code"]==0:
        for node in ast.parse(gate_text).body:
            if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
                try: gate_constants[node.targets[0].id]=ast.literal_eval(node.value)
                except (ValueError,TypeError): pass
    (out/"gate-schema-source.py").write_text(gate_text,encoding="utf-8",newline="\n")
    if gate_constants.get("SCHEMA")!="zhuyin-pr29-continuation/1" or gate_constants.get("AUTHORIZATION_SHA256")!=AUTH_SHA:
        problem("gate_schema","unsupported candidate schema or adopted source hash; do not guess/migrate")
    actual_head=git(repo,"rev-parse","HEAD")
    tree=git(repo,"rev-parse",candidate+"^{tree}")
    status=git(repo,"status","--porcelain=v1")
    contains_H=git(repo,"merge-base","--is-ancestor",H,candidate)
    contains_D=git(repo,"merge-base","--is-ancestor",D,candidate)
    log=git(repo,"log","--format=%H %P %s",H+".."+candidate)
    scope=dict(read_at_utc=now.isoformat(),candidate=candidate,actual_head=actual_head,tree=tree,status=status,
               contains_H=contains_H,contains_D=contains_D,commits_in_H_to_N=log,gate_source=gate_cmd,
               note="Git facts observed now; no role/review verdict inferred.")
    write("observed-git-scope.json",scope)
    clean=actual_head["exit_code"]==0 and actual_head["stdout"].strip()==candidate and status["exit_code"]==0 and status["stdout"]==""
    if not clean: problem("current","supplied checkout is not exact clean N")
    if contains_H["exit_code"]!=0 or contains_D["exit_code"]!=0: problem("integration","H/D ancestry not proven")
    authority=values.get("authorization")
    if provenance.get("authorization",{}).get("sha256")!=AUTH_SHA:
        problem("authorization","exact adopted user contract bytes unavailable")
    actors=required("actors")
    implementers=actors.get("implementers",[])
    if not implementers or not all(isinstance(x,str) and x.strip() for x in implementers):
        problem("implementers","explicit actual code-writing actors are required; no roles invented")
    if not supplied_refs(actors.get("source_keys"),"actor_sources"): implementers=[]
    active=actors.get("authorization_active")
    if type(active) is not bool: problem("authorization_active","must explicitly report current active/revoked status")
    handoffs=actors.get("handoffs",[])
    if not isinstance(handoffs,list): problem("handoffs","must be actual list");handoffs=[]
    unavailable_rounds=actors.get("unavailable_review_rounds",[])
    if not isinstance(unavailable_rounds,list): problem("unavailable_review_rounds","must be explicit list");unavailable_rounds=[]
    history=required("history")
    mapping=required("mapping")
    index=required("candidate_index")
    valid_index=index.get("candidate")==candidate and index.get("source_checkout_head")==candidate and index.get("source_checkout_status")==""
    index_source=provenance.get("candidate_index")
    if valid_index and index_source:
        origin=Path(index_source["original_path"]).parent
        for item in index.get("sources",[]):
            relative=item.get("file","")
            f=(origin/relative).resolve()
            if not f.is_relative_to(origin.resolve()) or not f.is_file() or sha(f.read_bytes())!=item.get("sha256"):
                problem("candidate_index","indexed raw source absent/changed: "+relative);valid_index=False
        if not index.get("sources"): problem("candidate_index","empty underlying source inventory");valid_index=False
    if not valid_index: problem("candidate_index","exact N index and underlying raw hashes not established")
    assessments=required("assessments")
    if assessments.get("candidate")!=candidate: problem("assessments","not explicitly for N");assessments={}
    local=assessments.get("local_validation",{})
    platform=local.get("platform");python_version=local.get("python_version")
    runtime_proven=supplied_refs(local.get("runtime_source_keys"),"local_runtime_sources")
    if platform!="Windows" or python_version!="3.13.0" or not runtime_proven:
        problem("runtime","exact Windows Python 3.13.0 evidence missing; no default runtime injected")
    roles={r.get("role") for r in index.get("record_facts",[]) if r.get("exact_N_execution_evidence") is True}
    checks={}
    for name,need_roles in CHECK_ROLES.items():
        item=local.get("checks",{}).get(name,{})
        result=item.get("status","missing")
        verified_sources=supplied_refs(item.get("source_keys"),"local_check:"+name) if item else False
        if result not in {"success","failure","missing"}: problem(name,"unknown status");result="missing"
        if result=="success":
            if not valid_index or not set(need_roles).issubset(roles) or not verified_sources:
                problem(name,"success claim lacks exact-N record and explicit source evidence");result="missing"
            if name in {"pytest","gui"} and index.get("inventory_and_junit",{}).get("failing_skipped_or_duplicate"):
                problem(name,"selected index contains failed/skipped/duplicate test identities");result="failure"
            if name=="performance" and not item.get("active_batch_source_key"):
                problem(name,"explicit final active batch source key missing");result="missing"
            elif name=="performance" and item.get("active_batch_source_key") not in provenance:
                problem(name,"active batch source missing/rejected");result="missing"
            elif name=="performance":
                requested_batch=config.get("active_benchmark_batch")
                chosen=provenance[item["active_batch_source_key"]]["original_path"]
                active_benchmark_source=index.get("benchmark",{}).get("active_source",{}).get("original_path")
                if not requested_batch or requested_batch not in Path(chosen).parts or not active_benchmark_source or Path(chosen).resolve()!=Path(active_benchmark_source).resolve():
                    problem(name,"active batch does not match explicit final batch and selected candidate index");result="missing"
        checks[name]=dict(status=result,evidence_ref=source_ref("assessments")+"#/local_validation/checks/"+name)
    matrix=[]
    def finding_array_ref(key,array_name,fid):
        # Resolve the actual source array position, independently of output sorting.
        data=values.get(key,{})
        rows=data.get(array_name,[]) if isinstance(data,dict) else []
        matches=[i for i,row in enumerate(rows) if isinstance(row,dict) and row.get("id")==fid] if isinstance(rows,list) else []
        src=provenance.get(key)
        if len(matches)!=1 or src is None:
            problem(key,"finding pointer requires one actual source array row for "+fid)
            return None
        fragment=(src.get("json_pointer") or "")+"/"+array_name+"/"+str(matches[0])
        original=loads((out/"sources"/src["saved_name"]).read_bytes())
        resolved=pointer(original,fragment)
        if not isinstance(resolved,dict) or resolved.get("id")!=fid:
            raise AssertionError("finding fragment did not resolve to matching ID: "+fragment+" -> "+fid)
        return source_ref(key)+"#"+fragment
    expected_ids={f"KF-{x:02d}" for x in range(1,8)}|{f"RC-{x:02d}" for x in range(1,5)}
    input_rows=mapping.get("rows",[])
    mapped={r.get("id"):r for r in input_rows}
    assessment_rows={r.get("id"):r for r in assessments.get("known_findings",[])}
    if set(mapped)!=expected_ids: problem("mapping","all eleven known KF/RC rows required")
    for fid in sorted(expected_ids):
        original=mapped.get(fid,{})
        check=assessment_rows.get(fid,{})
        fact=next((r for r in index.get("rows",[]) if r.get("id")==fid),{})
        state=check.get("status","unknown")
        if state not in {"verified_on_candidate","open","unknown"}: state="unknown";problem(fid,"unknown verification status")
        keys_ok=supplied_refs(check.get("source_keys"),fid) if check else False
        if state=="verified_on_candidate" and (not valid_index or not keys_ok or not check.get("analysis")):
            state="unknown";problem(fid,"requires explicit N analysis and valid source refs; test name alone is not coverage")
        mapping_ref=finding_array_ref("mapping","rows",fid)
        verification_ref=finding_array_ref("assessments","known_findings",fid) if state=="verified_on_candidate" else None
        if state=="verified_on_candidate" and verification_ref is None: state="unknown"
        matrix.append(dict(id=fid,source_ref=mapping_ref,
                           description=original.get("required_behavior",fid+" mapping unavailable"),
                           status=state,verification_ref=verification_ref,
                           actual_candidate_test_facts=fact,verification_source_keys=check.get("source_keys",[]),
                           candidate_analysis=check.get("analysis"),historical_resolution="unknown unchanged; no retroactive old finding closure"))
    missing_originals=[r.get("file") for r in history.get("known_missing_originals",[]) if isinstance(r.get("file"),str)]
    fifth=dict(schema="pr29-fifth-history-append/v1",created_at_utc=now.isoformat(),record_kind="APPENDED_CURRENT_CANDIDATE_EVIDENCE",
               task="review-confirm-responsive",baseline=B,from_head=H,candidate_head=candidate,correction_number=5,
               previous_history_ref=source_ref("history"),previous_history_rewritten=False,
               previous_four_count=history.get("known_completed_corrective_count"),
               stage="candidate_evidence_recorded_not_review_verdict" if valid_index else "candidate_evidence_unavailable",
               valid_exact_candidate_index=valid_index,formal_freeze=actors.get("candidate_freeze"),
               git_scope_ref="observed-git-scope.json",known_originals_missing=missing_originals,
               historical_authorizations_ratified=False,historical_resolutions_created=False,
               note="N1/N2/... ordinary pre-review commits are retained in Git; this is one fifth corrective cycle, not reset history.")
    if history.get("known_completed_corrective_count")!=4: problem("history","four known completed rounds not confirmed")
    write("fifth-history-append.json",fifth)
    write("known-findings-candidate-matrix.json",dict(candidate=candidate,created_at_utc=now.isoformat(),rows=matrix,
          historical_unknowns="unknown preserved",new_review_verdict=None))
    reviews=[]
    for item in config.get("reviews",[]):
        key=item.get("record_source");text_key=item.get("full_report_source")
        record=values.get(key);full=values.get(text_key)
        if not isinstance(record,dict) or not isinstance(full,str):
            problem("review","explicit original JSON and full report required; absent report not manufactured");continue
        if set(record)!=REVIEW_FIELDS: problem("review:"+str(key),"record does not match actual v2 closed review fields");continue
        if (record.get("baseline"),record.get("base"),record.get("head"))!=(B,D,candidate):
            problem("review:"+str(key),"wrong candidate scope; rejected");continue
        if record.get("report_ref","") not in full or candidate not in full:
            problem("review:"+str(key),"full report does not link exact report_ref and N; rejected");continue
        reviews.append(copy.deepcopy(record))
    prraw=required("pr_api")
    prchecks=assessments.get("pr_findings",{})
    checked=prchecks.get("checked")
    blockers=prchecks.get("new_blockers")
    if type(checked) is not bool or not isinstance(blockers,list) or not supplied_refs(prchecks.get("source_keys"),"fresh_pr_findings"):
        checked=False;blockers=[];problem("pr_findings","latest PR findings unavailable; empty list does not mean cleared")
    mergeable=prraw.get("mergeable")
    if type(mergeable) is not bool: problem("pr_mergeable","API null/absent preserved as unknown, not coerced")
    protection=assessments.get("protection",{})
    protected=protection.get("satisfied")
    if type(protected) is not bool or not supplied_refs(protection.get("source_keys"),"protection"):
        protected=None;problem("protection","truth unavailable; no false success")
    prstate="merged" if prraw.get("merged") is True else prraw.get("state")
    pr=dict(number=prraw.get("number"),url=prraw.get("html_url"),state=prstate,
            base_branch=prraw.get("base",{}).get("ref"),head_branch=prraw.get("head",{}).get("ref"),
            base_sha=prraw.get("base",{}).get("sha"),head_sha=prraw.get("head",{}).get("sha"),
            mergeable=mergeable,protection_satisfied=protected,findings_checked=checked,
            new_blockers=blockers,evidence_ref=source_ref("pr_api"),draft=prraw.get("draft"))
    refs_text=values.get("direct_refs")
    refs={}
    if isinstance(refs_text,str):
        for line in refs_text.splitlines():
            match=re.fullmatch(r"([0-9a-f]{40})\s+(refs/heads/\S+)",line.strip())
            if match: refs[match.group(2)]=match.group(1)
    remote=dict(base=refs.get("refs/heads/develop"),head=refs.get("refs/heads/codex/review-confirm-responsive"),
                evidence_ref=source_ref("direct_refs"))
    if remote["base"]!=D or remote["head"] not in {H,candidate}: problem("direct_refs","missing or unexpected direct branch SHA; API not substituted")
    for key in ("pr_api","direct_refs"):
        captured=provenance.get(key,{}).get("captured_at_utc")
        try:
            moment=datetime.fromisoformat(captured.replace("Z","+00:00"))
            age=(now-moment).total_seconds()
            if age<0 or age>300: problem(key,"supplied capture older than 300 seconds or future time; recheck before effects")
        except (AttributeError,TypeError,ValueError): problem(key,"actual source capture time unavailable")
    ci=None
    ci_conf=config.get("ci")
    if ci_conf:
        ci=values.get(ci_conf.get("normalized_source"))
        if not isinstance(ci,dict) or not supplied_refs(ci_conf.get("raw_source_keys"),"ci_original_sources"):
            ci=None;problem("ci","normalized CI without preserved raw source proof is unavailable")
        elif ci.get("head_sha")!=candidate:
            ci=None;problem("ci","old-head CI rejected")
        elif remote["head"]==H:
            ci=None;problem("ci","unpublished candidate cannot use old PR CI")
    state=dict(schema=gate_constants.get("SCHEMA"),task=dict(id="review-confirm-responsive",repository="discoveryray/zhuyin-proofreader",
                   baseline=B,base_branch="develop",head_branch="codex/review-confirm-responsive"),
               authorization=dict(task_id="review-confirm-responsive",active=active,
                   operations=["implement","delegate","test","commit","push","pr"],
                   source_ref="pr29-round5/user-adopted-contract",source_sha256=provenance.get("authorization",{}).get("sha256")),
               current=dict(base=D,head=candidate,tree=tree["stdout"].strip() if tree["exit_code"]==0 else None,
                            working_tree_clean=clean,evidence_ref="observed-git-scope.json"),
               implementers=implementers,corrections=[dict(number=i+1,from_head=start,to_head=end,
                   evidence_ref="fifth-history-append.json" if i==4 else source_ref("history")+"#/initial_and_four_corrective_commits/"+str(i+1))
                   for i,(start,end) in enumerate(zip(CHAIN,[*CHAIN[1:],candidate]))],
               reviews=reviews,unavailable_review_rounds=unavailable_rounds,pr=pr,pr_ci=ci,handoffs=handoffs,
               continuation=dict(created_at=now.isoformat(),reconstructed=True,history_ref=source_ref("history"),
                   missing_originals=missing_originals,known_findings=[{k:r[k] for k in ("id","source_ref","description","status","verification_ref")} for r in matrix],
                   finding_inventory_ref=source_ref("mapping"),original_stop_ref=source_ref("history")+"#/historical_stop",
                   candidate_head=candidate,integration_ref="observed-git-scope.json",contains_start=contains_H["exit_code"]==0,contains_develop=contains_D["exit_code"]==0),
               remote=remote,local_validation=dict(head=candidate,platform=platform,python_version=python_version,
                   evidence_ref=source_ref("candidate_index"),checks=checks))
    # Incomplete draft deliberately keeps unavailable values, not schema-friendly fake booleans or roles.
    write("continuation-state.draft.json" if unavailable else "continuation-state.json",state)
    write("construction-provenance.json",dict(created_at_utc=now.isoformat(),actor=config.get("executing_actor"),
            tool_author_agent="/root/reconstruct_evidence",tool_role="evidence-only; not formal reviewer",
            candidate=candidate,source_files=provenance,unavailable_prerequisites=unavailable,
            missing_review_rounds=sorted({1,2}-{r["round"] for r in reviews}),
            historical_unknowns_unchanged=True,gate_invoked=False,gate_decision=None,authenticity_verified=False,
            usage="Complete gaps with raw facts, then run the candidate adapter independently; builder output grants no permission.",
            status="unavailable_do_not_use_for_side_effects" if unavailable else "constructed_unvalidated_no_gate_decision"))
    rows=["# PR29 第五輪候選追加紀錄（不是審查結論）","",f"Candidate: {candidate}","",
          f"Known prior count: {history.get('known_completed_corrective_count')}; fifth cycle remains one cycle.",
          f"Candidate index binding: {valid_index}.",
          "歷史未知不變；原 STOP 引用保存全文支持，未偽造原 gate input/decision。","",
          "|KF/RC|當前候選明示評估|","|---|---|"]
    rows += [f"|{r['id']}|{r['status']}|" for r in matrix]
    rows += ["","Missing/unsupported prerequisites:"]+[f"- {r['prerequisite']}: {r['detail']}" for r in unavailable]
    rows += ["","No review verdict or gate decision was generated. No commit/push/PR/merge action occurred.",""]
    (out/"append-summary.md").write_text("\n".join(rows),encoding="utf-8",newline="\n")
    print(json.dumps(dict(output=str(out),unavailable_count=len(unavailable),candidate=candidate,
                         gate_invoked=False,gate_decision=None,authenticity_verified=False)))
    return 2 if unavailable else 0
if __name__=="__main__": raise SystemExit(main())
