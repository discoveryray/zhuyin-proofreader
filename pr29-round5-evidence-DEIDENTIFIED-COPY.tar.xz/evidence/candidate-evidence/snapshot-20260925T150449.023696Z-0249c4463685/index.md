# PR29 新候選證據索引（不是審查結論）

N: 0249c44636857739a262d10bd7f4e7ed1f713d1c

此工具只整理執行與來源事實；未知歷史保持未知，不補寫舊 finding resolution。

|項目|Retained tests|證據狀態|
|---|---:|---|
|KF-01|7|retained_tests_executed_on_N|
|KF-02|5|retained_tests_executed_on_N|
|KF-03|3|retained_tests_executed_on_N|
|KF-04|4|retained_tests_executed_on_N|
|KF-05|1|retained_tests_executed_on_N|
|KF-06|4|retained_tests_executed_on_N|
|KF-07|4|retained_tests_executed_on_N|
|RC-01|5|retained_tests_executed_on_N|
|RC-02|7|retained_tests_executed_on_N|
|RC-03|5|retained_tests_executed_on_N|
|RC-04|0|pending_or_incomplete|

尚缺精確 N 執行 record roles：[]。
完整 raw sources/hash、失敗／skip、source binding、額外 native cases 及 active benchmark 見 index.json。
需要獨立 reviewer 親讀 N 差異與證據；本文件不發 PASS、merge 或 COMPLETE。
