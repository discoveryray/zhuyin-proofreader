# PR29 接續 snapshot 外部建構工具

這是 evidence-only 工具，不是 gate、正式 reviewer、授權來源或 authenticity verifier。它只讀明確給定的檔案與 Git objects/status，輸出都在本 candidate-evidence 的唯一 timestamp/N 子目錄；不跑產品測試、不搜尋舊件、不改 Git/PR 或受審檔案。

工具已準備；目前沒有為 N1、N2 或其他版本建立成功 snapshot。N2 不是工具的預設或最終候選，default-fd pytest 的 skip 與 GUI audit failure 不會被覆蓋。

## 使用順序

1. 等 root 固定實際 N 並完成適用驗證，先取得 index_candidate_evidence.py 的有效 index.json。確認選用的 pytest/inventory/GUI verifier 是同一完整入口實際結果；所有失敗診斷仍保留。
2. 另存 continuation-construction.template.json 為新的執行 manifest，填 full N SHA、repo、actual executing_actor。不要覆寫已完成 snapshot。
3. 填每個 source 的 path、實際 SHA256、來源說明；JSON wrapper 必須明填 json_pointer，工具不猜測 connector 包裝。text 類型用 format=text。
4. 為 actors 與 assessments 另存完整實際版本，保留來源檔、分析與 source_keys；將其原始文件也登錄進 manifest.sources。模板的 null/empty/missing/unknown 都不是成功。
5. 填真實 PR REST pull-request object、git ls-remote 輸出的兩個直接 refs，保留 base/head 原值，不以 D/N 替換 API。兩者 captured_at_utc 必須是實際擷取時間，不是 PR updated_at 或檔案 mtime；超過 300 秒會列 unavailable，副作用前仍須協調者重新核對。
6. 已有正式 reviewer JSON 時，使用 reviews 清單中的 record_source/full_report_source 指向已登錄 source key。原 JSON 一字不造，須符合 v2 欄位並與 full report 的 report_ref/N 相連。尚未審查就 reviews=[]，不製造 BLOCKED/PASS 或角色。unavailable_review_rounds 只記實際能力不可用，不把尚未安排等同不可用。
7. 有 CI 時才填 ci={normalized_source: <key>, raw_source_keys: [<actual run/jobs/logs/tested-commit source keys>] }。normalized proof 是協調者保存的實際正規化證據，工具只保留與引用，不能靠它自稱 authenticity；所有 jobs/logs/checkout/run attempt 仍須第二輪親查。pre-push 不接收 old-head CI。
8. 執行：python -X utf8 construct_continuation_snapshot.py <explicit-manifest.json>
9. 只在無 construction gaps 時產生 continuation-state.json；有缺件則是 continuation-state.draft.json，exit 2，construction-provenance.json 列清楚 unavailable。不得拿 draft 做副作用。工具不執行 adapter，不產生 gate decision。
10. 協調者另以固定候選的 scripts/pr29_review_gate.py 對輸入執行 validate/next-action，保存真正輸出與 exit；schema-valid 不是 authenticity、review PASS 或 merge 權限。缺少 review/CI 在 state 保持 []/null，實際 next-action 由 gate 決定。

## manifest.sources 的最低資料

- authorization：已採納使用者全文，必須是實際 53790b7433d64197d046dbaad0e61c6ebb0ad5775a1d5ad3ec36e142371a0b26 bytes；模板已指向原件。
- history：本次重建 history，保留已知四輪和缺失原件；不改寫。
- mapping：11 項 KF/RC identity 對照。
- candidate_index：exact N 的候選 index；工具逐一重新核對它列出的本機 raw source hash。
- actors：實際 implementers、當前 authorization_active、source_keys、真實 handoffs、實際 unavailable_review_rounds、實際 candidate_freeze 記錄。沒有訊息/session就留 unknown，不能用 fixture actor。
- assessments：本次 N 的明示工程驗證判斷。local_validation 下 platform/python_version/runtime_source_keys 來自實際 runtime 原件；checks 各項 status/source_keys/analysis 來自已完成驗證。
- pr_api：原始 REST PR object，使用 number/html_url/state/merged/draft/base.ref/base.sha/head.ref/head.sha/mergeable。若 connector 格式不同，另保存明示 normalized object 及 raw source 鏈，不默默改值。
- direct_refs：原始文字，每行 full SHA 與 refs/heads/develop 或 refs/heads/codex/review-confirm-responsive。
- 其他 runtime、角色訊息、findings 查閱、protection、benchmark、reports、CI raw 檔：依 source_keys/refs 額外登錄，全部必須 path+SHA256 實際相符。

## assessments 不能自動填成成功

- local_validation.checks 名稱固定為 unittest、pytest、gui、runtime、compile、diff、performance。
- success 必須同時具有 exact N index 對应 record roles 與明示原始 source_keys；pytest/gui 有 failure/skip/duplicate 時拒絕 success。
- performance 的 active_batch_source_key 必須指向所選 candidate index 的同一 active run-index；其路徑須包含明指 active_benchmark_batch（本輪計畫 paired-final-v5）。v4/previous_source_measurements 只能當保留診斷。
- known_findings 的 KF-01..07/RC-01..04 只有明示 analysis、有效 N index、source_keys 齊全才能保留 verified_on_candidate；工具不從 test name 或舊 PASS 推論涵蓋。
- pr_findings.checked/source_keys/new_blockers 是真正讀取最新 PR finding 後的紀錄；缺資料會 findings_checked=false 並明列 unavailable。empty blockers 在 checked=false 時不代表清除。
- protection.satisfied 必須有真實來源；API mergeable=null 或未查保護狀態不會被硬改 true/false。未知會使建構輸入 incomplete。
- 不接受任意新增操作；可授權集合只來自精確採納全文，不包含 merge/release。

## 輸出

- observed-git-scope.json：當下 N/tree/status、H/D ancestry、H→N 全部 Git commits；無推測角色。
- fifth-history-append.json：本次候選追加事件，仍一個第5輪；是否 valid index 分開標示，不冒稱第五輪已審完。原四輪 history 與原 in-progress reconstruction 不動。
- known-findings-candidate-matrix.json：11 項新候選 facts/分析/引用。未知歷史與原 resolution 保持 unknown。
- continuation-state.json 或明顯 incomplete 的 draft。
- construction-provenance.json：每來源 path/hash/pointer/時間、工具自身、執行 manifest、副本、unavailable 與 missing review rounds；authenticity_verified=false、gate_invoked=false、gate_decision=null。
- append-summary.md 及 sources/ 可攜原始副本。

限制：工具會減少 schema、版本及 hash 引用錯誤，不能證明輸入作者真實、語意涵蓋完整、PR findings 全部讀過、性能達標或雙版本 CI 已真執行。這些仍由協調者與兩位 fresh session reviewers 對原始證據負責。

### Evidence pointer correction

The builder derives finding references from each ID's actual array index in the supplied source. Mapping order and assessment order need not match output sorting. It includes any declared source JSON pointer prefix and resolves the saved original source before emitting a reference; a missing or ambiguous row is unavailable, never a fabricated valid reference. This evidence-only correction does not invoke the gate or change candidate source, findings judgments, authorization, or review outcomes.
