"""Index fixed-candidate evidence without running tests or issuing review/gate PASS."""
from __future__ import annotations
import argparse,ast
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,re,subprocess
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
D="502414b3b38e004a6d8d9cb693cf21b65148765a"
B="1593e7af65596d320b4427f1b15bb2bc0bdc949c"
H="a38bdf1c84889c52e7281a0c23c9458e3762afa8"

def digest(raw): return hashlib.sha256(raw).hexdigest()
def load(p): return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def git(repo,*args):
    return subprocess.run(["git","-C",str(repo),*args],check=True,capture_output=True).stdout
def identity(case):
    return case.get("classname","").removeprefix("tests.")+"."+case.get("name","")
def cell_status(case):
    for tag in ("error","failure","skipped"):
        if case.find(tag) is not None: return tag
    return "executed_successfully"
def declared_output(command,flag):
    for i,arg in enumerate(command):
        if arg.startswith(flag+"="): return arg.split("=",1)[1]
        if arg==flag and i+1<len(command): return command[i+1]
    return None
def samepath(a,b,cwd):
    a=Path(a)
    if not a.is_absolute(): a=Path(cwd)/a
    return a.resolve()==Path(b).resolve()
def head_of(snapshot):
    h=snapshot.get("head",{})
    return h.get("stdout","").strip() if isinstance(h,dict) else None

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo",required=True,type=Path)
    p.add_argument("--candidate",required=True)
    p.add_argument("--junit",required=True,type=Path)
    p.add_argument("--inventory",required=True,type=Path)
    p.add_argument("--record",action="append",default=[],help="role=record.json; role examples: pytest,unittest,inventory,gui-verifier,runtime,compile,diff,oracle")
    p.add_argument("--benchmark-index",type=Path,help="Explicit final active batch run-index.json; never auto-selects v4/v5")
    p.add_argument("--benchmark-aggregate",type=Path)
    p.add_argument("--extra-evidence",action="append",default=[],type=Path)
    a=p.parse_args()
    if not re.fullmatch(r"[0-9a-f]{40}",a.candidate): p.error("candidate must be a full SHA")
    live_head=git(a.repo,"rev-parse","HEAD").decode().strip()
    live_status=git(a.repo,"status","--porcelain=v1").decode()
    if live_head!=a.candidate or live_status:
        p.error("source checkout must be exact N and clean; no candidate result inferred from dirty source")
    mapping=load(ROOT/"test-id-mapping.json")
    stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    out=ROOT/f"snapshot-{stamp}-{a.candidate[:12]}"
    out.mkdir(exist_ok=False)
    sources=[]
    def capture(path,role):
        path=Path(path).resolve()
        raw=path.read_bytes()
        relative="sources/"+digest(raw)[:16]+"-"+path.name
        dest=out/relative
        dest.parent.mkdir(exist_ok=True)
        if dest.exists() and dest.read_bytes()!=raw: raise ValueError("source filename collision")
        dest.write_bytes(raw)
        info=dict(role=role,original_path=str(path),file=relative,sha256=digest(raw),bytes=len(raw))
        sources.append(info)
        return info
    capture(ROOT/"test-id-mapping.json","mapping")
    capture(ROOT/"index_candidate_evidence.py","indexer_source")
    records=[]
    tracked={name for name in git(a.repo,"ls-tree","-r","--name-only","-z",a.candidate).decode("utf-8").split("\0") if name}
    current_hashes={name:digest((a.repo/name).read_bytes()) for name in tracked}
    for spec in a.record:
        if "=" not in spec: p.error("--record requires role=path")
        role,name=spec.split("=",1)
        path=Path(name)
        rec=load(path)
        ref=capture(path,"validation_record:"+role)
        raw=path.parent/"raw.log"
        logref=capture(raw,"validation_log:"+role) if raw.is_file() else None
        reasons=[]
        for state in ("before","after"):
            s=rec.get(state,{})
            if head_of(s)!=a.candidate: reasons.append(state+"_head_not_N")
            if s.get("status",{}).get("stdout")!="": reasons.append(state+"_working_tree_not_clean")
        if rec.get("source_bytes_unchanged") is not True: reasons.append("source_bytes_unchanged_not_proven")
        before_files=rec.get("before",{}).get("files_sha256",{})
        after_files=rec.get("after",{}).get("files_sha256",{})
        if not before_files or before_files!=after_files: reasons.append("before_after_source_hashes_differ_or_missing")
        if not tracked.issubset(before_files): reasons.append("record_source_manifest_omits_tracked_N_files")
        if any(before_files.get(name)!=expected for name,expected in current_hashes.items()): reasons.append("record_source_bytes_do_not_match_clean_N")
        if rec.get("exit_code")!=0: reasons.append("command_not_successful")
        if not rec.get("ended_utc"): reasons.append("command_not_finished")
        if logref is None or rec.get("log_sha256")!=logref["sha256"]: reasons.append("raw_log_hash_missing_or_mismatch")
        records.append(dict(role=role,record=ref,raw_log=logref,label=rec.get("label"),command=rec.get("command"),
                            cwd=rec.get("cwd"),before_head=head_of(rec.get("before",{})),
                            after_head=head_of(rec.get("after",{})),exit_code=rec.get("exit_code"),
                            started_utc=rec.get("started_utc"),ended_utc=rec.get("ended_utc"),
                            exact_N_execution_evidence=not reasons,binding_gaps=reasons))
    inv=load(a.inventory)
    iref=capture(a.inventory,"pytest_inventory")
    jref=capture(a.junit,"pytest_junit")
    collected=inv.get("pytest_ids",[])
    gui=inv.get("gui_ids",[])
    cases={}
    for case in ET.parse(a.junit).iter("testcase"):
        cases.setdefault(identity(case),[]).append(case)
    unique_collection=bool(collected) and all(v==1 for v in Counter(collected).values())
    identity_match=Counter(collected)==Counter({name:len(entries) for name,entries in cases.items()})
    pytest_records=[r for r in records if r["role"]=="pytest" and r["exact_N_execution_evidence"]]
    junit_bound=any(declared_output(r["command"] or [],"--junitxml") and
                    samepath(declared_output(r["command"],"--junitxml"),a.junit,r["cwd"]) for r in pytest_records)
    inventory_records=[r for r in records if r["role"]=="inventory" and r["exact_N_execution_evidence"]]
    inventory_bound=any("collect" in (r["command"] or []) and
                        (r["command"] or [])[-1] and samepath(r["command"][-1],a.inventory,r["cwd"]) for r in inventory_records)
    identity_evidence_valid=unique_collection and identity_match and junit_bound and inventory_bound
    testfacts={name:dict(execution_status=cell_status(entries[0]) if len(entries)==1 else "duplicate",
                         instances=len(entries),listed_in_inventory=name in collected,required_gui=name in gui,
                         junit=jref["file"],candidate_binding=identity_evidence_valid)
               for name,entries in cases.items()}
    rows=[]
    for row in mapping["rows"]:
        selected=[]
        for t in row["required_retained_test_ids"]:
            fact=testfacts.get(t["test_id"],dict(execution_status="missing",instances=0,candidate_binding=False))
            selected.append(dict(**t,**fact))
        available=bool(selected) and identity_evidence_valid and all(t["execution_status"]=="executed_successfully" for t in selected)
        rows.append(dict(id=row["id"],title=row["title"],candidate=a.candidate,
                         required_behavior=row["required_behavior"],retained_test_facts=selected,
                         evidence_status="retained_tests_executed_on_N" if available else "pending_or_incomplete",
                         semantic_coverage="requires independent source review; retained tests alone do not prove complete behavior",
                         historical_resolution="unchanged unknown; no retroactive finding resolution",
                         review_verdict=None))
    # New native owner/destroy cases are separately enumerated from exact N AST for reviewer mapping.
    supplemental=[]
    mapped={x["test_id"] for row in mapping["rows"] for x in row["required_retained_test_ids"]}
    raw=git(a.repo,"show",a.candidate+":tests/test_review_async_save.py")
    tree=ast.parse(raw.decode("utf-8-sig"))
    for cls in [n for n in ast.walk(tree) if isinstance(n,ast.ClassDef)]:
        for fn in [n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith("test_")]:
            tid=f"test_review_async_save.{cls.name}.{fn.name}"
            if tid not in mapped:
                supplemental.append(dict(test_id=tid,line=fn.lineno,source_ref=a.candidate+":tests/test_review_async_save.py",
                                         test_fact=testfacts.get(tid),semantic_mapping="pending reviewer/coordinator mapping; no inferred coverage"))
    benchmark=dict(status="not_supplied",active_source=None,source_binding="pending",prior_versions_not_accepted=True)
    if a.benchmark_index:
        bref=capture(a.benchmark_index,"explicit_active_benchmark_index")
        raw_index=load(a.benchmark_index)
        entries=raw_index if isinstance(raw_index,list) else raw_index.get("runs",[])
        measurements=[]
        for entry in entries:
            command=entry.get("command",[])
            result_name=declared_output(command,"--output")
            if not result_name: continue
            result=Path(result_name)
            if not result.is_absolute(): result=a.benchmark_index.parent/result
            if not result.is_file(): continue
            data=load(result)
            result_ref=capture(result,"benchmark_raw_result")
            log=a.benchmark_index.parent/(str(entry.get("name",""))+".log")
            log_ref=capture(log,"benchmark_raw_log") if log.is_file() else None
            files=data.get("source_files_sha256",{})
            matches_N=bool(files) and all((a.repo/name).is_file() and
                        digest((a.repo/name).read_bytes())==expected for name,expected in files.items())
            measurements.append(dict(name=entry.get("name"),exit_code=entry.get("exit_code"),
                                     result=result_ref,log=log_ref,result_hash_matches=entry.get("result_sha256")==result_ref["sha256"],
                                     log_hash_matches=bool(log_ref) and entry.get("log_sha256")==log_ref["sha256"],
                                     revision_label=data.get("revision_label"),source_manifest_matches_clean_N=matches_N,
                                     source_manifest_sha256=data.get("source_manifest_sha256"),
                                     fixture_content_sha256=data.get("fixture_content_sha256"),environment=data.get("environment"),
                                     python=data.get("python"),harness_sha256=data.get("harness_sha256"),
                                     rows=data.get("rows"),initial_events=data.get("initial_events"),staged_groups=data.get("staged_groups"),
                                     operations=data.get("operations"),cooldown_ms=data.get("cooldown_ms"),
                                     cold=data.get("cold"),processing=data.get("processing"),
                                     ui_max_heartbeat_gap=data.get("ui_max_heartbeat_gap"),memory=data.get("memory"),
                                     interpretation="facts only; D/source equality, paired fixture/environment, aggregate recalculation and regression analysis still require review"))
        benchmark=dict(status="explicit_active_batch_indexed",active_source=bref,measurements=measurements,
                       source_binding="per-measurement byte facts; no revision-label-only applicability",
                       prior_versions_not_accepted=True)
    if a.benchmark_aggregate:
        benchmark["aggregate"]=capture(a.benchmark_aggregate,"benchmark_aggregate")
        aggregate=load(a.benchmark_aggregate)
        benchmark["declared_active_batch"]=aggregate.get("active_batch") if isinstance(aggregate,dict) else None
        benchmark["aggregate_selection_note"]="Only explicit active index is indexed; previous_source_measurements retained separately and never silently substituted."
    for path in a.extra_evidence: capture(path,"extra_evidence")
    required_roles={"pytest","unittest","inventory","gui-verifier","runtime","compile","diff","oracle"}
    available_roles={r["role"] for r in records if r["exact_N_execution_evidence"]}
    result=dict(schema="pr29-candidate-evidence-index/v1",created_at_utc=datetime.now(timezone.utc).isoformat(),
                repository="discoveryray/zhuyin-proofreader",task="review-confirm-responsive",pr=29,
                baseline=B,continuation_start=H,integration_target=D,candidate=a.candidate,
                source_checkout_head=live_head,source_checkout_status=live_status,
                evidence_only=True,review_verdict=None,gate_decision=None,history_resolution="not asserted",
                inventory_and_junit=dict(unique_collection=unique_collection,identity_match=identity_match,
                    junit_command_bound_to_N=junit_bound,inventory_command_bound_to_N=inventory_bound,
                    collected_count=len(collected),gui_count=len(gui),
                    result_counts=dict(Counter(f["execution_status"] for f in testfacts.values())),
                    failing_skipped_or_duplicate=[name for name,f in testfacts.items() if f["execution_status"]!="executed_successfully"]),
                missing_exact_N_record_roles=sorted(required_roles-available_roles),
                record_facts=records,rows=rows,supplemental_async_test_facts=supplemental,benchmark=benchmark,sources=sources,
                limitations=["No independent review or gate PASS issued.","CI matrix verification remains independent reviewer work.",
                             "Source/command facts do not establish all semantic coverage.","Unknown historical report contents remain unknown."])
    (out/"index.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
    lines=["# PR29 新候選證據索引（不是審查結論）","",f"N: {a.candidate}","",
           "此工具只整理執行與來源事實；未知歷史保持未知，不補寫舊 finding resolution。","",
           "|項目|Retained tests|證據狀態|","|---|---:|---|"]
    for row in rows: lines.append(f"|{row['id']}|{len(row['retained_test_facts'])}|{row['evidence_status']}|")
    lines+=["",f"尚缺精確 N 執行 record roles：{result['missing_exact_N_record_roles']}。",
            "完整 raw sources/hash、失敗／skip、source binding、額外 native cases 及 active benchmark 見 index.json。",
            "需要獨立 reviewer 親讀 N 差異與證據；本文件不發 PASS、merge 或 COMPLETE。",""]
    (out/"index.md").write_text("\n".join(lines),encoding="utf-8",newline="\n")
    print(json.dumps(dict(output=str(out),candidate=a.candidate,review_verdict=None,
                         missing_exact_N_record_roles=result["missing_exact_N_record_roles"]),ensure_ascii=False))
if __name__=="__main__": main()
