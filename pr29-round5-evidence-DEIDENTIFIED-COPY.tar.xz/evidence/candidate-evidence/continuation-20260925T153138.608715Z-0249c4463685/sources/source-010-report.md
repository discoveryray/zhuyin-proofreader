# PR29 第五輪接續：第一輪獨立 cumulative review

REVIEW: PASS

- report_ref：`pr29-round5-r1-20260925T152241Z-0249c4463685`
- reviewer/session：`/root/review1_round5`；round：1；scope：`baseline_to_head`。
- baseline B：`1593e7af65596d320b4427f1b15bb2bc0bdc949c`
- base/integration D：`502414b3b38e004a6d8d9cb693cf21b65148765a`
- head N：`0249c44636857739a262d10bd7f4e7ed1f713d1c`
- tree：`824fe35743d3fefd6504315632c6b8d76fb23519`
- continuation start H：`a38bdf1c84889c52e7281a0c23c9458e3762afa8`
- repository：`discoveryray/zhuyin-proofreader`；PR：https://github.com/discoveryray/zhuyin-proofreader/pull/29；base/compare：`develop` / `codex/review-confirm-responsive`。
- independent=true；full_diff_reviewed=true；blocker_kind=null；findings=[]；ci=null。
- supersedes_report_ref=null；resolution_evidence_ref=null。本報告為 N 第一份正式第一輪報告，沒有替代歷史 code BLOCKED。

本 PASS 僅判斷使用者採納契約下、普通 push 前的完整 B→N 第一輪範圍。本人親自閱讀全部46個變更檔、相關呼叫／失敗／並行路徑、原始證據及整合 D；沒有把實作摘要、舊 PASS、CI綠燈或 adapter 輸出當作證明。N 尚未 push，新的 Windows 3.12／3.13 PR CI 及第二輪正式審查仍待執行，本報告不認證這些後續門檻。

## 獨立性、授權及範圍

本人不是實作者 `/root`、`/root/implement_round5`、`/root/benchmark_round5`、`/root/reconstruct_evidence` 之一，沒有修改受審 code/docs/tests/settings、Git/index 或 GitHub，也沒有委派他人代審。所有寫入只在 `E/reviews/review1`，用途為本人的證據核對程式、raw diagnostics、報告。隔離 detached checkout 為 `<LOCAL_REPOSITORY>/tmp/pr29-round5-review1`；E 為 `<LOCAL_REPOSITORY>/tmp/pr-review-automation/review-confirm-responsive/round5`。

先讀 N 的使用者採納原文 `docs/evidence/pr29_round5_user_adopted_contract.md`，核對 UTF-8 LF SHA256 `53790b7433d64197d046dbaad0e61c6ebb0ad5775a1d5ad3ec36e142371a0b26`；再從 B Git objects 讀 AGENTS、完整規範、automation、gate文件及v2程式，並讀 exact D 同份政策／VALIDATION_POLICY 和 N 附約。舊任務適用 B 凍結 v2 加明示第五輪附約；D 引入的一般 v3、單版本及sole-pytest不替代本案雙版本／雙入口。報告 JSON 因此無 review_mode。

原初實作及四輪鏈由 Git objects 核對：e53f44d→89e0297→bb4c136→bd6b478→H。H→cf444f4→7ea227d→N 是本次第五輪首次固定審查前準備；cf444f4 的 parents 正是 H、D，merge-base(D,N)=D。没有另開 task、重設 correction count，沒有把三個準備 commits 算成多次正式審查。任何後續確認需要改 code/tests/config/docs 的缺陷都須 STOP：第六輪未授權。

原 task、第四輪原授權、七份早期完整報告及原gate紀錄仍缺失；H全文、Git objects、舊CI及現存來源只供重建／指出需要驗證的行為，沒有追認缺失授權／PASS／resolution/session。本次採納明示不要求把全部缺件找齊才接續。核對現有鏈及29個原文引用後，未發現具體來源／輪次矛盾或尚未處理的重大安全不確定性；這不等於歷史未知內容已補齊。

工具實際限制：一般 exec sandbox helper 先回報 setup refresh/helper_unknown_error；explicit require_escalated 的唯讀操作可用。角色指令中的 read-only 並非本次OS強制保證；實際工具環境允許 workspace-write，靠本次唯讀指示和隔離checkout約束。最初 node工具初始化亦失敗，沒有因此操作受審來源。`gh` 不在PATH，改用公開REST唯讀取得原始PR資料。無尚未解除的能力缺口。

## 程式及整合判斷

`review_save_service.py` 的 worker 不觸碰Tk。save_event先以service nonblocking lock擋同service重入，再用既有project_delivery_lock串行化actual transaction/delivery；manifest/schema/seal、完整sourcePDF/XLSX/runtime內容hash及DB均檢查。hash不依mtime/size捷徑。保存前再次核對依賴；`standalone_proofread.json_save` 使用獨立temp、flush/fsync、預期DB內容hash guard及atomic replace，成功才回傳digest。失敗保持舊disk、記憶體及current row；temp清理不冒稱保存成功。

增量路徑由rule-applied baseline重做該row事件，不在上一個已判定row疊加；完整初建先驗證唯一identity，單筆結果再核對review/occurrence IDs及既有ledger validator。修改只在expected事件與機械投影，actual snapshot保留，actual unresolved不抑制expected resolution。沒有identity/schema/semantics epoch/fingerprint migration。staging摘要沿用正式group/source validation，invalid staging保留error及空checked roster，不隱藏未查核row。cache與evidence anchor分離；明知actual/rules drift不能靠retry、evict、defer、reload或換service清除。新sealed manifest只有經完整驗證才重anchor，合法actual refresh仍能進行。

`review_gui.py` 以純資料snapshot交worker、queue回主執行緒，只有durable success後才publish DB、ledger、todo及advance。generation、output path、manifest/DB owner identity、review_id阻擋stale publication；所有相關互動／shortcut／double-click及500ms cooldown保留。保存後queue/show失敗明確進recovery狀態，已保存資料可重開恢復，不再讓後續操作使用失效畫面。關閉owner取消自己的poll，worker可完成durable write，沒有向destroyed owner publish。

Tk的Variable、PhotoImage、callback和widget references依owner主執行緒清理；Expected/Confirmation/Actual dialogs、preview canvas及ActionRows都包含。PR31新增lazy peer rotation、preview-ready及viewport visibility timers亦納入；Python destroy和原生Tcl Destroy事件共用取消路徑，沒有取消其他widget timers或改全域GC。tests驗證weakref／finalizer thread、worker GC及關root後durable completion，並有舊bytes原生timer負向證據。

PR28暫存apply／navigation與確認後pending行為保留。PR31列出全部exact positions、已查核peers置後且不同字標示；A預設未勾。新checkbox只有實際photo、page、target red box及外層viewport可見才enable，之後仍需真實invoke；直接改variable、unseen peer、無photo／逾時皆不能提交。對仍有效的已staged peer不捏造新的直接證據。preview zoom／紅框／fit及失敗撤銷快捷鍵契約保留，沒有新preview cache功能。

PR32 `_canonical_reading` 只容許合法單一前置U+02D9的NFKC特殊情況，剩餘字串仍strict且canonical_bopomofo必須完全相等；reading lists專用validator，generic text/JSON/identity/quorum/contracts未放寬。新tests含TTF/CFF exact reuse、真SQLite promote/reopen/retry、conflict quarantine及malformed多音節不得改truth。Global promotions、per-PDF dependency與actual/expected fingerprint分離、repair/recovery/completion gates未被本次儲存優化越過。

## Gate、CI及政策

本人逐行審閱 `scripts/pr29_review_gate.py`，未把它自己的測試或結果當作真實review。它是無副作用的限定adapter：固定repository/task/B/H/D/branch/PR29/adoption hash與四輪history＋本輪N，拒絕未授權第六輪／merge；v2 closed report fields、兩個獨立full-scope sessions、non-code append-only關係及code BLOCKED不能同HEAD清除均保留。local/full-runtime/GUI/oracle/性能與known findings需要原始證據，文字ref本身不認證真實性。一般 `pr_review_gate.py` 仍維持三輪，v3改動適用新任務，本案不使用它降低舊门檻。

CI PR29例外同時限制event=pull_request、同repo/headrepo、number29、精確head branch、base develop/D；僅此scope套sys capture及Windows3.12／3.13＋full unittest，3.13固定3.13.0。既有PR30例外保留，其他PR/push/dispatch無新增例外。runtime、identity audit、fullpytest、GUI verifier、compile、event適用whitespace及clean-tree全保留；sys模式不等於已證明Tcl根因。test_entrypoint_audit使用独立collection identity、拒絕load_tests、覆蓋繼承GUI／functions／fixtures，並以全部JUnit逐一成功核對，skip/缺少/未知/重複/error/failure均拒絕；不把collection當execution。

即時唯讀 `git ls-remote`：develop=D、feature=H。公開PR API原始值仍base.sha=B、head.sha=H、open=true（state=open）、draft=true、merged=false；本人的 `pr29-api.raw.json` 原樣保存，沒有把它改寫成D/N。這是附約允許的push前舊API狀態，與實际branch refs分別記錄。issue comments/review comments/reviews三個公開lists目前各0；不據此清除KF或缺失歷史。沿用ruleset raw只要求Python3.13的外部保護現狀，並不豁免本task仍要求的3.12。N新CI尚不存在，R2必須取得新run/attempt、實際Windows版本／steps、synthetic merge parents[D,N]與treeN，不能使用舊H CI。

## KF／RC逐項結論與證據

下表均是本人對N的新判斷，不是替歷史報告補造resolution。精確test identities都已在N清冊及JUnit成功結果內核對。

| ID | N行為及反向情境 | 本人核對之主要來源 | 本輪結論 |
|---|---|---|---|
| KF-01 | drift跨retry/cache/reload/service replacement保留；新seal完整驗證後才reanchor | review_save_service._save；test_review_save_service:102,118,142,167；test_review_async_save:320,376,394 | 本機N已驗證 |
| KF-02 | owner close只取消自己的save/actual polls；pending durable write可重開 | review_gui._dispose_async；test_review_async_save:452,492,504,523 | 本機N已驗證 |
| KF-03 | async完成且refresh成功才explain_expected；mismatch不auto-open六gate | test_hotfix_tone_and_followup_v531:81,105,124及completion分支 | 本機N已驗證 |
| KF-04 | Tk資源主thread释放、peer轮替與原生Tcl销毁取消owned timers，worker GC安全 | test_review_async_save:538,586,645,688,721,752；native-owner-regression-before-proof-crlf原始log | 本機N已驗證；不宣稱native leak-free |
| KF-05 | held-progress fixture具有output_dir，真的到progress UI；assert無showerror／thread.start被呼叫／backend不被呼叫 | test_manual_review_usability_v580受影響fixture、test_review_async_save實際worker分支 | 本機N已驗證 |
| KF-06 | false/null/0/空字串/空list及truthy非object、malformed/duplicate JSON於cold/warm拒絕；disk/UI未前進；{}與missing保留合法初始化 | test_review_save_service:246,284,300；test_review_async_save:190 | 本機N已驗證 |
| KF-07 | 歷史init.tcl/main-thread錯誤原文保留，未知根因未猜定；strict GUI不容skip | N clean fullpytest、JUnit75GUI、fullunittest、CI scope及raw失敗history | R1階段本機證據足夠；新雙版本CI仍是R2必要門檻 |
| RC-01 | durable-before-advance、error/stale/queue failure/reopen、shortcuts/debounce | test_review_async_save:129,176,249,265,291,304；json_save guards | 本機N已驗證 |
| RC-02 | baseline單筆重播／staging與D凍結oracle等價；expected獨立；PR28/31整合 | develop_oracle_probe.py及candidate3-develop-oracle/raw.log（18函式closure、36操作）；service/staged-navigation/actual GUI tests | 本機N已驗證，非只與當前materializer自比 |
| RC-03 | 全內容hash、同size/mtime mutation、replay中變更、atomic stale DB、runtime/transactions/fingerprint安全 | test_review_save_service:216,230,324,341,356,365；N runtime及既有full安全回歸 | 本機N已驗證；沒有弱化永久契約 |
| RC-04 | 同fixture/source/environment、cold/steady中央値/P95、heartbeat及native memory；preview/500ms成本保留 | final-v5全部20測量process、22raw records、harness、本人artifact/provenance audits | 支持主要staging情境改善；cold regression與memory限制明列下方 |

## 測試與效能證據適用性

本人沒有重跑product full suite或benchmark，因為既有N乾淨完整證據可直接核對，沒有具體未解失敗需要再跑。本人實際執行的是只讀Git／原始來源閱讀、兩個獨立evidence audit scripts及REST讀取。以下為本人核對的協調者實際執行紀錄，不能說成本人重新執行。

11份 `E/validation/candidate3-{develop-oracle,runtime,inventory,unittest,pytest,gui-audit,compile,diff-baseline,diff-develop,status,environment}/record.json` 均exit0；各before/after為exact N、clean、180項來源hash相同；各raw.log SHA重新計算相符。新checkout十個text檔因Git CRLF/LF checkout與原測試raw不同，逐一以exact N Git blob核對，不把raw SHA與blob SHA混寫；runtime/binary bytes不正規化。本人audit完整讀取logs並搜尋Traceback/Exception ignored/Tcl_AsyncDelete/main-thread錯誤，N logs未見這些失敗。

| 原始N證據 | 結果 |
|---|---|
| full unittest | 762 tests，422.914s，OK；raw SHA f6ea4697e0aabba397477b0a5d0584b882d8f2ddb7e4a3e10deb9f7da052e1b2 |
| full pytest | 829 passed、887 subtests，428.13s，無skip/error/failure；raw SHA 839a64fa1cc16ca637a50d93791b707d7780a6ba6ad13c35e6f0ad8671431383 |
| identity/JUnit | 829 testcase與collection逐一相符，包含762 unittest、67pytest-only、75requiredGUI；不是固定count永久門檻 |
| runtime | 4 passed＋14subtests，manifest資產與CSV attributes測試保留；raw SHA 57062c2d4029a94ef070d3884e6e1c578005ed22ba7497c58c355f3671300b68 |
| D oracle | Git D原函式AST依赖closure18個，actual_review/occurrence_ledger來源與D核對；absent/valid/invalid staging各12操作，ledger/actual snapshot/expected unresolved/DB/checked roster比對成立 |
| compile、B→N及D→Ndiff-check、status | 原始記錄exit0；本人又唯讀核對兩份diff-check及最終clean/HEAD/tree |

環境原始記錄是Windows11 build26200、Python3.13.0 AMD64隔離venv、Tcl/Tk8.6.14、PyMuPDF1.26.7、openpyxl3.1.5、fonttools4.63.0、python-docx1.2.0、pytest9.1.1；process-local UTF8、sys capture、TCL_LIBRARY/TK_LIBRARY和隔離LOCALAPPDATA/TEMP/TMP。tests與harness的Global root都是臨時／隔離，沒有操作production Global SQLite。

`pre-review-validation-history`原文和raw來源保留：N1 sidecar -text roster failure、interrupted pytest及工具缺參數；N2 default-fd 827passed/2Tk setup skips且strictGUI fail、同N2 bytes明示sys control成功；candidate3 targeted實際為N2+dirty，不能算N；之後真正N clean完整紀錄才用作本次驗收。Tcl根因仍未知。原生owner negative probe helper exit0只證明預期failure重現，沒有被轉寫成產品PASS。

效能量測在commit前執行；本人核對D Git objects、每個run完整source map、fixture每個file hash、archived harness與N對應app bytes後才採用，不稱『當時在已存在N commit執行』。active_batch是paired-final-v5；舊v4、B→H四run與更早缺失raw仍作歷史，未混入。20 fresh measurement processes（0／8groups各5對），每run21操作、冷第1筆及穩20筆分開，20份全部raw result/log加2prepare共22紀錄hash/exit核對。兩個版本fixture實際bytes相同，environment/harness一致；每笔500ms cooldown另外保留，總完成時間包含preview。

本人重新計算每run及所有aggregate cold/steady median/P95、完成memory與sampled peaks，與提交JSON相等：

| 情境/指標 | D median/P95 ms | 新版對應N app bytes median/P95 ms |
|---|---:|---:|
| 0group cold 完成 | 163.30 /169.79 | 307.24 /317.89 |
| 0group steady 完成 | 168.11 /217.87 | 149.64 /173.22 |
| 8group cold 完成 | 415.20 /424.29 | 368.83 /379.33 |
| 8group steady 完成 | 425.08 /587.30 | 205.10 /237.76 |
| 8group steady最長heartbeat gap | 412.76 /571.44 | 59.87 /67.61 |

8group穩態total median改善51.8%、heartbeat median85.5%；0group cold增加143.93ms，確實退化。冷路徑full validation／dependency hash／初始ledger及durable fsync/guard可解釋新增成本，不把inclusive stages相加或猜精確未測部分。穩態full rebuild全為0。主thread preview仍存在，未為數據跳過。

0group steady private median177.61→190.18MiB（+12.57），8group188.56→190.67（+2.11）；兩側六次dialog序列及root destroy仍有OS memory retention，不能證明沒有native leak或長期穩態。120 dialogs／360次實際可見後checkbox invoke驗證合成互動路徑，並非真人閱讀教材。無真教材、大型複雜PDF、EXE或長期memory實測；採納契約允許如實保留這些限制，不以此冒稱驗收。

## 大型artifact与来源完整性

所有JSON以拒絕duplicate key／NaN的獨立parser讀取；兩個ZIP每個entry實際解壓讀bytes、CRC、path、重複名、length及SHA逐一核對。

- portable-reconstruction.zip：101 entries，SHA256 `5ac2a5f9657a1965aa890c1fe8d021ad00bea9339847c0b58bee8c9195134db4`；內外reconstruction manifest一致，各source與unknown狀態保留。
- benchmark-replay-v5.zip：75 entries，SHA256 `3a777d210b135ddcd08679643b22307c4867341005e45453c067213390ae81ed`；內manifest及祖先cf444f4的原sidecar一致，每個raw／fixture／harness內容均核對。sidecar固定祖先本地Git物件存在；尚未push，遠端可取回性應由協調者於普通push後讀回確認，不能說現在已發布。
- 提交的大型benchmark JSON新舊samples均實際解析；本人重算四個legacy run算術，但其中對第四輪授權的歷史敘述沒有被本review追認。
- 外部index SHA `eaa0f431af7f68c7311850056033423afb575ba80b60d015bd8d3f33f267db1e`及66個保留source bytes核對；29個KF/RC原文引用逐行／hash對照。index明示review_verdict/gate_decision=null；本人結論來自上述程式与原始證據，沒有讓index自證。

本人evidence audit首次把record.head物件當字串，第二次遇到clean checkout CRLF/LF差異，第三次未計ZIP內自帶manifest；均為本人的auditor解析／預期結構問題，修正只在本報告資料夾，保留attempt1..3 raw logs。artifact-audit-attempt4成功。另一次唯讀stdin探查有括號語法錯誤，未執行任何來源變更；provenance audit第一次完整執行成功。這些不是產品測試failure或新的修正輪次。

## 46個變更檔檢閱清冊

下列全為本人閱讀的B→N cumulative差異；新檔讀完整內容，大JSON/ZIP依上述完整结构与entry審查，沒有因檔案大而略過。D→N另外核對整合差異。

|#|檔案|檢閱焦點|
|---:|---|---|
|1|`.codex/agents/coordinator.toml`|D繼承角色分工／獨立性／v3／舊任務凍結及授權界線|
|2|`.codex/agents/implementer.toml`|D繼承角色分工／獨立性／v3／舊任務凍結及授權界線|
|3|`.codex/agents/reviewer_cumulative.toml`|D繼承角色分工／獨立性／v3／舊任務凍結及授權界線|
|4|`.codex/agents/reviewer_pr.toml`|D繼承角色分工／獨立性／v3／舊任務凍結及授權界線|
|5|`.gitattributes`|adoption LF pin；runtime CSV exact roster未擴充|
|6|`.github/workflows/ci.yml`|PR29限定雙版本／雙入口/sys capture；其他event及checks保留|
|7|`AGENTS.md`|B凍結與D/N政策逐項對照；新舊任務門檻及適用性不混用|
|8|`TESTING.md`|B凍結與D/N政策逐項對照；新舊任務門檻及適用性不混用|
|9|`docs/CHATGPT_PROJECT_INSTRUCTIONS.md`|B凍結與D/N政策逐項對照；新舊任務門檻及適用性不混用|
|10|`docs/PR29_CONTINUATION_CONTRACT.md`|B/D/H scope、限定gate/CI、原始值與階段責任|
|11|`docs/PR_REVIEW_AUTOMATION.md`|B凍結與D/N政策逐項對照；新舊任務門檻及適用性不混用|
|12|`docs/PR_REVIEW_GATE.md`|B凍結與D/N政策逐項對照；新舊任務門檻及適用性不混用|
|13|`docs/REVIEW_CONFIRM_PERFORMANCE.md`|冷退化／staging改善／native memory保留及非真人驗收|
|14|`docs/V58_MASTER_DEVELOPMENT_REVIEW_PLAN_v1.1.md`|B凍結與D/N政策逐項對照；新舊任務門檻及適用性不混用|
|15|`docs/VALIDATION_POLICY.md`|B凍結與D/N政策逐項對照；新舊任務門檻及適用性不混用|
|16|`docs/evidence/pr29_round5/README.md`|來源重建、祖先sidecar、可攜路徑與量測限制|
|17|`docs/evidence/pr29_round5/benchmark-replay-v5.zip`|全75entries／CRC／路徑／SHA／raw logs／fixture／harness|
|18|`docs/evidence/pr29_round5/portable-reconstruction.zip`|全101entries／CRC／路徑／manifest／SHA及unknown來源|
|19|`docs/evidence/pr29_round5/reconstruction-manifest.json`|每entry長度/hash／內外manifest一致|
|20|`docs/evidence/pr29_round5_user_adopted_contract.md`|使用者原文與LF bytes SHA；第五輪及禁止第六輪/merge|
|21|`docs/evidence/review_confirm_benchmark.json`|全四個歷史run/samples结构与算術；不用作N量測／授權|
|22|`docs/evidence/review_confirm_round5_benchmark.json`|final-v5全20run與保留v4；全部timing/memory統計及binding|
|23|`global_exact_glyph_library.py`|PR32 canonical neutral exception與嚴格reading/list輸入|
|24|`requirements-ci.txt`|D繼承固定direct dependency版本及launcher來源|
|25|`review_display.py`|preview/ActionRows owner resource與callbacks釋放，zoom/red target保留|
|26|`review_gui.py`|async durable publication／guards／PR28／PR31全位置及Tk生命周期|
|27|`review_save_service.py`|完整依賴hash、不可清除anchor、incremental replay、durable transaction|
|28|`scripts/benchmark_review_confirm.py`|fixture reset／內容hash／heartbeat／native memory／真render+invoke／fresh程序|
|29|`scripts/pr29_review_gate.py`|v2限定附約、自我認證禁止、五輪上限、prepush raw API與新雙CI|
|30|`scripts/pr_review_gate.py`|D繼承v3關係驗證與一般三輪不變；本案仍凍結v2|
|31|`scripts/test_entrypoint_audit.py`|identity而非count；load_tests拒絕；全部JUnit成功與GUI執行|
|32|`standalone_proofread.py`|atomic save guard、baseline replay抽取、staging摘要复用validator|
|33|`tests/review_save_test_support.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|34|`tests/test_global_exact_glyph_read_reuse_v580.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|35|`tests/test_global_promotion_v580.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|36|`tests/test_hotfix_tone_and_followup_v531.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|37|`tests/test_manual_actual_gui_batch_v570.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|38|`tests/test_manual_review_usability_v580.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|39|`tests/test_pr29_review_gate.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|40|`tests/test_pr_review_gate.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|41|`tests/test_review_async_save.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|42|`tests/test_review_save_service.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|43|`tests/test_review_visual_corrective_v580.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|44|`tests/test_review_visual_usability_v580.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|45|`tests/test_staged_review_navigation_v580.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|
|46|`tests/test_test_entrypoint_audit.py`|完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對|

## 實際命令、證據引用與交接

本人實際使用 `git show <B/D/N>:<path>`、`git diff B N -- <分組檔案>`、`git diff D N`、`git log --format=... --reverse B..N`、`git rev-parse HEAD HEAD^{tree}`、`git merge-base D N`、`git status --porcelain=v1 --untracked-files=all`、`git diff --check B N`、`git diff --check D N`、`git ls-remote origin refs/heads/develop refs/heads/codex/review-confirm-responsive`；Get-Content UTF8／rg逐段讀上列全部檔案及相關dependency。所有固定SHA以本報告頂部完整值代入。未執行fetch/checkout/commit/push/amend或任何Git mutation。

本人實際執行命令：`<LOCAL_REPOSITORY>/tmp/pr29-validation-env/Scripts/python.exe -X utf8 E/reviews/review1/artifact_audit.py`（成功為attempt4）；同interpreter執行 `E/reviews/review1/provenance_audit.py`（attempt1成功），均設PYTHONDONTWRITEBYTECODE=1，只有stdlib讀取，沒有匯入production或執行Tk/Global操作。完整輸出分別為artifact-audit-attempt4.raw.log、provenance-audit-attempt1.raw.log；結果artifact-audit.json、provenance-audit.json，失敗diagnostics保留。公開REST GET pulls/29、issues/29/comments、pulls/29/comments、pulls/29/reviews以Invoke-WebRequest讀取，原始JSON與remote-refs.raw.log在本目錄。

下列命令由原始N record轉錄，為沿用原執行證據，非本review重跑；每份before/after、env、elapsed及raw hash已在artifact-audit.json中保留。

**develop-oracle**

```text
<LOCAL_REPOSITORY>\tmp\pr29-validation-env\Scripts\python.exe -X utf8 <LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5\develop_oracle_probe.py <LOCAL_REPOSITORY>\tmp\pr29-round5-worktree
```

**runtime**

```text
<LOCAL_REPOSITORY>\tmp\pr29-validation-env\Scripts\python.exe -X utf8 -m pytest tests/test_runtime_asset_manifest_integrity_v562.py -q
```

**inventory**

```text
<LOCAL_REPOSITORY>\tmp\pr29-validation-env\Scripts\python.exe -X utf8 scripts/test_entrypoint_audit.py collect <LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5\candidate3-test-inventory.json
```

**unittest**

```text
<LOCAL_REPOSITORY>\tmp\pr29-validation-env\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_*.py
```

**pytest**

```text
<LOCAL_REPOSITORY>\tmp\pr29-validation-env\Scripts\python.exe -X utf8 -m pytest tests/ -q -rs --junitxml=<LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5\candidate3-pytest.xml --basetemp=<LOCAL_REPOSITORY>\tmp\pr29-round5-worktree\tmp\candidate3-pytest-tmp -o cache_dir=<LOCAL_REPOSITORY>\tmp\pr29-round5-worktree\tmp\candidate3-pytest-cache
```

**gui-audit**

```text
<LOCAL_REPOSITORY>\tmp\pr29-validation-env\Scripts\python.exe -X utf8 scripts/test_entrypoint_audit.py verify-gui <LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5\candidate3-test-inventory.json --junit <LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5\candidate3-pytest.xml
```

**compile**

```text
<LOCAL_REPOSITORY>\tmp\pr29-validation-env\Scripts\python.exe -X utf8 -m compileall -q -x (^|[\\/])(\.venv|tmp)([\\/]|$) .
```

**diff-baseline**

```text
git diff --check 1593e7af65596d320b4427f1b15bb2bc0bdc949c..0249c44636857739a262d10bd7f4e7ed1f713d1c
```

**diff-develop**

```text
git diff --check 502414b3b38e004a6d8d9cb693cf21b65148765a..0249c44636857739a262d10bd7f4e7ed1f713d1c
```

**status**

```text
git status --porcelain=v1
```

**environment**

```text
<LOCAL_REPOSITORY>\tmp\pr29-validation-env\Scripts\python.exe -X utf8 -c "import sys,platform,json,importlib.metadata,tkinter,os; print(json.dumps(dict(python=sys.version,executable=sys.executable,platform=platform.platform(),system=platform.system(),architecture=platform.architecture(),tcl=tkinter.TclVersion,tk=tkinter.TkVersion,pytest_addopts=os.environ.get(\"PYTEST_ADDOPTS\"),dependencies={k:importlib.metadata.version(k) for k in (\"pytest\",\"PyMuPDF\",\"openpyxl\",\"fonttools\",\"python-docx\")})))"
```

其他原始證據：E/develop_oracle_probe.py；E/candidate3-pytest.xml（SHA c8eb328739acfadeb13bf045023342361d33eaa6216ea30eb5ea4fcf94836a13）；E/candidate3-test-inventory.json；E/candidate-binding-0249c4463685.json；E/benchmark/paired-final-v5/run-index.json及22份logs/results；E/reconstruction/reconstructed-history.json/md、known-findings.json/md、source-index.json及sources；E/candidate-evidence/pre-review-validation-history.json/md及raw來源；E/candidate-evidence/snapshot-20260925T150449.023696Z-0249c4463685/index.json及66sources。標籤可能是歷史capture時間點；使用exactN records作最終判斷，沒有將所有舊標籤追認N。

未執行／未認證：新的Windows3.12/3.13 PR CI、R2、真教材／人工閱讀、長期native memory、EXE、merge／post-merge／release。未編輯受審來源／tests／政策，未降保護規則，未改live DB，未建立新task或新功能。

下一步交協調者：保留本完整report及v2 JSON；重新讀取遠端refs/API/findings及授權，只有仍D/H與exactN且本機證據／adapter checks滿足才普通push原feature分支並更新同一draft PR29，push後讀回N及祖先sidecar可取得性。然後由另一全新非實作者session自行審完整B→N及D→N PR差異，取得當前D/N synthetic integration及真正Windows3.12、3.13.0全部必要CI steps原始logs後做R2。既有缺件和STOP歷史不能覆寫；新code缺陷須STOP未授權第六輪，non-code只補原始證據、不空commit／不加count。本PASS不給merge/release或取消draft的授權。

最終核對：2026-09-25T15:27:41.126996+00:00，HEAD=N、tree如頂部、merge-base(D,N)=D，working tree clean（含untracked）且兩份diff-check無輸出／exit0；無drift。原始讀回在final-state.json。
