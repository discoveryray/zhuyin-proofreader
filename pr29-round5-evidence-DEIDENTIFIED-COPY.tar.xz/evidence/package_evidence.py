"""Package explicitly selected task evidence; no network, Git or product writes."""
import argparse,base64,datetime,hashlib,io,json,pathlib,tarfile
p=argparse.ArgumentParser();p.add_argument("manifest",type=pathlib.Path);p.add_argument("--output",required=True,type=pathlib.Path);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent
config=json.loads(a.manifest.read_text(encoding="utf-8-sig"))
out=a.output.resolve()
assert out.is_relative_to(root.resolve()) and not out.exists()
out.mkdir(parents=True)
sources={}
for relative in config["files"]:
    path=(root/relative).resolve()
    assert path.is_relative_to(root.resolve()) and path.is_file(),relative
    name=path.relative_to(root).as_posix()
    assert name not in sources,name
    sources[name]=path.read_bytes()
assert sources
def sha(raw):return hashlib.sha256(raw).hexdigest()
index={"schema":"pr29-round5-portable-evidence/1","created_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"repository":"discoveryray/zhuyin-proofreader","task":"review-confirm-responsive","pr":29,"candidate":config["candidate"],"source_root_mapping":"Archive evidence/ corresponds to original round5 evidence root. Original absolute paths in logs are retained audit data.","scope_note":config["scope_note"],"git_references":config.get("git_references",[]),"files":[{"path":"evidence/"+name,"sha256":sha(raw),"bytes":len(raw)} for name,raw in sorted(sources.items())]}
payload={"INDEX.json":(json.dumps(index,ensure_ascii=False,indent=2)+"\n").encode(),"README.md":b"# PR29 round5 original evidence\n\nINDEX.json maps each preserved raw file to its SHA256. No review or historical authorization is created by this archive. Git references identify separately preserved large committed artifacts. Never reinterpret earlier failed/partial records as current success.\n"}
payload.update({"evidence/"+k:v for k,v in sources.items()})
archive=out/"pr29-round5-evidence.tar.xz"
with tarfile.open(archive,"w:xz",preset=6) as tf:
    for name,raw in sorted(payload.items()):
        item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0
        tf.addfile(item,io.BytesIO(raw))
with tarfile.open(archive,"r:xz") as tf:
    assert tf.getnames()==sorted(payload)
    for member in tf.getmembers():
        assert member.isfile() and tf.extractfile(member).read()==payload[member.name]
raw=archive.read_bytes();bundle=sha(raw);encoded=base64.b64encode(raw).decode("ascii")
parts=[encoded[i:i+52000] for i in range(0,len(encoded),52000)]
items=[]
for number,part in enumerate(parts,1):
    body=("PR29-R5-EVIDENCE "+bundle+" part "+str(number)+"/"+str(len(parts))+"\n\n"
      "<details><summary>第五輪原始證據封存分段 "+str(number)+"/"+str(len(parts))+"（Base64；不是審查结論）</summary>\n\n"
      "Archive: pr29-round5-evidence.tar.xz\n\nCandidate: "+config["candidate"]+"\n\n"
      "完整 archive SHA256: "+bundle+"\n\n"
      "本段 Base64 text SHA256: "+sha(part.encode())+"\n\n"
      "```base64\n"+part+"\n```\n\n</details>\n")
    assert len(body)<60000
    file=out/("part-"+str(number).zfill(3)+".md");file.write_text(body,encoding="utf-8",newline="\n")
    items.append({"part":number,"parts":len(parts),"file":str(file),"body_sha256":sha(body.encode()),"base64_sha256":sha(part.encode()),"characters":len(body)})
manifest={"bundle_sha256":bundle,"archive":str(archive),"bytes":len(raw),"candidate":config["candidate"],"index_sha256":sha(payload["INDEX.json"]),"files":len(sources),"parts":items}
(out/"publication-manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
(out/"INDEX.json").write_bytes(payload["INDEX.json"])
print(json.dumps({"output":str(out),"archive_sha256":bundle,"bytes":len(raw),"source_files":len(sources),"parts":len(parts),"roundtrip_verified":True}))

