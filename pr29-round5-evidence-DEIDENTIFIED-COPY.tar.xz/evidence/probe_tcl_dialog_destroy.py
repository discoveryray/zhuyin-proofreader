import tkinter as tk
import tempfile, pathlib, json, sys
sys.path.insert(0,str(pathlib.Path.cwd()))
import review_gui as gui
from tests.test_staged_review_navigation_v580 import create_staged_navigation_fixture
import standalone_proofread as sp
root=tk.Tk(); root.tk.eval("set ::probe_errors {}; proc bgerror {message} {lappend ::probe_errors $message}")
with tempfile.TemporaryDirectory() as directory:
    output=pathlib.Path(directory); create_staged_navigation_fixture(output)
    app=gui.ReviewApp(root,output); root.update(); row=app.current()
    owner=tk.Toplevel(root)
    dialog=gui.ActualReadingDialog(owner,row,{"members":[row]},output,wait=False)
    dialog._schedule_visibility_check()
    owned=set(filter(None,dialog._preview_ready_after))
    if dialog._visibility_after: owned.add(dialog._visibility_after)
    root.tk.call("destroy",owner._w)
    pending=set(root.tk.splitlist(root.tk.call("after","info")))
    print(json.dumps({"owned_before":sorted(owned),"owned_pending_after_tcl_destroy":sorted(owned&pending),"destroying":dialog._destroying}))
    root.update()
    print("bgerrors",root.tk.getvar("probe_errors"))
root.destroy()
