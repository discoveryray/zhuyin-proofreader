from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path(r'<LOCAL_REPOSITORY>\tmp\pr29-round5-review1');R=Path(r'<LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5\reviews\review1')
B='1593e7af65596d320b4427f1b15bb2bc0bdc949c';D='502414b3b38e004a6d8d9cb693cf21b65148765a';N='0249c44636857739a262d10bd7f4e7ed1f713d1c'
def git(*a):return subprocess.check_output(['git',*a],cwd=W).decode('utf8')
files=git('diff','--name-only',B,N).splitlines();assert len(files)==46
notes={
'.gitattributes':'adoption LF pin；runtime CSV exact roster未擴充',
'.github/workflows/ci.yml':'PR29限定雙版本／雙入口/sys capture；其他event及checks保留',
'global_exact_glyph_library.py':'PR32 canonical neutral exception與嚴格reading/list輸入',
'requirements-ci.txt':'D繼承固定direct dependency版本及launcher來源',
'review_display.py':'preview/ActionRows owner resource與callbacks釋放，zoom/red target保留',
'review_gui.py':'async durable publication／guards／PR28／PR31全位置及Tk生命周期',
'review_save_service.py':'完整依賴hash、不可清除anchor、incremental replay、durable transaction',
'standalone_proofread.py':'atomic save guard、baseline replay抽取、staging摘要复用validator',
'scripts/benchmark_review_confirm.py':'fixture reset／內容hash／heartbeat／native memory／真render+invoke／fresh程序',
'scripts/pr29_review_gate.py':'v2限定附約、自我認證禁止、五輪上限、prepush raw API與新雙CI',
'scripts/pr_review_gate.py':'D繼承v3關係驗證與一般三輪不變；本案仍凍結v2',
'scripts/test_entrypoint_audit.py':'identity而非count；load_tests拒絕；全部JUnit成功與GUI執行',
'docs/evidence/review_confirm_benchmark.json':'全四個歷史run/samples结构与算術；不用作N量測／授權',
'docs/evidence/review_confirm_round5_benchmark.json':'final-v5全20run與保留v4；全部timing/memory統計及binding',
'docs/evidence/pr29_round5/portable-reconstruction.zip':'全101entries／CRC／路徑／manifest／SHA及unknown來源',
'docs/evidence/pr29_round5/benchmark-replay-v5.zip':'全75entries／CRC／路徑／SHA／raw logs／fixture／harness',
'docs/evidence/pr29_round5/reconstruction-manifest.json':'每entry長度/hash／內外manifest一致',
'docs/evidence/pr29_round5/README.md':'來源重建、祖先sidecar、可攜路徑與量測限制',
'docs/evidence/pr29_round5_user_adopted_contract.md':'使用者原文與LF bytes SHA；第五輪及禁止第六輪/merge',
'docs/PR29_CONTINUATION_CONTRACT.md':'B/D/H scope、限定gate/CI、原始值與階段責任',
'docs/REVIEW_CONFIRM_PERFORMANCE.md':'冷退化／staging改善／native memory保留及非真人驗收',
}
for f in files:
 if f.startswith('tests/'):
  notes[f]='完整差異與assertions、fixture隔離、negative cases及N JUnit身份核對'
 elif f.startswith('.codex/'):
  notes[f]='D繼承角色分工／獨立性／v3／舊任務凍結及授權界線'
 elif f not in notes:
  notes[f]='B凍結與D/N政策逐項對照；新舊任務門檻及適用性不混用'
audit=json.loads((R/'artifact-audit.json').read_text())
with (R/'report.md').open('a',encoding='utf8') as o:
 o.write('|#|檔案|檢閱焦點|\n|---:|---|---|\n')
 for i,f in enumerate(files,1):o.write(f'|{i}|`{f}`|{notes[f]}|\n')
 o.write('\n## 實際命令、證據引用與交接\n\n')
 o.write('本人實際使用 `git show <B/D/N>:<path>`、`git diff B N -- <分組檔案>`、`git diff D N`、`git log --format=... --reverse B..N`、`git rev-parse HEAD HEAD^{tree}`、`git merge-base D N`、`git status --porcelain=v1 --untracked-files=all`、`git diff --check B N`、`git diff --check D N`、`git ls-remote origin refs/heads/develop refs/heads/codex/review-confirm-responsive`；Get-Content UTF8／rg逐段讀上列全部檔案及相關dependency。所有固定SHA以本報告頂部完整值代入。未執行fetch/checkout/commit/push/amend或任何Git mutation。\n\n')
 o.write('本人實際執行命令：`<LOCAL_REPOSITORY>/tmp/pr29-validation-env/Scripts/python.exe -X utf8 E/reviews/review1/artifact_audit.py`（成功為attempt4）；同interpreter執行 `E/reviews/review1/provenance_audit.py`（attempt1成功），均設PYTHONDONTWRITEBYTECODE=1，只有stdlib讀取，沒有匯入production或執行Tk/Global操作。完整輸出分別為artifact-audit-attempt4.raw.log、provenance-audit-attempt1.raw.log；結果artifact-audit.json、provenance-audit.json，失敗diagnostics保留。公開REST GET pulls/29、issues/29/comments、pulls/29/comments、pulls/29/reviews以Invoke-WebRequest讀取，原始JSON與remote-refs.raw.log在本目錄。\n\n')
 o.write('下列命令由原始N record轉錄，為沿用原執行證據，非本review重跑；每份before/after、env、elapsed及raw hash已在artifact-audit.json中保留。\n\n')
 for x in audit['validation']:
  cmd=x['command']
  o.write('**'+x['label']+'**\n\n```text\n'+(subprocess.list2cmdline(cmd) if isinstance(cmd,list) else str(cmd))+'\n```\n\n')
 o.write('其他原始證據：E/develop_oracle_probe.py；E/candidate3-pytest.xml（SHA c8eb328739acfadeb13bf045023342361d33eaa6216ea30eb5ea4fcf94836a13）；E/candidate3-test-inventory.json；E/candidate-binding-0249c4463685.json；E/benchmark/paired-final-v5/run-index.json及22份logs/results；E/reconstruction/reconstructed-history.json/md、known-findings.json/md、source-index.json及sources；E/candidate-evidence/pre-review-validation-history.json/md及raw來源；E/candidate-evidence/snapshot-20260925T150449.023696Z-0249c4463685/index.json及66sources。標籤可能是歷史capture時間點；使用exactN records作最終判斷，沒有將所有舊標籤追認N。\n\n')
 o.write('未執行／未認證：新的Windows3.12/3.13 PR CI、R2、真教材／人工閱讀、長期native memory、EXE、merge／post-merge／release。未編輯受審來源／tests／政策，未降保護規則，未改live DB，未建立新task或新功能。\n\n')
 o.write('下一步交協調者：保留本完整report及v2 JSON；重新讀取遠端refs/API/findings及授權，只有仍D/H與exactN且本機證據／adapter checks滿足才普通push原feature分支並更新同一draft PR29，push後讀回N及祖先sidecar可取得性。然後由另一全新非實作者session自行審完整B→N及D→N PR差異，取得當前D/N synthetic integration及真正Windows3.12、3.13.0全部必要CI steps原始logs後做R2。既有缺件和STOP歷史不能覆寫；新code缺陷須STOP未授權第六輪，non-code只補原始證據、不空commit／不加count。本PASS不給merge/release或取消draft的授權。\n')
state={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').strip(),'tree':git('rev-parse','HEAD^{tree}').strip(),'status':git('status','--porcelain=v1','--untracked-files=all'),'merge_base_D':git('merge-base',D,N).strip(),'diff_baseline_check':git('diff','--check',B,N),'diff_develop_check':git('diff','--check',D,N),'files':files}
assert state['head']==N and state['tree']=='824fe35743d3fefd6504315632c6b8d76fb23519' and state['status']=='' and state['merge_base_D']==D
(R/'final-state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf8')
with (R/'report.md').open('a',encoding='utf8') as o:o.write('\n最終核對：'+state['utc']+'，HEAD=N、tree如頂部、merge-base(D,N)=D，working tree clean（含untracked）且兩份diff-check無輸出／exit0；無drift。原始讀回在final-state.json。\n')
review={'round':1,'reviewer':'/root/review1_round5','baseline':B,'base':D,'head':N,'scope':'baseline_to_head','verdict':'PASS','independent':True,'full_diff_reviewed':True,'findings':[],'report_ref':'pr29-round5-r1-20260925T152241Z-0249c4463685','ci':None,'blocker_kind':None,'supersedes_report_ref':None,'resolution_evidence_ref':None}
(R/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'report':str(R/'report.md'),'review':review,'final':state,'report_sha256':hashlib.sha256((R/'report.md').read_bytes()).hexdigest(),'review_sha256':hashlib.sha256((R/'review.json').read_bytes()).hexdigest()},ensure_ascii=False,indent=2))
