from pathlib import Path
import json,hashlib,subprocess,statistics,math,zipfile
W=Path(r'<LOCAL_REPOSITORY>\tmp\pr29-round5-review1');E=Path(r'<LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5');R=E/'reviews/review1'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
b=load(W/'docs/evidence/review_confirm_round5_benchmark.json');z=zipfile.ZipFile(W/'docs/evidence/pr29_round5/benchmark-replay-v5.zip')
idx=load(E/'benchmark/paired-final-v5/run-index.json');assert idx==b['run_index'];assert len(idx)==22
rawrows=[]
for x in idx:
 name=x['name'];log=(E/'benchmark/paired-final-v5'/(name+'.log')).read_bytes();result=(E/'benchmark/paired-final-v5'/(name+'.json')).read_bytes()
 assert x['exit_code']==0 and sha(log)==x['log_sha256'] and sha(result)==x['result_sha256']
 assert z.read('raw-logs/paired-final-v5/'+name+'.log')==log
 assert not any(v in log.decode('utf8') for v in ['Traceback (most recent','Exception ignored','Tcl_AsyncDelete','main thread is not in main loop'])
 if not name.startswith('prepare'):
  run=b['raw_runs'][name];assert json.loads(result)==run
  assert len(run['dialog_cycles'])==6 and [r['close_mode'] for r in run['dialog_cycles']]==['submit','cancel','owner_destroy']*2
  assert all([s['index'] for s in r['visible_samples']]==[0,1,2] for r in run['dialog_cycles'])
  ref='502414b3b38e004a6d8d9cb693cf21b65148765a' if name.endswith('-D') else '0249c44636857739a262d10bd7f4e7ed1f713d1c'
  for path,h in run['source_files_sha256'].items():
   raw=((E/'benchmark/develop-D' if name.endswith('-D') else W)/path).read_bytes()
   blob=subprocess.check_output(['git','show',ref+':'+path],cwd=W)
   assert sha(raw)==h and raw.replace(b'\r\n',b'\n')==blob.replace(b'\r\n',b'\n'),path
 rawrows.append({'name':name,'exit':0,'log':sha(log),'result':sha(result),'start':x['started_utc'],'finish':x['finished_utc']})
for g in ['0','8']:
 for rev in ['D','integrated']:
  runs=[r for n,r in b['raw_runs'].items() if n.startswith('g'+g+'-') and n.endswith('-'+rev)]
  for phase in ['cold','steady']:
   ss=[s for r in runs for s in (r['samples'][:1] if phase=='cold' else r['samples'][1:])]
   for key,field in [('processing','processing_seconds'),('button_callback','button_callback_seconds'),('ui_max_heartbeat_gap','max_heartbeat_gap_seconds')]:
    vs=sorted(s[field]*1000 for s in ss);v=b['scenarios'][g][rev][phase][key]
    assert v['n']==len(vs) and abs(v['median_ms']-statistics.median(vs))<1e-9 and abs(v['p95_ms']-vs[math.ceil(len(vs)*.95)-1])<1e-9
   for kind in ['memory_after','memory_sampled_peak']:
    for metric in ['working_set_bytes','private_bytes','process_peak_working_set_bytes']:
     vs=sorted(s[kind][metric] for s in ss);v=b['scenarios'][g][rev][phase][kind][metric]
     assert v['n']==len(vs) and v['median_bytes']==statistics.median(vs) and v['p95_bytes']==vs[math.ceil(len(vs)*.95)-1]
assert sha(z.read('sources/benchmark_review_confirm.py'))==b['harness_sha256']
assert z.read('sources/benchmark_review_confirm.py').replace(b'\r\n',b'\n')==(W/'scripts/benchmark_review_confirm.py').read_bytes().replace(b'\r\n',b'\n')
old=load(W/'docs/evidence/review_confirm_benchmark.json')
for n,r in old['runs'].items():
 assert len(r['samples'])==21
 for key,field in [('processing','processing_seconds'),('button_callback','button_callback_seconds'),('ui_max_heartbeat_gap','max_heartbeat_gap_seconds')]:
  vs=sorted(s[field]*1000 for s in r['samples'][1:]);assert abs(r[key]['median_ms']-statistics.median(vs))<1e-9 and abs(r[key]['p95_ms']-vs[18])<1e-9
snapshot=E/'candidate-evidence/snapshot-20260925T150449.023696Z-0249c4463685';s=load(snapshot/'index.json')
assert sha((snapshot/'index.json').read_bytes())=='eaa0f431af7f68c7311850056033423afb575ba80b60d015bd8d3f33f267db1e'
for x in s['sources']:
 raw=(snapshot/x['file']).read_bytes();assert sha(raw)==x['sha256'] and len(raw)==x['bytes']
known=load(E/'reconstruction/known-findings.json');refs=0
for f in known['findings']+known['preserved_requirement_matrix']:
 for x in f['source_evidence']:
  p=E/'reconstruction'/x['source_file'];raw=p.read_bytes();assert sha(raw)==x['sha256'];lines=raw.decode('utf-8-sig').splitlines();assert x['excerpt'] in lines[x['line']-1],(f['id'],x);refs+=1
out={'result':'PASS evidence arithmetic and source audit only; not gate or reviewer verdict','raw_runs':rawrows,'all_aggregate_timing_and_memory_cells_recomputed':True,'D_and_N_application_source_bindings_verified':True,'raw_sources_in_index_verified':len(s['sources']),'historical_excerpt_source_refs_verified':refs,'legacy_sample_runs_recomputed':list(old['runs']),'legacy_authorization_claim_not_adopted':True}
(R/'provenance-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(out,ensure_ascii=False,indent=2))
