from pathlib import Path
import json,hashlib,zipfile,subprocess,statistics,math,collections,xml.etree.ElementTree as ET
W=Path(r'<LOCAL_REPOSITORY>\tmp\pr29-round5-review1')
E=Path(r'<LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5')
R=E/'reviews/review1'
N='0249c44636857739a262d10bd7f4e7ed1f713d1c';D='502414b3b38e004a6d8d9cb693cf21b65148765a';B='1593e7af65596d320b4427f1b15bb2bc0bdc949c'
def sha(x):return hashlib.sha256(x).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:
  assert k not in d, k
  d[k]=v
 return d
def parse(x):return json.loads(x,object_pairs_hook=unique,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def load(p):return parse(p.read_text(encoding='utf-8-sig'))
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
def stats(vals):
 vals=sorted(vals);return [statistics.median(vals),vals[math.ceil(.95*len(vals))-1]]
result={'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain').decode(),'validation':[],'archives':[],'benchmarks':{}}
assert result['head']==N and result['status']==''
for label in ['develop-oracle','runtime','inventory','unittest','pytest','gui-audit','compile','diff-baseline','diff-develop','status','environment']:
 p=E/'validation'/('candidate3-'+label);r=load(p/'record.json');raw=(p/'raw.log').read_bytes()
 assert r['exit_code']==0 and r['before']['head']['stdout'].strip()==r['after']['head']['stdout'].strip()==N
 assert r['before']['status']['stdout']==r['after']['status']['stdout']==''
 assert r['before']['files_sha256']==r['after']['files_sha256']
 assert sha(raw)==r['log_sha256']
 mismatches=[name for name,h in r['before']['files_sha256'].items() if sha((W/name).read_bytes())!=h and sha(git('show',N+':'+name))!=h]
 assert not mismatches,mismatches
 text=raw.decode('utf-8-sig'); suspicious=[s for s in text.splitlines() if any(x in s for x in ['Exception ignored','Tcl_AsyncDelete','Traceback (most recent','main thread is not in main loop'])]
 assert not suspicious,(label,suspicious)
 result['validation'].append({'label':label,'command':r['command'],'environment':r['environment'],'head':N,'source_count':len(r['before']['files_sha256']),'log_sha256':sha(raw),'elapsed_seconds':r['elapsed_seconds'],'raw_tail':text.splitlines()[-6:]})
i=load(E/'candidate3-test-inventory.json');cases=list(ET.parse(E/'candidate3-pytest.xml').iter('testcase'))
ids=[c.get('classname','').removeprefix('tests.')+'.'+c.get('name','') for c in cases]
assert collections.Counter(ids)==collections.Counter(i['pytest_ids'])
assert set(i['unittest_ids']) <= set(ids) and set(i['gui_ids'])<=set(ids)
assert all(not any(c.find(t) is not None for t in ['skipped','error','failure']) for c in cases)
result['junit']={'cases':len(cases),'unittest_inventory':len(i['unittest_ids']),'gui':len(i['gui_ids']),'pytest_only':len(i['pytest_only']),'sha256':sha((E/'candidate3-pytest.xml').read_bytes())}
for name in ['portable-reconstruction.zip','benchmark-replay-v5.zip']:
 p=W/'docs/evidence/pr29_round5'/name
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  names=z.namelist();assert len(set(names))==len(names)
  assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
  data={n:z.read(n) for n in names if not n.endswith('/')}
  if name.startswith('portable'):
   man=load(W/'docs/evidence/pr29_round5/reconstruction-manifest.json')
   expected={x['file']:x for x in man['files']}
   assert set(data)==set(expected)|{'reconstruction-manifest.json'},(set(data)-set(expected),set(expected)-set(data))
   assert parse(data['reconstruction-manifest.json'].decode('utf8'))==man
  else:
   man=parse(git('show','cf444f4c892a660d36c57b34cbb08bf5a270bd66:docs/evidence/pr29_round5/benchmark-replay-v5.sha256.json'))
   expected=man['entry_manifest'];assert set(data)==set(expected)|{'manifest.json'}
   assert sha(data['manifest.json'])==man['manifest_sha256']
   assert parse(data['manifest.json'])==expected
   assert sha(p.read_bytes())==man['sha256']
  for n,item in expected.items():
   assert len(data[n])==item['bytes'] and sha(data[n])==item['sha256'],n
  for n,raw in data.items():
   if n.endswith('.json'):parse(raw.decode('utf-8-sig'))
  result['archives'].append({'file':name,'sha256':sha(p.read_bytes()),'entries':len(data),'verified_each_entry':True})
bm=load(W/'docs/evidence/review_confirm_round5_benchmark.json')
assert bm['active_batch']=='paired-final-v5'
for name,r in bm['raw_runs'].items():
 assert len(r['samples'])==21 and r['rows']==2000 and r['initial_events']==500
 assert r['environment']==bm['environment'] and r['harness_sha256']==bm['harness_sha256']
 assert [s['operation'] for s in r['samples']]==list(range(21))
 for s in r['samples']:
  assert s['cooldown_seconds']==.5 and s['events_before']==500+s['operation']
 for metric,field in [('processing','processing_seconds'),('button_callback','button_callback_seconds'),('ui_max_heartbeat_gap','max_heartbeat_gap_seconds')]:
  values=stats([s[field]*1000 for s in r['samples'][1:]])
  assert abs(values[0]-r[metric]['median_ms'])<1e-9 and abs(values[1]-r[metric]['p95_ms'])<1e-9
 if name.endswith('integrated'):
  assert all(sha((W/p).read_bytes())==h for p,h in r['source_files_sha256'].items())
  assert all(s['service_timings']['ledger_full_rebuild']==0 for s in r['samples'][1:])
 for relative,h in r['fixture_files_sha256'].items():
  with zipfile.ZipFile(W/'docs/evidence/pr29_round5/benchmark-replay-v5.zip') as z:
   matches=[n for n in z.namelist() if n.endswith('/'+relative) and 'fixtures/g'+str(r['staged_groups'])+'/initial/' in n]
   assert len(matches)==1,(relative,matches)
   assert sha(z.read(matches[0]))==h
for g in [0,8]:
 for revision in ['D','integrated']:
  runs=[r for name,r in bm['raw_runs'].items() if name.startswith('g'+str(g)+'-') and name.endswith('-'+revision)]
  assert len(runs)==5
  assert len({r['fixture_content_sha256'] for r in runs})==1
  for phase in ['cold','steady']:
   samples=[s for r in runs for s in (r['samples'][:1] if phase=='cold' else r['samples'][1:])]
   result['benchmarks'][f'g{g}-{revision}-{phase}']={field:stats([s[field]*1000 for s in samples]) for field in ['processing_seconds','button_callback_seconds','max_heartbeat_gap_seconds']}
   result['benchmarks'][f'g{g}-{revision}-{phase}'].update({m:stats([s['memory_after'][m]/1024**2 for s in samples]) for m in ['working_set_bytes','private_bytes']})
 result['benchmarks'][f'g{g}-fixture_equal']=len({r['fixture_content_sha256'] for name,r in bm['raw_runs'].items() if name.startswith('g'+str(g)+'-')})==1
 result['benchmarks'][f'g{g}-fixture_hashes_equal']=len({json.dumps(r['fixture_files_sha256'],sort_keys=True) for name,r in bm['raw_runs'].items() if name.startswith('g'+str(g)+'-')})==1
old=load(W/'docs/evidence/review_confirm_benchmark.json')
result['old_benchmark_structure']={'keys':list(old),'sha256':sha((W/'docs/evidence/review_confirm_benchmark.json').read_bytes())}
result['known_requirements']=[{k:x.get(k) for k in ['id','title','required_candidate_behavior']} for x in load(E/'reconstruction/known-findings.json')['preserved_requirement_matrix']]
(R/'artifact-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
