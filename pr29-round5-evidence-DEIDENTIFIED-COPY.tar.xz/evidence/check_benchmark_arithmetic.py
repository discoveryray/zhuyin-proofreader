import json,math,statistics,hashlib,pathlib,datetime
E=pathlib.Path(r'<LOCAL_REPOSITORY>\tmp\pr-review-automation\review-confirm-responsive\round5')
W=pathlib.Path(r'<LOCAL_REPOSITORY>\tmp\pr29-round5-worktree')
p=json.loads((W/'docs/evidence/review_confirm_round5_benchmark.json').read_text(encoding='utf-8'))
assert len(p['raw_runs'])==20
checks=[]
for group in ('0','8'):
 for version in ('D','integrated'):
  runs=[v for k,v in p['raw_runs'].items() if k.startswith('g'+group+'-') and k.endswith('-'+version)]
  assert len(runs)==5
  assert all(len(r['samples'])==21 and r['operations']==21 for r in runs)
  assert all(s['cooldown_seconds']==.5 for r in runs for s in r['samples'])
  assert len({r['fixture_content_sha256'] for r in runs})==1
  assert runs[0]['fixture_content_sha256']==p['scenarios'][group]['fixture_content_sha256']
  for phase in ('cold','steady'):
   samples=[s for r in runs for s in (r['samples'][:1] if phase=='cold' else r['samples'][1:])]
   for metric,key in [('processing','processing_seconds'),('button_callback','button_callback_seconds'),('ui_max_heartbeat_gap','max_heartbeat_gap_seconds')]:
    xs=sorted(s[key]*1000 for s in samples)
    calc={'n':len(xs),'median_ms':statistics.median(xs),'p95_ms':xs[math.ceil(.95*len(xs))-1]}
    actual=p['scenarios'][group][version][phase][metric]
    assert all(abs(calc[k]-actual[k])<1e-8 for k in calc),(group,version,phase,metric,calc,actual)
    checks.append({'group':group,'version':version,'phase':phase,'metric':metric,**calc})
 for pair in range(1,6):
  d=p['raw_runs'][f'g{group}-pair{pair}-D'];n=p['raw_runs'][f'g{group}-pair{pair}-integrated']
  assert d['fixture_files_sha256']==n['fixture_files_sha256']
  assert d['harness_sha256']==n['harness_sha256']==p['harness_sha256']
source_witness={}
for k,r in p['raw_runs'].items():
 if k.endswith('-integrated'):
  for f,h in r['source_files_sha256'].items():
   assert hashlib.sha256((W/f).read_bytes()).hexdigest()==h,f
   source_witness[f]=h
assert hashlib.sha256((W/'scripts/benchmark_review_confirm.py').read_bytes()).hexdigest()==p['harness_sha256']
result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'coordinator_arithmetic_and_source_check_not_independent_review','benchmark_file_sha256':hashlib.sha256((W/'docs/evidence/review_confirm_round5_benchmark.json').read_bytes()).hexdigest(),'run_count':20,'metric_checks':checks,'candidate_source_files_sha256':source_witness,'harness_sha256':p['harness_sha256'],'assertions_passed':True,'no_new_measurements':True}
(E/('benchmark-arithmetic-check-'+p['active_batch']+'.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'runs':20,'metric_comparisons':len(checks),'fixture_pairs_equal':10,'source_files':len(source_witness),'success':True}))
