"""Bind measured checkout bytes and preserved source objects to an exact candidate."""
import argparse,datetime,hashlib,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('--head',required=True);a=p.parse_args()
E=pathlib.Path(__file__).resolve().parent;W=pathlib.Path(r'<LOCAL_REPOSITORY>\tmp\pr29-round5-worktree')
B='1593e7af65596d320b4427f1b15bb2bc0bdc949c';H='a38bdf1c84889c52e7281a0c23c9458e3762afa8';D='502414b3b38e004a6d8d9cb693cf21b65148765a'
def raw(*args):return subprocess.check_output(['git',*args],cwd=W)
def git(*args):return raw(*args).decode('utf-8').strip()
def sha(x):return hashlib.sha256(x).hexdigest()
assert git('rev-parse','HEAD')==a.head
assert not git('status','--porcelain=v1')
for old in [B,H,D]:subprocess.run(['git','merge-base','--is-ancestor',old,a.head],cwd=W,check=True)
data=json.loads((W/'docs/evidence/review_confirm_round5_benchmark.json').read_text(encoding='utf-8'))
assert data['active_batch']=='paired-final-v5',data.get('active_batch')
bindings={}
for key,run in data['raw_runs'].items():
 version=a.head if key.endswith('-integrated') else D
 for path,expected in run['source_files_sha256'].items():
  blob=raw('show',version+':'+path)
  if version==a.head:
   measured=(W/path).read_bytes();assert sha(measured)==expected,(key,path)
   assert measured.replace(b'\r\n',b'\n')==blob.replace(b'\r\n',b'\n'),path
   mapping='raw measured checkout; Python text CRLF/LF mapping to committed blob'
  else:
   measured=(E/'benchmark/develop-D'/path).read_bytes();assert sha(measured)==expected,(key,path)
   assert measured.replace(b'\r\n',b'\n')==blob.replace(b'\r\n',b'\n'),path
   mapping='raw measured D export; Python text CRLF/LF mapping to committed blob'
  bindings[version+':'+path]={'measured_raw_sha256':expected,'git_blob_sha256':sha(blob),'git_blob_oid':git('rev-parse',version+':'+path),'mapping':mapping}
assert sha((W/'scripts/benchmark_review_confirm.py').read_bytes())==data['harness_sha256']
result={'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':'review-confirm-responsive','baseline':B,'continuation_start':H,'develop':D,'candidate':a.head,'tree':git('rev-parse',a.head+'^{tree}'),'parents':git('show','-s','--format=%P',a.head).split(),'merge_base_develop':git('merge-base',D,a.head),'contains_start_and_develop':True,'working_tree_clean':True,'benchmark_active_batch':data['active_batch'],'benchmark_measured_before_candidate_commit':True,'benchmark_application_source_bindings':bindings,'harness_measured_raw_sha256':data['harness_sha256'],'normalization_limit':'Only Python source CRLF/LF mapping; fixture and runtime-asset bytes are never normalized. Measurement is not retroactively described as running on an existing commit.','diffs':{name:git('diff','--name-status',start+'..'+a.head).splitlines() for name,start in [('baseline_to_candidate',B),('develop_to_candidate',D),('start_to_candidate',H)]}}
out=E/('candidate-binding-'+a.head[:12]+'.json');assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
for name,start in [('baseline',B),('develop',D)]:
 (E/('candidate-'+name+'-diff.patch')).write_bytes(raw('diff','--binary',start+'..'+a.head))
 (E/('candidate-'+name+'-files.txt')).write_text(git('diff','--name-status',start+'..'+a.head)+'\n',encoding='utf-8')
print(json.dumps({'candidate':a.head,'source_bindings':len(bindings),'output':str(out),'success':True}))
