import pathlib,json,hashlib
E=pathlib.Path(__file__).resolve().parent
W=pathlib.Path(r"<LOCAL_REPOSITORY>\tmp\pr29-round5-worktree")
N="0249c44636857739a262d10bd7f4e7ed1f713d1c"
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
r1=E/"reviews/review1/report.md"; rj=E/"reviews/review1/review.json"
assert sha(r1)=="505b2139e9744caa850dc6707375f6b1ca0f45a99e98424d11a29d0210fb273c"
report=read(rj);assert report["verdict"]=="PASS" and report["head"]==N and report["findings"]==[] and report["reviewer"]=="/root/review1_round5"
text=r1.read_text(encoding="utf-8")
sources={}
def add(key,path,fmt="json",capture=None):
 path=path.resolve();sources[key]={"path":str(path),"sha256":sha(path),"format":fmt,"source_ref":str(path.relative_to(E)) if path.is_relative_to(E) else str(path),"captured_at_utc":capture}
 return key
capture=read(E/"prepush-capture-time.json")["captured_at_utc"]
add("authorization",E/"reconstruction/user-adopted-contract.md","text")
add("history",E/"reconstruction/reconstructed-history.json")
add("mapping",E/"candidate-evidence/test-id-mapping.json")
add("candidate_index",E/"candidate-evidence/snapshot-20260925T150449.023696Z-0249c4463685/index.json")
add("actors",E/"candidate-evidence/candidate3-actual-actors.json")
add("dispatch",E/"review1-dispatch-and-candidate-freeze.json")
add("preflight",E/"preflight.json")
add("implementationN3",E/"implementation-candidate3-commit.json")
add("review1_full",r1,"text");add("review1_json",rj)
add("pr_api",E/"prepush-pr-api.json",capture=capture)
add("direct_refs",E/"prepush-direct-refs.txt","text",capture)
for key in ["issue-comments","review-comments","reviews","ruleset"]:add(key,E/("prepush-"+key+".json"),capture=capture)
add("environment",E/"validation/candidate3-environment/raw.log","text")
add("environment_record",E/"validation/candidate3-environment/record.json")
checks={}
for check,label in [("unittest","unittest"),("pytest","pytest"),("gui","gui-audit"),("runtime","runtime"),("compile","compile"),("diff","diff-baseline")]:
 record=E/("validation/candidate3-"+label+"/record.json")
 obj=read(record)
 assert obj["exit_code"]==0 and obj["source_bytes_unchanged"]
 assert all(obj[phase]["head"]["stdout"].strip()==N and obj[phase]["status"]["stdout"]=="" for phase in ["before","after"])
 add(check+"_record",record);add(check+"_log",record.parent/"raw.log","text")
 checks[check]={"status":"success","source_keys":[check+"_record",check+"_log","candidate_index","review1_full"],"analysis":"Exact N ended execution; original command/env/source witnesses and log hash checked by coordinator and independent R1. All required cases retained. This is not reuse relabelled from N1/N2."}
add("oracle_record",E/"validation/candidate3-develop-oracle/record.json");add("oracle_log",E/"validation/candidate3-develop-oracle/raw.log","text")
add("benchmark_active_index",E/"benchmark/paired-final-v5/run-index.json")
add("benchmark_binding",E/"candidate-binding-0249c4463685.json")
add("benchmark_arithmetic",E/"benchmark-arithmetic-check-paired-final-v5.json")
add("benchmark_policy",W/"docs/REVIEW_CONFIRM_PERFORMANCE.md","text")
checks["performance"]={"status":"success","source_keys":["benchmark_active_index","benchmark_binding","benchmark_arithmetic","benchmark_policy","review1_full"],"active_batch_source_key":"benchmark_active_index","analysis":"Coordinator recomputation and R1 independent complete raw audit support same-environment/same-fixture main staging improvement: steady total median/P95 425.08/587.30 to205.10/237.76ms; heartbeat412.76/571.44 to59.87/67.61. 500ms cooldown retained separately, preview included. Cold0-group regression +143.93ms and memory increases retained/investigated, no all-scenario/throughput/leak-free claim. Measured before commit and exact app bytes mapped to N, not relabelled execution on existing N. No true教材/longterm/EXE acceptance."}
findings=[]
for fid in [*(f"KF-{i:02d}" for i in range(1,8)),*(f"RC-{i:02d}" for i in range(1,5))]:
 rows=[line for line in text.splitlines() if line.startswith("| "+fid+" |")]
 assert len(rows)==1,(fid,rows)
 analysis=rows[0]+" Coordinator adopts this independent R1 candidate assessment after reading full report and raw test/source bindings. Historical resolution/unknown original report contents remain unchanged and unknown."
 if fid=="KF-07":analysis+=" PRE-PUSH ONLY: new local Tk evidence and exact bounded dual-CI requirement verified; actual N312/313 PR CI is still absent and is separately mandatory after push. Historical Tcl root cause is not asserted."
 keys=["review1_full","review1_json","candidate_index","mapping"]
 if fid=="RC-02":keys+=["oracle_record","oracle_log"]
 if fid=="RC-04":keys+=["benchmark_active_index","benchmark_binding","benchmark_arithmetic"]
 findings.append({"id":fid,"status":"verified_on_candidate","source_keys":keys,"analysis":analysis})
assess={"candidate":N,"local_validation":{"platform":"Windows","python_version":"3.13.0","runtime_source_keys":["environment","environment_record"],"checks":checks},"known_findings":findings,"pr_findings":{"checked":True,"new_blockers":[],"source_keys":["pr_api","issue-comments","review-comments","reviews","review1_full"],"analysis":"Fresh explicit first pages per_page100 each empty; no later pages. Existing PR body historical findings retained and mapped above, not discarded because lists empty."},"protection":{"satisfied":False,"source_keys":["pr_api","ruleset","direct_refs"],"analysis":"Conservative prepush predicate: raw mergeable=false, candidate N unpublished and no current-N tested integration/status. This is a coordinator evaluation, not a fabricated API protection_satisfied field or a waiver; no merge authorized."}}
ap=E/"candidate-evidence/prepush-candidate-assessments.json";assert not ap.exists();ap.write_text(json.dumps(assess,ensure_ascii=False,indent=2),encoding="utf-8")
add("assessments",ap)
config={"repo":str(W),"candidate":N,"executing_actor":"/root","active_benchmark_batch":"paired-final-v5","sources":sources,"reviews":[{"record_source":"review1_json","full_report_source":"review1_full"}],"ci":None,"note":"First R1 report originals adopted after actual canonical-session dispatch and full coordinator readback. No current PR CI exists before push. Frozen original four history preserved."}
dest=E/"candidate-evidence/prepush-construction.json";assert not dest.exists();dest.write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps({"manifest":str(dest),"sources":len(sources),"capture":capture}))

