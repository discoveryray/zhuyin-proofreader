# PR29 候選證據公開範圍

本份僅是證據內容與來源審核，不是程式審查 PASS 或完成交付。

依使用者明確採納的第五輪契約，保存 PR29 原始驗證／審查 evidence 與可跨電腦取回的副本；原文已保存在固定 N 的 docs/evidence/pr29_round5_user_adopted_contract.md。

本次逐項檢查原封存的 389 個文字 payload（387 原件及 INDEX/README、254 種獨立內容），除關鍵字檢查，也核对 record 的欄位與環境白名單、JSON task／PR 範圍、全部 JUnit、source code／Git bytes、20 組效能樣本及 raw log 的來源與內容。未發現憑證、私人文件、真教材或正式資料庫內容。

公開集合排除兩份非必要原件：含不相關跨任務記憶索引的內部 checkpoint，以及重複五筆歷史 run 的寬範圍 API 清單。原件留存，沒有改寫；它們不被候選／gate／reviewer 的必要來源引用。公開 INDEX 是縮小集合的新清冊，不能用舊包裝清冊宣稱已包含排除檔案。

剩餘 385 份原件保留 exact bytes／SHA256，包括失敗紀錄。原始 logs／records 含 Windows 測試路徑及帳號目錄；4 份 JUnit XML（含重複副本）含本機 hostname。這些是本任務執行來源的機器中繼資料，不是憑證；為了保留原件 hash，不暗中塗改。環境紀錄僅有 LOCALAPPDATA、TEMP、TMP、PYTHONUTF8、PYTHONIOENCODING、TCL_LIBRARY、TK_LIBRARY、PYTEST_ADDOPTS 八個測試所需欄位，不含完整環境傾印。

未增加任何授權，也不保證未來新增的 evidence 自動符合此範圍。新 CI、第二輪及最終 gate 另行核對並追加。固定候選未變更，沒有 commit／merge。
