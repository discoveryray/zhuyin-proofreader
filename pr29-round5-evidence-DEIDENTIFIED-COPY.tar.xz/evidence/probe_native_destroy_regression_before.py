from pathlib import Path
import hashlib,json,sys,types,unittest
sys.path.insert(0,str(Path.cwd()))
root=Path(__file__).resolve().parent
source=Path("review_gui.py").read_text(encoding="utf-8")
start=source.index("    def _cancel_owned_preview_callbacks(self):")
end=source.index("    def show_sample_preview(self, index):",start)
old="""    def destroy(self):
        self._destroying = True
        if self._visibility_after is not None:
            self.after_cancel(self._visibility_after)
            self._visibility_after = None
        for index in range(len(getattr(self, "_preview_ready_after", []))):
            self._cancel_preview_ready(index)
        super().destroy()

"""
source=source[:start]+old+source[end:]
expected=json.loads((root/"implementation-pre-review-self-check.json").read_text(encoding="utf-8"))["files_sha256"]["review_gui.py"]
raw_current=Path("review_gui.py").read_bytes()
raw_before=source.replace("\n","\r\n").encode("utf-8") if b"\r\n" in raw_current else source.encode("utf-8")
actual=hashlib.sha256(raw_before).hexdigest()
assert actual==expected,(actual,expected)
print("exact pre-fix raw source SHA256",actual)
module=types.ModuleType("review_gui"); module.__file__=str(Path("review_gui.py").resolve())
sys.modules["review_gui"]=module
exec(compile(source,module.__file__,"exec"),module.__dict__)
from tests.test_review_async_save import AsyncOwnerTkTests
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([AsyncOwnerTkTests("test_native_tcl_owner_destroy_cancels_only_owned_preview_callbacks")]))
assert len(result.failures)==1 and not result.errors and not result.skipped,result
assert "owned & pending" in result.failures[0][1],result.failures[0][1]
print("EXPECTED REGRESSION FAILURE verified on exact pre-fix source; current files never changed")
