from pathlib import Path
import hashlib,json,math,statistics
root=Path(r"C:\Work\zhuyin-proofreader-phase4\tmp\pr-review-automation\review-confirm-responsive\round5\benchmark")
runs=root/"paired-final-v5"
candidate=Path(r"C:\Work\zhuyin-proofreader-phase4\tmp\pr29-round5-worktree")
result=json.loads((candidate/"docs/evidence/review_confirm_round5_benchmark.json").read_text(encoding="utf-8"))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
checks=[]
for record in result["run_index"]:
    name=record["name"]
    assert sha(runs/(name+".log"))==record["log_sha256"]
    assert sha(runs/(name+".json"))==record["result_sha256"]
    assert record["exit_code"]==0
    text=(runs/(name+".log")).read_text(encoding="utf-8")
    assert not any(token in text for token in ("Traceback","Exception ignored","Tcl_AsyncDelete","main thread is not in main loop"))
checks.append("22 process exit codes, original log/result hashes and native error markers")
assert sha(candidate/"scripts/benchmark_review_confirm.py")==result["harness_sha256"]
for relative,digest in result["raw_runs"]["g0-pair1-integrated"]["source_files_sha256"].items():
    assert sha(candidate/relative)==digest,(relative,"source drift")
checks.append("Current measured application/fixture/harness source bytes unchanged")
for g in ("0","8"):
    marker=json.loads((root/"paired-final-v4"/f"fixture-g{g}"/"benchmark-fixture.json").read_text(encoding="utf-8"))
    initial={name:hashlib.sha256(bytes.fromhex(value)).hexdigest() for name,value in marker["initial_files_hex"].items()}
    assert initial==result["scenarios"][g]["fixture_files_sha256"]
    for side in ("D","integrated"):
        for phase in ("cold","steady"):
            for key,field in (("processing","processing_seconds"),("button_callback","button_callback_seconds"),("ui_max_heartbeat_gap","max_heartbeat_gap_seconds")):
                data=[]
                for pair in range(1,6):
                    original=json.loads((runs/f"g{g}-pair{pair}-{side}.json").read_text(encoding="utf-8"))
                    data.extend(row[field]*1000 for row in (original["samples"][:1] if phase=="cold" else original["samples"][1:]))
                data.sort()
                summary=result["scenarios"][g][side][phase][key]
                assert summary["n"]==len(data)
                assert summary["median_ms"]==statistics.median(data)
                assert summary["p95_ms"]==data[math.ceil(.95*len(data))-1]
checks.append("Independent recomputation of all cold/steady median/P95 from original per-run files")
checks.append("Full original fixture byte map independently hashed from preparation marker")
out={"checks":checks,"result_file_sha256":sha(candidate/"docs/evidence/review_confirm_round5_benchmark.json"),"harness_sha256":result["harness_sha256"],"D_source_manifest_sha256":result["raw_runs"]["g0-pair1-D"]["source_manifest_sha256"],"integrated_source_manifest_sha256":result["raw_runs"]["g0-pair1-integrated"]["source_manifest_sha256"],"fixtures":{g:result["scenarios"][g]["fixture_content_sha256"] for g in ("0","8")},"scope":"Benchmark consistency audit, not formal PR review or whole-task PASS"}
(root/"aggregate-independent-audit-v5.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(out,ensure_ascii=False,indent=2))
for g in ("0","8"):
 s=result["scenarios"][g]
 print("GROUP",g,"cold/stable memory working/private MB")
 for phase in ("cold","steady"):
  for side in ("D","integrated"):
   print(phase,side,{k:[round(v["median_bytes"]/2**20,2),round(v["p95_bytes"]/2**20,2)] for k,v in s[side][phase]["memory_after"].items()})
 print("N cold stage medians",{k:round(statistics.median(r["samples"][0]["service_timings"].get(k,0) for n,r in result["raw_runs"].items() if n.startswith("g"+g+"-") and n.endswith("-integrated"))*1000,2) for k in result["raw_runs"][f"g{g}-pair1-integrated"]["samples"][0]["service_timings"]})
