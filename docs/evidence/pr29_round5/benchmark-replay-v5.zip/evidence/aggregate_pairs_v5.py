from pathlib import Path
import datetime, hashlib, json, math, statistics
base=Path(r"C:\Work\zhuyin-proofreader-phase4\tmp\pr-review-automation\review-confirm-responsive\round5\benchmark")
root=base/"paired-final-v5"
candidate=Path(r"C:\Work\zhuyin-proofreader-phase4\tmp\pr29-round5-worktree")
index=json.loads((root/"run-index.json").read_text(encoding="utf-8"))
assert len(index)==22 and all(r["exit_code"]==0 for r in index)
metrics={"processing":"processing_seconds","button_callback":"button_callback_seconds","ui_max_heartbeat_gap":"max_heartbeat_gap_seconds"}
memory_fields=("working_set_bytes","private_bytes","process_peak_working_set_bytes")
def stats(values, unit):
    values=sorted(values)
    return {"n":len(values),"median_"+unit:statistics.median(values),
      "p95_"+unit:values[math.ceil(len(values)*.95)-1],"min_"+unit:min(values),"max_"+unit:max(values)}
raw={}
for groups in (0,8):
    for pair in range(1,6):
        for side in ("D","integrated"):
            name=f"g{groups}-pair{pair}-{side}"
            raw[name]=json.loads((root/(name+".json")).read_text(encoding="utf-8"))
assert len({r["harness_sha256"] for r in raw.values()})==1
assert len({json.dumps((r["environment"],r["python"],r["platform"]),sort_keys=True) for r in raw.values()})==1
for side in ("D","integrated"):
    assert len({r["source_manifest_sha256"] for n,r in raw.items() if n.endswith("-"+side)})==1
scenarios={}
for groups in (0,8):
    runs_group=[r for n,r in raw.items() if n.startswith(f"g{groups}-")]
    assert len({r["fixture_content_sha256"] for r in runs_group})==1
    assert len({json.dumps(r["fixture_files_sha256"],sort_keys=True) for r in runs_group})==1
    assert len({r["fixture_marker_sha256"] for r in runs_group})==1
    group={"fixture_content_sha256":runs_group[0]["fixture_content_sha256"],
           "fixture_files_sha256":runs_group[0]["fixture_files_sha256"]}
    for side in ("D","integrated"):
        runs=[raw[f"g{groups}-pair{pair}-{side}"] for pair in range(1,6)]
        for run in runs:
            assert (run["rows"],run["initial_events"],run["staged_groups"],run["operations"])==(2000,500,groups,21)
            assert len(run["samples"])==21 and len(run["dialog_cycles"])==6
            assert all(s["events_before"]==500+i and s["cooldown_seconds"]==.5 for i,s in enumerate(run["samples"]))
            assert all(len(c["visible_samples"])==3 for c in run["dialog_cycles"])
        summary={}
        for phase in ("cold","steady"):
            samples=[sample for run in runs for sample in (run["samples"][:1] if phase=="cold" else run["samples"][1:])]
            summary[phase]={name:stats([s[field]*1000 for s in samples],"ms") for name,field in metrics.items()}
            summary[phase]["memory_after"]={field:stats([s["memory_after"][field] for s in samples],"bytes") for field in memory_fields}
            summary[phase]["memory_sampled_peak"]={field:stats([s["memory_sampled_peak"][field] for s in samples],"bytes") for field in memory_fields}
        summary["lifecycle_memory"]={stage:{field:stats([r["memory"][stage][field] for r in runs],"bytes")
          for field in memory_fields} for stage in ("before_gui","after_gui","after_saves","after_destroy")}
        summary["dialog_memory"]={
          "cycles":{str(cycle):{field:stats([r["dialog_cycles"][cycle]["after_close"][field] for r in runs],"bytes")
                    for field in memory_fields} for cycle in range(6)},
          "last_minus_first_close":{field:stats([r["dialog_cycles"][-1]["after_close"][field]-r["dialog_cycles"][0]["after_close"][field]
                     for r in runs],"bytes") for field in memory_fields}}
        steady=[s for r in runs for s in r["samples"][1:]]
        summary["stages_inclusive"]={key:stats([s["stage_seconds"].get(key,0)*1000 for s in steady],"ms")
            for key in sorted({key for s in steady for key in s["stage_seconds"]})}
        summary["service_stages"]={key:stats([s["service_timings"].get(key,0)*1000 for s in steady],"ms")
            for key in sorted({key for s in steady for key in s["service_timings"]})}
        group[side]=summary
    group["paired_steady_median_ratios_integrated_over_D"]={}
    for metric,field in metrics.items():
        ratios=[]
        for pair in range(1,6):
            before=statistics.median(s[field] for s in raw[f"g{groups}-pair{pair}-D"]["samples"][1:])
            after=statistics.median(s[field] for s in raw[f"g{groups}-pair{pair}-integrated"]["samples"][1:])
            ratios.append(after/before)
        group["paired_steady_median_ratios_integrated_over_D"][metric]={"ratios":ratios,**stats(ratios,"ratio")}
    scenarios[str(groups)]=group
result={
 "schema":1,"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "task":"review-confirm-responsive","round":5,"repository":"discoveryray/zhuyin-proofreader","pr_number":29,
 "baseline":"1593e7af65596d320b4427f1b15bb2bc0bdc949c",
 "comparison_before":"502414b3b38e004a6d8d9cb693cf21b65148765a",
 "comparison_after":"round5-integrated-after-native-destroy-fix-uncommitted-source-manifest",
 "candidate_binding":"The measured application sources and fixture constructor must match source_files_sha256 at the reviewed commit; no commit SHA is retroactively claimed for the time of measurement.",
 "harness_sha256":next(iter(raw.values()))["harness_sha256"],
 "method":{"fresh_process_pairs_per_scenario":5,"order":"odd pair D then integrated; even pair integrated then D",
 "rows":2000,"initial_events":500,"groups":[0,8],"operations_per_process":21,
 "cold":"First save with fresh application/service; OS filesystem caches are not flushed.",
 "steady":"Operations 2-21 pooled across five processes: n=100 correlated operations, not 100 independent experiments.",
 "p95":"Nearest rank; cold n=5 P95 is the maximum and has limited tail precision.",
 "fixture":"All captured input files, DB, staging and real initialized delivery lock restored to identical bytes before every fresh process; preparation is outside measured processes.",
 "timing":"Native Tk button invoke through saved and refreshed UI, full preview retained; 500ms production cooldown waited separately; 10ms heartbeat.",
 "memory":"Windows GetProcessMemoryInfo process working set, private bytes and process peak working set; heartbeat/boundary sampling; private-byte peak is sampled only.",
 "dialog":"Six native three-position PDF preview cycles per process, A and peers selected only via enabled checkbox invoke after actual target render and scroll; submit/cancel/owner destroy each twice; display-only group not persisted; no forced GC.",
 "quiet_window":"Other agent heavy tests paused; no claim of exclusive control over unrelated operating-system work.",
 "scope":"Synthetic native automation, not human visual acceptance or real-textbook/decoder throughput."},
 "environment":next(iter(raw.values()))["environment"],"python":next(iter(raw.values()))["python"],
 "platform":next(iter(raw.values()))["platform"],
 "scenarios":scenarios,"raw_runs":raw,"run_index":index,
 "excluded_attempts":{"location":"round5/benchmark outside paired-final-v4","reason":
 "Smoke probe initially requested absent optional pytest-subtests metadata; changed to enumerate installed distributions. The first formal batch stopped before g0 pair2 timing because N's real project_delivery_lock creates a lock even when no staging exists. Initialized it through the real context manager before new fixture snapshots; reran all pairs in paired-final-v4 with a fixed cached ctypes API. The intermediate paired-final batch was also excluded after identifying per-call dynamic ctypes type-cache allocations; the final instrument passed a 10000-call probe with no type or memory growth. All previous raw files retained, none pooled here."}}
prior_path=base/"paired-final-v4"/"aggregate-before-native-destroy-fix.json"
result["previous_source_measurements"]=[{
 "source_label":"pre-native-destroy-fix integrated working source",
 "reason":"Source changed before first formal review: ActualReadingDialog now cancels owned preview/visibility callbacks when Tcl-native ancestor destruction bypasses the Python destroy override. Preserve v4 as its own source measurement; full twenty-process v5 rerun uses identical fixture bytes and unchanged harness.",
 "aggregate_sha256":hashlib.sha256(prior_path.read_bytes()).hexdigest(),
 "aggregate":json.loads(prior_path.read_text(encoding="utf-8"))}]
result["fixture_source_directory"]="paired-final-v4: exact existing fixture bytes reused by paired-final-v5"
result["active_batch"]="paired-final-v5"
out=candidate/"docs/evidence/review_confirm_round5_benchmark.json"
out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8",newline="\n")
for g,s in scenarios.items():
    print("GROUP",g)
    for phase in ("cold","steady"):
        for metric in metrics:
            a=s["D"][phase][metric]; b=s["integrated"][phase][metric]
            print(phase,metric,round(a["median_ms"],2),round(a["p95_ms"],2),"->",round(b["median_ms"],2),round(b["p95_ms"],2))
    print("paired ratios",s["paired_steady_median_ratios_integrated_over_D"])
    for side in ("D","integrated"):
        print(side,"memory_MB",
         {stage:{f:round(v["median_bytes"]/2**20,2) for f,v in data.items()} for stage,data in s[side]["lifecycle_memory"].items()})
        print(side,"dialog_private_MB",
         [round(s[side]["dialog_memory"]["cycles"][str(c)]["private_bytes"]["median_bytes"]/2**20,2) for c in range(6)])
print("saved",out,"sha256",hashlib.sha256(out.read_bytes()).hexdigest())
