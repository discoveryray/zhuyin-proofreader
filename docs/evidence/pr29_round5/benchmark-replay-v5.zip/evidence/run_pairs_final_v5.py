from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
root=Path(r"C:\Work\zhuyin-proofreader-phase4\tmp\pr-review-automation\review-confirm-responsive\round5\benchmark\paired-final-v5")
root.mkdir(exist_ok=False)
candidate=Path(r"C:\Work\zhuyin-proofreader-phase4\tmp\pr29-round5-worktree")
harness=candidate/"scripts/benchmark_review_confirm.py"
python=Path(r"C:\Work\zhuyin-proofreader-phase4\tmp\pr29-validation-env\Scripts\python.exe")
d="502414b3b38e004a6d8d9cb693cf21b65148765a"
env=os.environ.copy()
env.update(PYTHONUTF8="1",PYTHONIOENCODING="utf-8",
 TCL_LIBRARY=r"C:\Users\discoveryray\AppData\Local\Programs\Python\Python313\tcl\tcl8.6",
 TK_LIBRARY=r"C:\Users\discoveryray\AppData\Local\Programs\Python\Python313\tcl\tk8.6")
records=[]
harness_hash=hashlib.sha256(harness.read_bytes()).hexdigest()
def invoke(name, repository, label, groups, prepare=False):
    if hashlib.sha256(harness.read_bytes()).hexdigest()!=harness_hash:
        raise RuntimeError("Harness changed during paired run")
    result_path=root/(name+".json")
    log_path=root/(name+".log")
    if result_path.exists() or log_path.exists(): raise RuntimeError("Refusing to overwrite run "+name)
    isolated=root/"isolated-localappdata"/name
    isolated.mkdir(parents=True,exist_ok=False)
    env["LOCALAPPDATA"]=str(isolated)
    command=[str(python),str(harness),"--repository",str(repository),"--revision-label",label,
     "--rows","2000","--events","500","--groups",str(groups),"--operations","21","--dialog-cycles","6",
     "--fixture",str(root.parent/"paired-final-v4"/f"fixture-g{groups}"),"--output",str(result_path)]
    if prepare: command.append("--prepare-fixture-only")
    record={"name":name,"command":command,"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
      "localappdata":str(isolated),"harness_sha256":harness_hash}
    print("START "+name,flush=True)
    started=time.monotonic()
    with log_path.open("wb") as log:
        process=subprocess.run(command,cwd=candidate,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(exit_code=process.returncode,elapsed_seconds=time.monotonic()-started,
      finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
      log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest())
    if result_path.exists(): record["result_sha256"]=hashlib.sha256(result_path.read_bytes()).hexdigest()
    records.append(record)
    (root/"run-index.json").write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding="utf-8")
    print("FINISH "+name+" exit="+str(process.returncode),flush=True)
    if process.returncode: raise RuntimeError("Failed "+name+"; inspect saved raw log")
for groups in (0,8):
    invoke(f"prepare-g{groups}",root.parent/"develop-D",d,groups,True)
for groups in (0,8):
    for pair in range(1,6):
        order=("D","integrated") if pair%2 else ("integrated","D")
        for side in order:
            invoke(f"g{groups}-pair{pair}-{side}",root.parent/"develop-D" if side=="D" else candidate,
             d if side=="D" else "round5-integrated-after-native-destroy-fix-uncommitted-source-manifest",groups)
print("ALL PAIRED RUNS FINISHED",flush=True)
