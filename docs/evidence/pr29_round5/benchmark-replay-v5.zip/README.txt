PR29 round5 performance replay evidence, active batch paired-final-v5.

No production Global database or private textbook is included. All fixture data
is synthetic. The candidate JSON contains the full active twenty-run samples
and the entire prior-source v4 aggregate, so those large JSONs are not duplicated
in this archive. Git provides D and the subsequently bound reviewed candidate.

EXACT original fixture directories:
C:/Work/zhuyin-proofreader-phase4/tmp/pr-review-automation/review-confirm-responsive/round5/benchmark/paired-final-v4/fixture-g0
C:/Work/zhuyin-proofreader-phase4/tmp/pr-review-automation/review-confirm-responsive/round5/benchmark/paired-final-v4/fixture-g8

For exact-byte replay, use only new, dedicated empty directories at those
original paths. Copy each fixtures/gN/initial/ subtree to the corresponding
directory and copy fixtures/gN/benchmark-fixture.json beside its files. Do not
overwrite unrelated files. Verify every byte against manifest.json before use.
The fixture manifests contain absolute PDF/XLSX paths and integrity seals.
Changing those paths changes the bytes/seal: regenerate a fresh shared fixture
and label it as NEW, never claim it matches this original fixture.

Use the archived harness (SHA in manifest), Windows Python3.13.0 and recorded
dependencies/Tcl/Tk/screen configuration. Isolate LOCALAPPDATA/Global. Run the
same harness against D=502414b3b38e004a6d8d9cb693cf21b65148765a and the reviewed
candidate whose application bytes match the active source manifest. The runner
contains original absolute interpreter/output paths and is a command record;
a replay must use new output directories, never overwrite original evidence.
The first and last source/fixture checks inside the harness must still pass.
Source labels remain uncommitted-at-measurement labels, not retroactive SHA claims.

Cold is first save in a fresh service, not a flushed filesystem cache. Five
fresh-process pairs/scenario, 21 operations each, 0/8 staged groups. Alternating
D/N order. The 500ms cooldown and real PDF previews remain enabled. Dialog owner
close in this harness uses Python owner.destroy; the Tcl-native ancestor path
is validated by separate native regression tests.

File contents and exact marker bytes are retained. ZIP metadata timestamps do
not form part of the fixture content contract. No tests or measurements need
rerunning merely to unpack/inspect this archive.
