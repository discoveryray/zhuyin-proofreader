# PR29 已知歷史 finding 與新候選驗證矩陣

建立時間（UTC）：2026-09-25T12:58:29.165950+00:00

下列 KF ID 是本次整理 ID，非遺失原報告的 finding ID。任何『修正 commit』只表示可讀的程式差異，不代替原 finding resolution。
所有新候選結果均 pending；舊 PASS 不沿用。七份缺失報告未知內容保持未知；本文件不發出審查結論。

## KF-01 Known actual/rule drift must survive cache invalidation and retry

分類：code_behavior_reconstructed

Keep content-hash evidence anchor independent of disposable computation cache across retry, write failure, defer/revisit/reload/service replacement. Only a fully revalidated new sealed session may reanchor; legitimate durable actual refresh stays possible.

歷史 code prestate：`e53f44d2da29b46dfe0bd0f2c06af9919808b99f`；可讀修正 commit：`89e0297bd6e5b9b08d077b2216029fb6224976fc`。
限制：Later H report summary plus real code delta identifies behavior, not missing original finding text/ID/reviewer association.

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:57](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> - 每次保存讀取完整依賴 bytes/hash，驗證 session/schema、PDF、actual/candidate artifacts 與 runtime asset roster，保存前重核對。既有 evidence anchor 在普通 cache eviction、write failure、defer/revisit/reload 後保留；已知 actual/rule drift 不會因重試被清除。沒有新增 first-open/pipeline fingerprint 契約。

來源 [sources/prior/commit-89e0297.diff:2324](sources/prior/commit-89e0297.diff)（SHA256 `1432832f36211aef9637a351165fa7f85c271b9ef6d74714195a33fd5ca95e10`）：

> +class ReviewEvidenceAnchor:

來源 [sources/prior/commit-89e0297.diff:2262](sources/prior/commit-89e0297.diff)（SHA256 `1432832f36211aef9637a351165fa7f85c271b9ef6d74714195a33fd5ca95e10`）：

> +        # Evict computation only. A rejected evidence change remains rejected

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_save_service.py:102](sources/git/H/tests/test_review_save_service.py) `test_actual_evidence_external_change_invalidates_cache`
- `H` [tests/test_review_save_service.py:118](sources/git/H/tests/test_review_save_service.py) `test_external_rule_change_and_explicit_reload_invalidation`
- `H` [tests/test_review_save_service.py:142](sources/git/H/tests/test_review_save_service.py) `test_changed_sealed_snapshot_requires_full_validation_before_reanchor`
- `H` [tests/test_review_save_service.py:167](sources/git/H/tests/test_review_save_service.py) `test_failed_first_write_keeps_verified_anchor_and_unchanged_source_can_retry`
- `H` [tests/test_review_async_save.py:320](sources/git/H/tests/test_review_async_save.py) `test_evidence_rejection_survives_retry_reload_and_defer_revisit`
- `H` [tests/test_review_async_save.py:376](sources/git/H/tests/test_review_async_save.py) `test_ordinary_write_failure_can_retry_with_same_evidence_anchor`
- `H` [tests/test_review_async_save.py:394](sources/git/H/tests/test_review_async_save.py) `test_real_actual_transaction_refresh_allows_verified_new_snapshot`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## KF-02 Destroying save/actual owner must cancel only owned polling callbacks

分類：code_behavior_reconstructed

Owner destroy invalidates pending publication and cancels its own timers; unrelated callbacks remain. A worker may finish durable save, which must reopen correctly without publishing to destroyed owner. Keep success/failure poll disposal.

歷史 code prestate：`e53f44d2da29b46dfe0bd0f2c06af9919808b99f`；可讀修正 commit：`89e0297bd6e5b9b08d077b2216029fb6224976fc`。
限制：Later H report summary plus real code delta identifies behavior, not missing original finding text/ID/reviewer association.

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md:95](sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md)（SHA256 `7ebc63befe1bcfe111b3d8f438a39e76d32cff05f10aed6cee33e90d58850ff6`）：

> - Worker 顯式 call chain 不執行 Tk/PhotoImage/PyMuPDF rendering；queue polling 和 Tk resource disposal 由 owner main thread負責。已銷毀 owner 只取消其 timers，未取消無關 widget callbacks。

來源 [sources/prior/commit-89e0297.diff:2230](sources/prior/commit-89e0297.diff)（SHA256 `1432832f36211aef9637a351165fa7f85c271b9ef6d74714195a33fd5ca95e10`）：

> +    def _dispose_async(self, event):

來源 [sources/prior/commit-89e0297.diff:2239](sources/prior/commit-89e0297.diff)（SHA256 `1432832f36211aef9637a351165fa7f85c271b9ef6d74714195a33fd5ca95e10`）：

> +        # The worker may still finish its durable write. It never touches Tk;

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_async_save.py:265](sources/git/H/tests/test_review_async_save.py) `test_project_generation_and_review_id_reject_stale_saved_result`
- `H` [tests/test_review_async_save.py:452](sources/git/H/tests/test_review_async_save.py) `test_disposed_save_owner_cancels_only_owned_poll_and_saved_work_reopens`
- `H` [tests/test_review_async_save.py:492](sources/git/H/tests/test_review_async_save.py) `test_actual_poll_owner_disposal_cancels_pending_timer`
- `H` [tests/test_review_async_save.py:504](sources/git/H/tests/test_review_async_save.py) `test_actual_success_and_failure_release_owned_poll`
- `H` [tests/test_review_async_save.py:523](sources/git/H/tests/test_review_async_save.py) `test_save_completion_and_failure_release_owned_poll`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## KF-03 Expected followup regression fixture must model asynchronous publication

分類：code_behavior_reconstructed

Followup explanation belongs to completed published save and retains failed-refresh guard; expected mismatch must not auto-open six-gate confirmation. Keep tests modeling explain_expected callback and do not remove safety assertions.

歷史 code prestate：`e53f44d2da29b46dfe0bd0f2c06af9919808b99f`；可讀修正 commit：`89e0297bd6e5b9b08d077b2216029fb6224976fc`。
限制：Later H report summary plus real code delta identifies behavior, not missing original finding text/ID/reviewer association.

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md:98](sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md)（SHA256 `7ebc63befe1bcfe111b3d8f438a39e76d32cff05f10aed6cee33e90d58850ff6`）：

> 回歸不只有 current implementation equality：本人從原 baseline Git object 編譯原 materialize_ledger 為 oracle，並證明五個依賴 helper AST 未變；六個 event/overwrite/undo/exclusion cases 與原 oracle 相等、actual/identity 不變；三個無效 transition 拒絕。既有 assertions 亦分別檢查 independently expected state、durable bytes、checked roster、thread identity、stale refusal、UI success flags。歷史 e53 anchor/poll/followup、bb4 Tk ownership/progress fixture、bd6 invalid-root findings 的場景均在本 HEAD 審查及適用 regressions 中核對，舊 reports 不刪除、不以新 CI 清除原 code report。

來源 [sources/prior/commit-89e0297.diff:2454](sources/prior/commit-89e0297.diff)（SHA256 `1432832f36211aef9637a351165fa7f85c271b9ef6d74714195a33fd5ca95e10`）：

> +            # Model the asynchronous completion callback: followup belongs to

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_hotfix_tone_and_followup_v531.py:81](sources/git/H/tests/test_hotfix_tone_and_followup_v531.py) `test_expected_still_mismatch_warns_but_does_not_auto_open_six_gate`
- `H` [tests/test_hotfix_tone_and_followup_v531.py:105](sources/git/H/tests/test_hotfix_tone_and_followup_v531.py) `test_saved_mismatch_without_successful_refresh_has_no_normal_followup`
- `H` [tests/test_hotfix_tone_and_followup_v531.py:124](sources/git/H/tests/test_hotfix_tone_and_followup_v531.py) `test_expected_match_does_not_open_six_gate_followup`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## KF-04 Tk Variables/PhotoImages/widget cycles must release on owner thread before worker GC

分類：code_behavior_reconstructed

Preserve explicit master ownership and Destroy cleanup of dialogs/previews/canvas/ActionRows. PR31 integration must add its new preview-ready/visibility timers, callbacks, buttons and peer lifecycle to resource tests. Tests use actual visible-preview then checkbox invocation, retaining weakref/finalizer-thread/worker-GC assertions.

歷史 code prestate：`89e0297bd6e5b9b08d077b2216029fb6224976fc`；可讀修正 commit：`bb4c136fbc49c706fecfd48d1dacf81b4d97584e`。
限制：Commit bb4c136 changes predecessor 89e0297 Tk lifetime handling. Later report groups 'bb4 Tk ownership/progress fixture'; missing original report prevents exact original finding/session attribution.

來源 [sources/prior/commit-bb4c136.diff:2274](sources/prior/commit-bb4c136.diff)（SHA256 `ba9c0344eb7b0b9aa7321692b2269d436b89d1c38fe14dc0f4e662eea14e75b8`）：

> +class _ReviewDialog(tk.Toplevel):

來源 [sources/prior/commit-bb4c136.diff:2243](sources/prior/commit-bb4c136.diff)（SHA256 `ba9c0344eb7b0b9aa7321692b2269d436b89d1c38fe14dc0f4e662eea14e75b8`）：

> +            # Tcl images and callback-held dialog variables must be released on

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:61](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> - 新 save worker 的 call path 不操作 Tk、PhotoImage 或 PDF renderer；queue 排序在 worker，render 留在 main。save/actual polls 由 Tk owner 管理，銷毀取消自身 callbacks。native tests 實際驗證 destroyed dialogs/preview/完整 root 的 Variable/Image 釋放、worker GC、無外部 root reference、durable recovery、keyboard repetition、preview failure 與無關 timers 保留；production 沒有改全域 GC 或用 skip 隱藏問題。

來源 [sources/prior/remote/job-106598564776.log:316](sources/prior/remote/job-106598564776.log)（SHA256 `9ec9c844455179b5f266836abe181a208aaf8c60fea13d5d92ee9bcbf73cb353`）：

> 2026-09-22T02:59:45.0409709Z ..............................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................Exception ignored in: <function Variable.__del__ at 0x0000021B6A1E00E0>

來源 [sources/prior/remote/job-106598564776.log:321](sources/prior/remote/job-106598564776.log)（SHA256 `9ec9c844455179b5f266836abe181a208aaf8c60fea13d5d92ee9bcbf73cb353`）：

> 2026-09-22T02:59:45.0425464Z RuntimeError: main thread is not in main loop

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_async_save.py:538](sources/git/H/tests/test_review_async_save.py) `test_submitted_expected_variables_release_on_main_before_save_worker_gc`
- `H` [tests/test_review_async_save.py:586](sources/git/H/tests/test_review_async_save.py) `test_submit_cancel_and_owner_destroy_release_dialog_variables_and_photos`
- `H` [tests/test_review_async_save.py:636](sources/git/H/tests/test_review_async_save.py) `test_owner_close_releases_preview_before_pending_save_worker_collects`
- `H` [tests/test_review_async_save.py:667](sources/git/H/tests/test_review_async_save.py) `test_real_root_and_prior_dialogs_release_before_expected_or_actual_worker_gc`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## KF-05 Held actual-progress UI fixture must initialize production prerequisites

分類：code_behavior_reconstructed

Keep output_dir initialized in UI-only held worker fixture and assert showerror not called, thread start called and actual service not called; bar/text visibility tests must really reach production progress dialog.

歷史 code prestate：`bb4c136fbc49c706fecfd48d1dacf81b4d97584e`；可讀修正 commit：`bd6b4789a646f8bed075c256447f54922a5c4f90`。
限制：Later H report summary plus real code delta identifies behavior, not missing original finding text/ID/reviewer association.

來源 [sources/prior/commit-bd6b478.diff:17](sources/prior/commit-bd6b478.diff)（SHA256 `71109bde172fbf64e2b8c983bbf6cc694077f1e58169c8bce0113591b3f5b5b8`）：

> +    app.output_dir = Path("ui-only-held-progress-project")

來源 [sources/prior/commit-bd6b478.diff:25](sources/prior/commit-bd6b478.diff)（SHA256 `71109bde172fbf64e2b8c983bbf6cc694077f1e58169c8bce0113591b3f5b5b8`）：

> +        error.assert_not_called()

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:89](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> 舊失敗原始證據也有親查：`review1-e53f44d/reviewer-stale-retry-matrix.log`、`reviewer-native-poll.log`/`reviewer-native-poll-unsandboxed.log`、`investigate-adversarial-dialog-gc.log`、`review1-bb4c136-progress-fixture-probe.log` 與 `review2-bb4c136-progress-probe.py`、`review2-bd6b478-db-root-probe.py/.log`。本輪不是照抄舊 PASS；相關修正於新 HEAD 重新完整審查/驗證。較早 `corrective3-full-pytest.log` 的 Tcl theme skip 及 exact retry 原文亦看過，沒有把舊 HEAD 的結果當本 HEAD full pytest/CI PASS，也未宣稱已證明其環境根因。

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_visual_corrective_v580.py:169](sources/git/H/tests/test_review_visual_corrective_v580.py) `test_actual_apply_progress_constructor_keeps_bar_visible_and_text_readable`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## KF-06 Non-object durable JSON root must be rejected before normalization/replay/write

分類：code_behavior_reconstructed

Cold/warm/replacement/retry reject falsy and truthy scalar/list roots, malformed and duplicate-key JSON without changing disk bytes, queue, index or last_saved flags. Missing DB and valid empty object preserve initialization; original version normalization/future-schema rejection stay intact.

歷史 code prestate：`bd6b4789a646f8bed075c256447f54922a5c4f90`；可讀修正 commit：`a38bdf1c84889c52e7281a0c23c9458e3762afa8`。
限制：Later H report summary plus real code delta identifies behavior, not missing original finding text/ID/reviewer association.

來源 [sources/prior/commit-a38bdf1.diff:2217](sources/prior/commit-a38bdf1.diff)（SHA256 `54b899aa9f76932e0bfc8ccbaf337d55bf41850931db2c5477e13e9eb8c10eaf`）：

> +            if not isinstance(raw_db, dict):

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:58](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> - 最新 root validation 在 normalization 之前拒絕所有非 object durable JSON。獨立 probe 除既有五種 falsy root 外加非空 list、數字、true、非空字串，共九種 root，跨 repeat/service replacement 全部拒絕且 bytes 不變；恢復有效 bytes 可保存。未知 ID、非法 action、缺 expected proof 也拒絕且不改 DB。Missing DB/合法空物件、舊 version normalization、future schema/legacy rejection 由已讀並執行的 regression 覆蓋。

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_save_service.py:246](sources/git/H/tests/test_review_save_service.py) `test_non_object_db_roots_reject_before_replay_and_write_in_cold_and_warm_cache`
- `H` [tests/test_review_save_service.py:284](sources/git/H/tests/test_review_save_service.py) `test_missing_and_empty_object_databases_keep_initialization_contract`
- `H` [tests/test_review_save_service.py:300](sources/git/H/tests/test_review_save_service.py) `test_object_root_preserves_version_normalization_and_schema_rejection`
- `H` [tests/test_review_async_save.py:190](sources/git/H/tests/test_review_async_save.py) `test_corrupt_db_root_never_publishes_or_advances_and_valid_bytes_restore_retry`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## KF-07 Historical CI capability/evidence failures are not code fixes or extra corrective rounds

分類：historical_ci_capability_or_evidence_limit

New N requires its own actual Windows 3.12/3.13 full unittest plus full pytest/GUI/runtime/compile/diff job and log evidence. Runner-not-started attempts have no tested SHA. Preserve historical Tcl setup failure; a successful rerun does not identify its root cause. Investigate new failures before classification.

歷史 code prestate：`['89e0297bd6e5b9b08d077b2216029fb6224976fc', 'a38bdf1c84889c52e7281a0c23c9458e3762afa8']`；可讀修正 commit：`None`。
限制：Historical R2 full report plus preserved raw CI identify attempt failures; no current code defect or exact root cause is inferred.

來源 [sources/prior/remote/job-106598564548.log:445](sources/prior/remote/job-106598564548.log)（SHA256 `a68c2a8d3529bd402c9532c8df8fcb6247b9d488b0607066d9ae698212e06b23`）：

> 2026-09-22T03:28:05.8457997Z E       _tkinter.TclError: Can't find a usable init.tcl in the following directories: 

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:99](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> 正式交付前收到並親讀最新平台原始證據 `ci-a38bdf1-attempt2-api.json`、`ci-a38bdf1-platform-checks-attempt2-native.log`：PR run `35690849530` attempt `2`、head `a38bdf1...` 為 completed/failure；Python 3.13 job `106630235508` 與 Python 3.12 job `106630235654` 均為 runner_id 0、steps 為空，annotation 明載 account payments/spending limit 導致 job 未啟動。這不是 code defect 的證據，也不存在可冒稱的 tested checkout SHA。此 CI 平台能力缺口阻擋第二輪 CI 門檻與任務交付完成，須由 coordinator/第二輪保留正式 non-code BLOCKED、待平台能力恢復後取得最新適用原始 CI 並完整補審。本第一輪 source verdict 不清除此限制，不授權改 billing/settings、空 commit 或第五輪修正。

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md:60](sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md)（SHA256 `7ebc63befe1bcfe111b3d8f438a39e76d32cff05f10aed6cee33e90d58850ff6`）：

> Attempt3 實際執行：Python 3.12 全部成功；Python 3.13.15 unittest 710/859.207s OK，pytest 773 passed、4 setup errors、877 subtests passed/948.63s。四 errors 共用 `tests/test_review_visual_corrective_v580.py:88` 的 `CorrectiveTkTests.setUpClass → tk.Tk()`，Tcl 讀取 hosted Python 的 `tcl8.6/init.tcl` 時回「couldn't read file ...: No error」，尚未進入 test body。此 setup 相對 baseline 未修改。該次其他 native Tk 測試及 unittest 成功，不能推論 Tcl 整體未安裝、固定不可用或程式必然有缺陷。

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md:64](sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md)（SHA256 `7ebc63befe1bcfe111b3d8f438a39e76d32cff05f10aed6cee33e90d58850ff6`）：

> 協調者經精確 preflight，在 source/test/workflow 不變的同 HEAD 只做一次完整 matrix rerun；HTTP201 原始證據 `ci-a38bdf1-controlled-rerun.json/.log` 已親讀。Attempt4 兩版都重新執行全部 suites，四個先前 setup error 對應測試亦包含於零 skip 的 777 passed。這補齊本輪最新必要 CI 的實際執行證據；**未證實 attempt3 的底層讀取失敗根因，也不宣稱修復某個平台缺陷**。它不是 code corrective cycle，未用 rerun 或無關 PASS 清除歷史 code finding。

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_visual_corrective_v580.py:124](sources/git/H/tests/test_review_visual_corrective_v580.py) `test_real_expected_and_actual_form_labels_converge_at_narrow_and_wide_sizes`
- `H` [tests/test_review_visual_corrective_v580.py:169](sources/git/H/tests/test_review_visual_corrective_v580.py) `test_actual_apply_progress_constructor_keeps_bar_visible_and_text_readable`
- `H` [tests/test_review_visual_corrective_v580.py:188](sources/git/H/tests/test_review_visual_corrective_v580.py) `test_unallocated_wrapped_label_does_not_erode_its_own_width`
- `H` [tests/test_review_visual_corrective_v580.py:194](sources/git/H/tests/test_review_visual_corrective_v580.py) `test_owned_idle_callbacks_cancel_on_child_parent_and_canvas_destruction`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## RC-01 Durable save before publication; failure/reopen/stale/UI guards

分類：preserved_original_requirement_not_claimed_historical_finding

Save success precedes advance; failure keeps memory/disk/current; queue/show failure distinguishes saved state and reopens; generation/paths/IDs reject stale; real shortcuts/repeated clicks preserve preview gates and cooldown.

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:60](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> - GUI 在 durable result 後才 publish 正式 DB/queue。write failure 保留 current/memory/disk；post-save queue/show failure 明確區分已保存、封鎖後續操作並可重開恢復。generation、manifest/DB owner identity、output path、review_id 綁定，stale result 不 publish；guard/debounce 保留，preview 失效撤銷快捷確認。

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_async_save.py:129](sources/git/H/tests/test_review_async_save.py) `test_worker_keeps_ui_unlocked_but_guards_all_mutating_actions_and_debounce`
- `H` [tests/test_review_async_save.py:176](sources/git/H/tests/test_review_async_save.py) `test_write_failure_leaves_current_memory_disk_and_reopen_unchanged`
- `H` [tests/test_review_async_save.py:249](sources/git/H/tests/test_review_async_save.py) `test_post_save_queue_failure_is_saved_and_recoverable_after_reopen`
- `H` [tests/test_review_async_save.py:265](sources/git/H/tests/test_review_async_save.py) `test_project_generation_and_review_id_reject_stale_saved_result`
- `H` [tests/test_review_async_save.py:291](sources/git/H/tests/test_review_async_save.py) `test_missing_or_wrong_preview_never_starts_shortcut`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## RC-02 Incremental materializer and staging must remain independently equivalent

分類：preserved_original_requirement_not_claimed_historical_finding

Use D original materializer/staging as independent oracle for new candidate; retain identity/actual snapshot and empty checked IDs for invalid staging; PR28 defer/navigation and PR31 all-position behavior retained.

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:54](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> - Incremental replay 從 rule-applied 原 baseline row 出發，覆寫及 undo 不在已判定 row 上疊加。完整 roster 的唯一 identity 驗證先完成，單筆 replay 後核對 immutable occurrence/review IDs 並使用既有 row validator。不同 evidence chains 的判定、fingerprint、schema、semantics epoch 未遷移。

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md:116](sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md)（SHA256 `7ebc63befe1bcfe111b3d8f438a39e76d32cff05f10aed6cee33e90d58850ff6`）：

> - 另從原baseline Git object編譯原staging summary、projection、source validation及materializer作獨立oracle，absent/valid/overwrite/undo/invalid五情境與新service完全相等；invalid保留error並清空checked IDs，exit0；`review2-a38bdf1-staging-oracle.py/.log`。

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_save_service.py:57](sources/git/H/tests/test_review_save_service.py) `test_incremental_overwrite_undo_match_full_and_preserve_actual`
- `H` [tests/test_review_save_service.py:72](sources/git/H/tests/test_review_save_service.py) `test_expected_survives_unresolved_actual_and_confirmation_replacement`
- `H` [tests/test_review_save_service.py:87](sources/git/H/tests/test_review_save_service.py) `test_reusable_rule_baseline_is_restored_by_undo`
- `H` [tests/test_review_save_service.py:185](sources/git/H/tests/test_review_save_service.py) `test_valid_staging_expected_edit_and_undo_match_full_summary`
- `H` [tests/test_review_save_service.py:192](sources/git/H/tests/test_review_save_service.py) `test_changed_staging_forces_full_and_invalid_staging_never_hides`
- `H` [tests/test_review_save_service.py:207](sources/git/H/tests/test_review_save_service.py) `test_malformed_staging_does_not_lose_saved_expected_or_hide`
- `H` [tests/test_staged_review_navigation_v580.py:365](sources/git/H/tests/test_staged_review_navigation_v580.py) `test_saved_expected_survives_render_failure_without_extra_success_prompt`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## RC-03 Content hashes, runtime and transaction guards remain fail-closed

分類：preserved_original_requirement_not_claimed_historical_finding

Preserve actual/expected independence, schema/identity/epochs, exact truth/quorum, per-PDF fingerprint, project lock/transactions/recovery; verify same size/mtime and during-replay changes and atomic stale-DB refusal.

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md:92](sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md)（SHA256 `7ebc63befe1bcfe111b3d8f438a39e76d32cff05f10aed6cee33e90d58850ff6`）：

> - 每次驗證 session/DB/source PDF/artifact/runtime/rules/project evidence 的內容 hash；mtime/size 不是信任依據。Evidence anchor 與計算 cache 分离，已知 drift 跨 retry/invalidate/replacement/defer/reload 保留。沒有另創首次開啟既有 pipeline 的新 contract。

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md:96](sources/prior/continuation-contract-finalization/adopted-pr-report-round2.md)（SHA256 `7ebc63befe1bcfe111b3d8f438a39e76d32cff05f10aed6cee33e90d58850ff6`）：

> - 未修改 sources、runtime manifest truth、schema、identity、semantics epochs、fingerprint boundary、Global truth 或 JSON document layout。Shared json_save 仍對所有 caller 原子 replace，新增 private temp、fsync 及 optional DB hash guard。

固定 Git object 中的測試定位（只讀；此代理未執行）：

- `H` [tests/test_review_save_service.py:216](sources/git/H/tests/test_review_save_service.py) `test_same_size_mtime_source_and_artifact_mutation_rejected`
- `H` [tests/test_review_save_service.py:230](sources/git/H/tests/test_review_save_service.py) `test_external_sealed_session_and_database_changes_rejected`
- `H` [tests/test_review_save_service.py:324](sources/git/H/tests/test_review_save_service.py) `test_dependency_changed_during_replay_rejected_before_write`
- `H` [tests/test_review_save_service.py:356](sources/git/H/tests/test_review_save_service.py) `test_atomic_db_guard_rejects_concurrent_edit`
- `H` [tests/test_review_save_service.py:365](sources/git/H/tests/test_review_save_service.py) `test_service_reentrancy_and_runtime_failure_rejected`

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## RC-04 Performance retains staging acceleration without omitting cost

分類：preserved_original_requirement_not_claimed_historical_finding

Measure D versus N on same environment/fixture bytes; cold/steady median/P95 heartbeat and memory; keep 500ms debounce and preview cost; investigate clear regression. Historical H samples never count as N measurement, synthetic never counts as real textbook.

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:87](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> 量測支持的範圍：無 staging 穩態 processing median 368.00→303.58 ms、heartbeat gap 354.35→107.60 ms；8 groups 1018.35→436.13 ms、1005.07→105.36 ms。冷 cache 第一筆成本及約 90 ms main-thread preview 均有如實揭露，不宣稱 zero UI stall 或真教材性能。

來源 [sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md:85](sources/prior/continuation-contract-finalization/adopted-pr-report-round1.md)（SHA256 `287ea7dc71f4bdc6a45cbd6a96a5b8ddfd72b22a9399dffcb7828477292b5c65`）：

> 另親查最新原始 `corrective4-db-root-targeted.log`、`corrective4-headless-regression.log`、`corrective4-runtime.log`、`corrective4-compile.log`、兩份 `corrective4-benchmark-*.log` 與 raw JSON。原始 baseline/current 四份 JSON 與 fixed Git bundle 完全相同（僅移除 portable bundle 未含的 repository path），重算全部 median/nearest-rank P95、確認 21 operations/2000 rows/500 initial events/0 或 8 staged groups，500 ms cooldown 與 processing/heartbeat 分開。fixture marker/session/PDF/workbook hashes 相符。

固定 Git object 中的測試定位（只讀；此代理未執行）：

- 量測／證據核對，沒有以單元測試替代。

新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。

## 七份未知報告

完整索引及已知 hash 見 [reconstructed-history.json](reconstructed-history.json)。不能將本矩陣當成這七份報告全部內容。
