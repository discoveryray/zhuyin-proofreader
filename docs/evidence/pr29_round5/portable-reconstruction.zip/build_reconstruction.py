"""Evidence-only reconstruction. Reads exact Git objects and already known files.

No discovery of missing originals, import of product code, or test execution.
Writes only next to this script. Not production implementation or review verdict.
"""
from __future__ import annotations
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
PRIOR = Path(r"C:\Users\discoveryray\.codex\visualizations\2026\09\25\01a0d859-f75a-75d3-a5df-260013f51629\pr29")
REPO = Path(r"C:\Work\zhuyin-proofreader-phase4")
B = "1593e7af65596d320b4427f1b15bb2bc0bdc949c"
H = "a38bdf1c84889c52e7281a0c23c9458e3762afa8"
D = "502414b3b38e004a6d8d9cb693cf21b65148765a"
INITIAL = "e53f44d2da29b46dfe0bd0f2c06af9919808b99f"
KNOWN = [INITIAL, "89e0297bd6e5b9b08d077b2216029fb6224976fc",
         "bb4c136fbc49c706fecfd48d1dacf81b4d97584e",
         "bd6b4789a646f8bed075c256447f54922a5c4f90", H]
NOW = datetime.now(timezone.utc).isoformat()
ROOT_SCOPE = dict(repository="discoveryray/zhuyin-proofreader", task="review-confirm-responsive",
                  pr=29, branch="codex/review-confirm-responsive", baseline=B,
                  continuation_start=H, integration_target=D)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def put(rel, raw):
    dest = OUT / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    return dest

def write_json(rel, data):
    return put(rel, (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))

def git(*args):
    return subprocess.run(["git", "-C", str(REPO), *args], check=True, capture_output=True).stdout

sources = []
source_by_original = {}

def capture_file(path, *, source=None, scope=None, category=None, expected=None):
    raw = path.read_bytes()
    rel = "sources/prior/" + path.relative_to(PRIOR).as_posix()
    put(rel, raw)
    row = dict(source_id="src-" + str(len(sources) + 1).zfill(3),
               original_path=str(path), portable_file=rel, sha256=sha(raw), bytes=len(raw),
               source_ref=source or "previous PR29 evidence artifact", scope=scope,
               category=category, captured_at_utc=NOW)
    if expected:
        row["prior_index_sha256"] = expected
        row["prior_index_matches"] = row["sha256"] == expected
        if not row["prior_index_matches"]:
            raise RuntimeError(f"Changed known source: {path}")
    sources.append(row)
    source_by_original[str(path)] = row
    return row

register_path = PRIOR / "continuation-contract-finalization/evidence-register.json"
register = json.loads(register_path.read_text(encoding="utf-8"))
capture_file(register_path, source="previous evidence audit index", scope=ROOT_SCOPE)
for entry in register["entries"]:
    path = Path(entry["file"])
    if entry.get("sha256") and path.is_absolute() and path.is_file():
        if str(path) not in source_by_original:
            capture_file(path, source=entry["source"], scope=entry.get("scope"),
                         category=entry["category"], expected=entry["sha256"])

for filename in ["baseline-feature.diff", "merge-tree.stdout"] + [
        "commit-" + commit[:7] + suffix for commit in KNOWN for suffix in [".txt", ".diff"]]:
    path = PRIOR / filename
    if str(path) not in source_by_original:
        capture_file(path, scope=dict(baseline=B, head=H), category="known_diff_or_simulation")

raw_chain = git("rev-list", "--reverse", f"{B}..{H}")
observed = raw_chain.decode("ascii").splitlines()
put("sources/git/B-to-H-commit-list.txt", raw_chain)
if observed != KNOWN:
    raise RuntimeError(f"Unexpected historical chain {observed}; coordinator must inspect count")

chain = []
for i, commit in enumerate(KNOWN):
    raw = git("cat-file", "commit", commit)
    rel = f"sources/git/commit-{commit}.raw"
    put(rel, raw)
    text = raw.decode("utf-8")
    headers, message = text.split("\n\n", 1)
    parents = [line.removeprefix("parent ") for line in headers.splitlines() if line.startswith("parent ")]
    expected_parent = B if i == 0 else KNOWN[i-1]
    if parents != [expected_parent]:
        raise RuntimeError(f"Unexpected parent for {commit}: {parents}")
    chain.append(dict(commit=commit, parent=parents[0], kind="initial" if i == 0 else "corrective",
                      correction_number=None if i == 0 else i,
                      commit_subject=message.splitlines()[0], git_object_ref=f"git:commit:{commit}",
                      source_file=rel, sha256=sha(raw), original_ledger_obtained=False,
                      historical_user_authorization=None, historical_actor_session=None,
                      historical_resolution_evidence=None,
                      attribution="Git chain plus persisted PR29 report/index; reconstructed now, not the original ledger"))

test_files = ["tests/test_review_save_service.py", "tests/test_review_async_save.py",
              "tests/test_hotfix_tone_and_followup_v531.py", "tests/test_review_visual_corrective_v580.py",
              "tests/test_manual_actual_gui_batch_v570.py", "tests/test_manual_review_usability_v580.py",
              "tests/test_staged_review_navigation_v580.py"]
test_index = []
for label, commit in [("H", H), ("D", D)]:
    files = git("ls-tree", "-r", "--name-only", commit, "tests").decode("utf-8").splitlines()
    for filename in test_files:
        if filename not in files:
            continue
        raw = git("show", f"{commit}:{filename}")
        rel = f"sources/git/{label}/{filename}"
        put(rel, raw)
        text = raw.decode("utf-8-sig")
        tree = ast.parse(text)
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
                test_index.append(dict(commit=commit, label=label, file=filename, line=node.lineno,
                                       function=node.name, blob=git("rev-parse", f"{commit}:{filename}").decode().strip(),
                                       sha256=sha(raw), portable_file=rel, execution_status="not_run_by_reconstruction"))
write_json("fixed-object-test-index.json", test_index)

adopted = OUT / "user-adopted-contract.md"
authority = dict(source_ref="current thread latest user message: explicit adopted PR29 continuation contract",
                 source_kind="user_message_transcription_from_current_context",
                 message_id=None, message_created_at=None, captured_at_utc=NOW,
                 capture_agent="/root/reconstruct_evidence", role="evidence_reconstruction_only",
                 file="user-adopted-contract.md", sha256=sha(adopted.read_bytes()),
                 encoding="UTF-8; LF; final newline; message text including Markdown escapes preserved",
                 note="Capture time is not claimed to be the user's message creation time. No platform message UUID available.")
write_json("user-adopted-contract.source.json", authority)

def source_for(suffix):
    path = PRIOR / suffix
    return source_by_original[str(path)]

R1 = "continuation-contract-finalization/adopted-pr-report-round1.md"
R2 = "continuation-contract-finalization/adopted-pr-report-round2.md"
BODY = "continuation-contract-finalization/pr29-body-current.md"

def excerpt(suffix, needle):
    s = source_for(suffix)
    lines = (OUT / s["portable_file"]).read_text(encoding="utf-8").splitlines()
    matches = [(i+1, line) for i, line in enumerate(lines) if needle in line]
    if not matches:
        raise RuntimeError(f"Missing quote {suffix}: {needle}")
    i, quote = matches[0]
    return dict(source_id=s["source_id"], source_file=s["portable_file"], line=i,
                sha256=s["sha256"], excerpt=quote,
                quote_role="persisted source text; not a new reviewer conclusion")

missing = []
index_labels = {"e53f44d": "BLOCKED/code", "89e0297": None, "bb4c136": "BLOCKED/code", "bd6b478": "BLOCKED/code"}
for entry in register["entries"]:
    if entry["category"] in {"historical_review_missing", "missing_original"}:
        record = dict(entry)
        record["status_now"] = "missing; not searched again"
        record["new_version_evidence_value"] = "none"
        record["unknown_content"] = True
        record["is_automatic_round5_prerequisite"] = False
        record["policy"] = "Do not fabricate. Append if later obtained; reassess only concrete new current-safety/count/source/problem implications."
        if entry["category"] == "historical_review_missing":
            record["index_quote"] = excerpt(BODY, entry["file"])
        missing.append(record)

preserved_reports = []
for suffix in [R1, R2]:
    s = source_for(suffix)
    content = (OUT / s["portable_file"]).read_text(encoding="utf-8")
    block = re.search(r"```json\s*(\{.*?\})\s*```", content, re.S)
    record = json.loads(block.group(1))
    preserved_reports.append(dict(source=s, historical_record_verbatim=record,
                                  status="persisted full historical report; not current-candidate review",
                                  copied_claims_not_reexecuted=True))

stop_support = [excerpt(R1, "truthful 四筆 ledger"), excerpt(R2, "production gate 最大三輪")]
history = dict(schema="pr29-reconstructed-continuation-history/v1", created_at_utc=NOW,
               reconstruction_actor="/root/reconstruct_evidence", reconstruction_role="evidence only; not implementation reviewer",
               **ROOT_SCOPE, record_kind="RECONSTRUCTED_NOW_NOT_ORIGINAL_LEDGER",
               history_complete=False, historical_gate_input_obtained=False,
               historical_gate_replayed=False, historical_gate_decision_original=None,
               historical_stop=dict(status="STOP reported in persisted H reports", evidence=stop_support,
                                    original_input_state_decision_missing=True,
                                    new_execution_or_retroactive_auth_claim=False),
               initial_and_four_corrective_commits=chain, known_completed_corrective_count=4,
               reliable_evidence_above_four_found=False,
               count_evidence_limit="Only specified existing sources and exact B..H Git history checked; no repeated original-file search.",
               round5=dict(number=5, status="in_progress", from_head=H, to_head=None,
                           first_fixed_candidate=None, commit_list=None,
                           note="Authority adopted; candidate/completion not yet provided to this evidence recorder. No fabricated to_head.",
                           authority_source=authority),
               old_authority_retrospectively_ratified=False,
               known_missing_originals=missing, persisted_historical_full_reports=preserved_reports,
               historical_ci_source_ids=[s["source_id"] for s in sources if s.get("category") == "ci_original_record"],
               new_candidate_verification_status="pending; no old PASS or CI adopted as N result",
               obsolete_previous_draft_preconditions="Superseded only by current adopted user contract; earlier documents preserved as historical planning sources.",
               all_source_index="source-index.json")
write_json("reconstructed-history.json", history)

def tests(*needles):
    return [t for t in test_index if t["label"] == "H" and any(n in t["function"] for n in needles)]

def finding(fid, title, behavior, before, corrective, refs, test_needles, *, kind="code_behavior_reconstructed", limitations=None):
    return dict(id=fid, title=title, kind=kind, source_evidence=refs,
                affected_historical_code_prestate=before, corrective_commit_evidence=corrective,
                original_finding_id=None, original_full_finding_report_obtained=False,
                historical_resolution_status="not reconstructed or asserted",
                attribution_limit=limitations or "Later H report summary plus real code delta identifies behavior, not missing original finding text/ID/reviewer association.",
                required_candidate_behavior=behavior, existing_test_locations=tests(*test_needles),
                candidate_head=None, new_result_status="pending new candidate validation and independent review",
                new_result_evidence_refs=[], resolved_by_this_record=False)

findings = [
    finding("KF-01", "Known actual/rule drift must survive cache invalidation and retry",
            "Keep content-hash evidence anchor independent of disposable computation cache across retry, write failure, defer/revisit/reload/service replacement. Only a fully revalidated new sealed session may reanchor; legitimate durable actual refresh stays possible.",
            INITIAL, KNOWN[1], [excerpt(R1, "既有 evidence anchor"), excerpt("commit-89e0297.diff", "+class ReviewEvidenceAnchor:"), excerpt("commit-89e0297.diff", "+        # Evict computation only.")],
            ["actual_evidence_external", "external_rule_change", "changed_sealed", "failed_first_write", "evidence_rejection", "ordinary_write_failure", "real_actual_transaction"]),
    finding("KF-02", "Destroying save/actual owner must cancel only owned polling callbacks",
            "Owner destroy invalidates pending publication and cancels its own timers; unrelated callbacks remain. A worker may finish durable save, which must reopen correctly without publishing to destroyed owner. Keep success/failure poll disposal.",
            INITIAL, KNOWN[1], [excerpt(R2, "已銷毀 owner"), excerpt("commit-89e0297.diff", "+    def _dispose_async(self, event):"), excerpt("commit-89e0297.diff", "+        # The worker may still finish its durable write.")],
            ["disposed_save_owner", "actual_poll_owner", "actual_success_and_failure", "save_completion_and_failure", "project_generation"]),
    finding("KF-03", "Expected followup regression fixture must model asynchronous publication",
            "Followup explanation belongs to completed published save and retains failed-refresh guard; expected mismatch must not auto-open six-gate confirmation. Keep tests modeling explain_expected callback and do not remove safety assertions.",
            INITIAL, KNOWN[1], [excerpt(R2, "歷史 e53 anchor/poll/followup"), excerpt("commit-89e0297.diff", "+            # Model the asynchronous completion callback:")],
            ["expected_still_mismatch", "saved_mismatch_without", "expected_match_does_not"]),
    finding("KF-04", "Tk Variables/PhotoImages/widget cycles must release on owner thread before worker GC",
            "Preserve explicit master ownership and Destroy cleanup of dialogs/previews/canvas/ActionRows. PR31 integration must add its new preview-ready/visibility timers, callbacks, buttons and peer lifecycle to resource tests. Tests use actual visible-preview then checkbox invocation, retaining weakref/finalizer-thread/worker-GC assertions.",
            KNOWN[1], KNOWN[2], [excerpt("commit-bb4c136.diff", "+class _ReviewDialog(tk.Toplevel):"), excerpt("commit-bb4c136.diff", "+            # Tcl images and callback-held dialog variables"), excerpt(R1, "native tests 實際驗證 destroyed"), excerpt("remote/job-106598564776.log", "Exception ignored in: <function Variable.__del__"), excerpt("remote/job-106598564776.log", "RuntimeError: main thread is not in main loop")],
            ["submitted_expected_variables", "submit_cancel_and_owner", "owner_close_releases", "real_root_and_prior"],
            limitations="Commit bb4c136 changes predecessor 89e0297 Tk lifetime handling. Later report groups 'bb4 Tk ownership/progress fixture'; missing original report prevents exact original finding/session attribution."),
    finding("KF-05", "Held actual-progress UI fixture must initialize production prerequisites",
            "Keep output_dir initialized in UI-only held worker fixture and assert showerror not called, thread start called and actual service not called; bar/text visibility tests must really reach production progress dialog.",
            KNOWN[2], KNOWN[3], [excerpt("commit-bd6b478.diff", '+    app.output_dir = Path("ui-only-held-progress-project")'), excerpt("commit-bd6b478.diff", "+        error.assert_not_called()"), excerpt(R1, "review1-bb4c136-progress-fixture-probe.log")],
            ["actual_apply_progress_constructor"]),
    finding("KF-06", "Non-object durable JSON root must be rejected before normalization/replay/write",
            "Cold/warm/replacement/retry reject falsy and truthy scalar/list roots, malformed and duplicate-key JSON without changing disk bytes, queue, index or last_saved flags. Missing DB and valid empty object preserve initialization; original version normalization/future-schema rejection stay intact.",
            KNOWN[3], H, [excerpt("commit-a38bdf1.diff", "+            if not isinstance(raw_db, dict):"), excerpt(R1, "最新 root validation")],
            ["non_object_db_roots", "corrupt_db_root", "missing_and_empty_object", "object_root_preserves"]),
    finding("KF-07", "Historical CI capability/evidence failures are not code fixes or extra corrective rounds",
            "New N requires its own actual Windows 3.12/3.13 full unittest plus full pytest/GUI/runtime/compile/diff job and log evidence. Runner-not-started attempts have no tested SHA. Preserve historical Tcl setup failure; a successful rerun does not identify its root cause. Investigate new failures before classification.",
            [KNOWN[1], H], None, [excerpt("remote/job-106598564548.log", "_tkinter.TclError: Can"), excerpt(R1, "runner_id 0"), excerpt(R2, "Attempt3 實際執行"), excerpt(R2, "未證實 attempt3")],
            ["actual_apply_progress_constructor", "real_expected_and_actual_form_labels", "owned_idle_callbacks", "unallocated_wrapped"], kind="historical_ci_capability_or_evidence_limit",
            limitations="Historical R2 full report plus preserved raw CI identify attempt failures; no current code defect or exact root cause is inferred."),
]

requirements = [
    dict(id="RC-01", title="Durable save before publication; failure/reopen/stale/UI guards",
         kind="preserved_original_requirement_not_claimed_historical_finding",
         source_evidence=[excerpt(R1, "GUI 在 durable result 後")],
         required_candidate_behavior="Save success precedes advance; failure keeps memory/disk/current; queue/show failure distinguishes saved state and reopens; generation/paths/IDs reject stale; real shortcuts/repeated clicks preserve preview gates and cooldown.",
         existing_test_locations=tests("worker_keeps_ui", "write_failure_leaves", "post_save_queue", "project_generation", "missing_or_wrong_preview")),
    dict(id="RC-02", title="Incremental materializer and staging must remain independently equivalent",
         kind="preserved_original_requirement_not_claimed_historical_finding",
         source_evidence=[excerpt(R1, "Incremental replay"), excerpt(R2, "staging summary、projection")],
         required_candidate_behavior="Use D original materializer/staging as independent oracle for new candidate; retain identity/actual snapshot and empty checked IDs for invalid staging; PR28 defer/navigation and PR31 all-position behavior retained.",
         existing_test_locations=tests("incremental_overwrite", "expected_survives", "reusable_rule", "valid_staging", "changed_staging", "malformed_staging")),
    dict(id="RC-03", title="Content hashes, runtime and transaction guards remain fail-closed",
         kind="preserved_original_requirement_not_claimed_historical_finding",
         source_evidence=[excerpt(R2, "每次驗證 session/DB/source"), excerpt(R2, "Shared json_save")],
         required_candidate_behavior="Preserve actual/expected independence, schema/identity/epochs, exact truth/quorum, per-PDF fingerprint, project lock/transactions/recovery; verify same size/mtime and during-replay changes and atomic stale-DB refusal.",
         existing_test_locations=tests("same_size_mtime", "external_sealed", "dependency_changed", "atomic_db_guard", "service_reentrancy")),
    dict(id="RC-04", title="Performance retains staging acceleration without omitting cost",
         kind="preserved_original_requirement_not_claimed_historical_finding",
         source_evidence=[excerpt(R1, "量測支持的範圍"), excerpt(R1, "500 ms cooldown")],
         required_candidate_behavior="Measure D versus N on same environment/fixture bytes; cold/steady median/P95 heartbeat and memory; keep 500ms debounce and preview cost; investigate clear regression. Historical H samples never count as N measurement, synthetic never counts as real textbook.",
         existing_test_locations=[]),
]
for req in requirements:
    req.update(candidate_head=None, new_result_status="pending", new_result_evidence_refs=[])

finding_doc = dict(schema="pr29-reconstructed-known-findings/v1", created_at_utc=NOW, **ROOT_SCOPE,
                   record_kind="CURRENT_RECONSTRUCTION_NOT_ORIGINAL_FINDING_REPORT",
                   authority_file="user-adopted-contract.md", findings=findings,
                   preserved_requirement_matrix=requirements,
                   missing_full_report_unknowns=[m for m in missing if m["category"] == "historical_review_missing"],
                   unknown_policy="Missing report contents remain unknown. New review is responsible only for new candidate; no fabricated old finding resolution.",
                   no_tests_executed=True, no_review_verdict_issued=True)
write_json("known-findings.json", finding_doc)
write_json("source-index.json", dict(created_at_utc=NOW, **ROOT_SCOPE, sources=sources,
                                      count=len(sources), missing_files_not_included_as_evidence=True,
                                      note="Portable copies preserve source bytes; earlier draft authority/preconditions superseded by user-adopted-contract.md."))

lines = ["# PR29 本次重建的接續紀錄", "", f"建立時間（UTC）：{NOW}",
         "", "本文件是本次重建資料，並非尋回的原 ledger、原授權或 gate decision。沒有正式審查 verdict。",
         "", f"Task：review-confirm-responsive；PR：29；B：`{B}`；H：`{H}`；D：`{D}`。",
         "", "目前已知四輪修正，第五輪 in-progress；to_head/candidate 尚未提供，保持 null。",
         "沒有取得可靠的超過四輪證據。此結論只限既有來源及固定 B→H Git objects，不宣稱歷史原件完整。",
         "", "## 提交鏈", "", "|項目|SHA|Parent|Git subject|", "|---|---|---|---|"]
for row in chain:
    lines.append(f"|{'initial' if row['correction_number'] is None else '第'+str(row['correction_number'])+'輪'}|`{row['commit']}`|`{row['parent']}`|{row['commit_subject']}|")
lines += ["", "## 原 STOP 與新授權", "",
          "歷史四輪 STOP 由 H 兩份保存全文的報告原文支持；原 gate input/state/decision 未取得，未重播、未偽造 decision 或 exit code。",
          "新使用者採納允許重建接續，解除所有歷史原件一律作為開工前置條件；不追認第四輪原授權，不清除未知內容，不創造 merge/release 授權。",
          f"新採納全文：[user-adopted-contract.md](user-adopted-contract.md)；SHA256 `{authority['sha256']}`。",
          "source_ref 是 current thread latest user message；message UUID/原訊息時間未提供，記 null；擷取時間另記。",
          "", "## 缺件保留", "", "|原件或索引名稱|狀態|已知索引 SHA256|", "|---|---|---|"]
for m in missing:
    lines.append(f"|{m['file']}|缺失；未再次搜尋；未知內容不算有效證據|{m.get('expected_sha256_from_pr_index') or '未知'}|")
lines += ["", "## 來源與跨電腦保存", "", "[source-index.json](source-index.json) 列出每個來源的原路徑、可攜副本、SHA256、scope；sources/ 包含既有原件副本。",
          "[reconstructed-history.json](reconstructed-history.json) 保存完整結構與原 H 報告 record；[known-findings.md](known-findings.md) 對照必要新驗證。",
          "現有副本仍需由協調者放入可跨電腦取回的已授權 PR evidence／附件位置；本證據代理沒有 push、上傳或更新 PR。",
          "舊 PASS/CI 只是歷史來源；新候選驗證結果均 pending。本次沒有執行產品測試、未修改程式/tests/docs/workflow、未操作 index/commit。", ""]
put("reconstructed-history.md", "\n".join(lines).encode("utf-8"))

lines = ["# PR29 已知歷史 finding 與新候選驗證矩陣", "", f"建立時間（UTC）：{NOW}",
         "", "下列 KF ID 是本次整理 ID，非遺失原報告的 finding ID。任何『修正 commit』只表示可讀的程式差異，不代替原 finding resolution。",
         "所有新候選結果均 pending；舊 PASS 不沿用。七份缺失報告未知內容保持未知；本文件不發出審查結論。", ""]
for row in findings + requirements:
    lines += [f"## {row['id']} {row['title']}", "", f"分類：{row['kind']}", "",
              row["required_candidate_behavior"], ""]
    if "affected_historical_code_prestate" in row:
        lines += [f"歷史 code prestate：`{row['affected_historical_code_prestate']}`；可讀修正 commit：`{row['corrective_commit_evidence']}`。",
                  f"限制：{row['attribution_limit']}", ""]
    for ref in row["source_evidence"]:
        lines += [f"來源 [{ref['source_file']}:{ref['line']}]({ref['source_file']})（SHA256 `{ref['sha256']}`）：", "", "> " + ref["excerpt"], ""]
    lines += ["固定 Git object 中的測試定位（只讀；此代理未執行）：", ""]
    for loc in row["existing_test_locations"]:
        lines.append(f"- `{loc['label']}` [{loc['file']}:{loc['line']}]({loc['portable_file']}) `{loc['function']}`")
    if not row["existing_test_locations"]:
        lines.append("- 量測／證據核對，沒有以單元測試替代。")
    lines += ["", "新候選 SHA：未固定；處理／測試／審查原始結果：待 append。未宣稱已解除。", ""]
lines += ["## 七份未知報告", "", "完整索引及已知 hash 見 [reconstructed-history.json](reconstructed-history.json)。不能將本矩陣當成這七份報告全部內容。", ""]
put("known-findings.md", "\n".join(lines).encode("utf-8"))

manifest = []
for path in sorted(OUT.rglob("*")):
    if path.is_file() and path.name != "reconstruction-manifest.json":
        raw = path.read_bytes()
        manifest.append(dict(file=path.relative_to(OUT).as_posix(), bytes=len(raw), sha256=sha(raw)))
write_json("reconstruction-manifest.json", dict(created_at_utc=NOW, files=manifest,
                                                no_current_candidate_pass=True))
print(json.dumps(dict(created_at_utc=NOW, source_count=len(sources), file_count=len(manifest),
                      completed_corrections=4, round5_status="in_progress", to_head=None,
                      known_findings=len(findings), preserved_requirements=len(requirements),
                      missing_originals=len(missing), authority_sha256=authority["sha256"],
                      reliable_evidence_above_four=False), ensure_ascii=False, indent=2))
