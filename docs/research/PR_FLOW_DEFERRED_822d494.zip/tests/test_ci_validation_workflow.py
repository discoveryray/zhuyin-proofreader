"""Bounded workflow regressions; execute the real required-check PowerShell body.

No Actions run, GUI, Git write, credential request or functional suite is started.
"""
from pathlib import Path
import os
import json
import tempfile
import re
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
# These ten retained methods verify their exact archived policy; live obligations
# are independently exercised by CurrentValidationWorkflowTests below.
from tests.ci_workflow_history_fixture import WORKFLOW
LIVE_WORKFLOW = (ROOT / '.github/workflows/ci.yml').read_text(encoding='utf-8')


def job(name):
    match = re.search(r'^  ' + re.escape(name) + r':\n(.*?)(?=^  [a-z][a-z_]*:|\Z)', WORKFLOW, re.M | re.S)
    if match is None:
        raise AssertionError('required job missing: ' + name)
    return match.group(1)


def step(section, name):
    match = re.search(r'^      - name: ' + re.escape(name) + r'\n(.*?)(?=^      - name:|\Z)', section, re.M | re.S)
    if match is None:
        raise AssertionError('required step missing: ' + name)
    return match.group(1)


def expression(text, context):
    """Evaluate only the grammar used by the actual workflow expressions."""
    text = text.strip().removeprefix('${{').removesuffix('}}').strip()
    tokens = re.findall(r"'[^']*'|&&|\|\||==|!=|[!(),]|[A-Za-z_][A-Za-z0-9_.-]*|[0-9]+", text)
    if re.sub(r'\s+', '', ''.join(tokens)) != re.sub(r"\s+", '', re.sub(r"'[^']*'", lambda m: m.group().replace(' ', ''), text)):
        raise AssertionError('unsupported workflow expression: ' + text)
    index = 0

    def atom():
        nonlocal index
        token = tokens[index]; index += 1
        if token == '!': return not bool(atom())
        if token == '(':
            value = either()
            if tokens[index] != ')': raise AssertionError('unbalanced expression')
            index += 1; return value
        if token.startswith("'"): return token[1:-1]
        if token.isdecimal(): return int(token)
        if token in ('true', 'false'): return token == 'true'
        if index < len(tokens) and tokens[index] == '(':
            index += 1
            if token == 'fromJSON': value = json.loads(either())
            else: value = {'always': True, 'success': context.get('_success', True),
                           'cancelled': context.get('_cancelled', False),
                           'failure': not context.get('_success', True)}[token]
            if tokens[index] != ')': raise AssertionError('unsupported function arguments')
            index += 1; return value
        value = context
        for component in token.split('.'):
            value = value.get(component, '') if isinstance(value, dict) else ''
        return value

    def compare():
        nonlocal index
        left = atom()
        if index < len(tokens) and tokens[index] in ('==', '!='):
            operator = tokens[index]; index += 1; right = atom()
            equal = left.casefold() == right.casefold() if isinstance(left, str) and isinstance(right, str) else left == right
            return equal if operator == '==' else not equal
        return left

    def both():
        nonlocal index
        left = compare()
        while index < len(tokens) and tokens[index] == '&&':
            index += 1; right = compare(); left = right if left else left
        return left

    def either():
        nonlocal index
        left = both()
        while index < len(tokens) and tokens[index] == '||':
            index += 1; right = both(); left = left if left else right
        return left

    value = either()
    if index != len(tokens): raise AssertionError('unconsumed workflow expression')
    return value


def condition(section, context):
    found = re.search(r'^ +if: (.*)$', section, re.M)
    value = found.group(1) if found else 'success()'
    implicit = not re.search(r'\b(always|cancelled|failure|success)\(', value)
    return bool(expression(value, context)) and (not implicit or context.get('_success', True))


def steps(section):
    return [(m.group(1), m.group(2)) for m in re.finditer(
        r'^      - name: ([^\n]+)\n(.*?)(?=^      - name:|\Z)', section, re.M | re.S)]


def action(section):
    uses = re.search(r'^        uses: (.*)$', section, re.M)
    if uses: return ('uses', uses.group(1))
    run = re.search(r'^        run: (.*)$', section, re.M)
    if not run: raise AssertionError('selected step has no real run/uses')
    if run.group(1) in ('|', '>-'):
        lines = [line[10:] for line in section[run.end():].splitlines() if line.startswith('          ')]
        return ('run', (' ' if run.group(1) == '>-' else '\n').join(lines))
    return ('run', run.group(1))


def current_python_transport_driver(body):
    """Only command transport; interpreter identity is tested with a real venv separately."""
    return '''
$env:CI_PYTHON = Join-Path (Get-Location) 'tmp/ci-venv/Scripts/python.exe'
New-Item -ItemType Directory -Force -Path (Split-Path $env:CI_PYTHON) | Out-Null
New-Item -ItemType File -Force -Path $env:CI_PYTHON | Out-Null
function python { $global:LASTEXITCODE=0 }
Set-Item -LiteralPath "Function:$env:CI_PYTHON" -Value { $args -join ' '; $global:LASTEXITCODE=[int]$env:FIXTURE_EXIT }
''' + body


def event_context(event='pull_request', ref='refs/pull/41/merge', **changes):
    github = dict(event_name=event, ref=ref, head_ref='chore/validation-flow-reduction',
                  repository='discoveryray/zhuyin-proofreader',
                  event=dict(before='1' * 40, pull_request=dict(number=41,
                    head=dict(repo=dict(full_name='discoveryray/zhuyin-proofreader')),
                    base=dict(ref='develop', sha='2' * 40, repo=dict(full_name='discoveryray/zhuyin-proofreader')))))
    for path, value in changes.items():
        target = github; components = path.split('__')
        for component in components[:-1]: target = target[component]
        target[components[-1]] = value
    return dict(github=github, needs=dict(grouped=dict(result='skipped'), short=dict(result='skipped')),
                _success=True, _cancelled=False)


def planned(context):
    return {name: [(label, action(body)) for label, body in steps(job(name)) if condition(body, context)]
            for name in ('grouped', 'short', 'test') if condition(job(name).split('    steps:', 1)[0], context)}


def summary_environment(context, outcomes):
    context = {**context, 'steps': {key: dict(outcome=value) for key, value in outcomes.items()}}
    body = step(job('test'), 'Verify required validation results')
    bindings = body.split('        env:\n', 1)[1].split('        run:', 1)[0]
    environment = {}
    for key, value in re.findall(r'^          ([A-Z_]+): (.*)$', bindings, re.M):
        actual = expression(value, context)
        environment[key] = str(actual).lower() if isinstance(actual, bool) else str(actual)
    return environment


class ValidationWorkflowTests(unittest.TestCase):
    def test_finalize_main_route_is_exact_and_uses_existing_nonwindow_full_path(self):
        release = event_context(head_ref='codex/release-v5.8.0-finalize', event__pull_request__base__ref='main')
        self.assertEqual(set(planned(release)), {'test'})
        selected = dict(planned(release)['test'])
        required = {'Check out repository', 'Set up Python', 'Show Python version', 'Upgrade pip',
                    'Install development dependencies', 'Validate runtime asset integrity', 'Audit test entrypoint coverage',
                    'Run full pytest suite', 'Verify active test execution', 'Compile Python sources',
                    'Check committed whitespace (pull request)', 'Check repository working tree',
                    'Capture main full environment', 'Upload main full evidence', 'Verify required validation results'}
        self.assertEqual(set(selected), required)
        self.assertNotIn('Run full unittest suite', selected)
        self.assertFalse(condition(job('grouped').split('    steps:', 1)[0], release))
        self.assertFalse(condition(job('short').split('    steps:', 1)[0], release))
        matrix = re.search(r'^        python-version: (.*)$', job('test'), re.M).group(1)
        self.assertEqual(expression(matrix, release), ['3.13'])
        version = re.search(r'^          python-version: (.*)$', step(job('test'), 'Set up Python'), re.M).group(1)
        self.assertEqual(expression(version, {**release, 'matrix': {'python-version': '3.13'}}), '3.13.0')
        full_flag = re.search(r'^      FULL_RELEASE_VALIDATION: (.*)$', job('test'), re.M).group(1)
        self.assertTrue(expression(full_flag, release))
        self.assertTrue(expression(full_flag, event_context('push', 'refs/heads/main')))
        self.assertFalse(expression(full_flag, event_context()))
        for name in ('Upgrade pip', 'Install development dependencies', 'Validate runtime asset integrity', 'Run full pytest suite'):
            self.assertIn("if (($env:GITHUB_EVENT_NAME -eq 'push' -and $env:GITHUB_REF -eq 'refs/heads/main') -or $env:FULL_RELEASE_VALIDATION -eq 'true')", selected[name][1])
            self.assertIn('release_ci_evidence.py run --output tmp/main-full/', selected[name][1])
            self.assertIn('if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }', selected[name][1])
        self.assertIn('pip==24.2', selected['Upgrade pip'][1])
        self.assertIn('-r requirements-ci-lock.txt', selected['Install development dependencies'][1])
        self.assertIn('python -m pytest tests/ -q -rs --junitxml=tmp/ci-pytest.xml', selected['Run full pytest suite'][1])
        self.assertEqual(selected['Verify active test execution'], ('run', 'python scripts/test_entrypoint_audit.py verify-active tmp/ci-test-inventory.json --junit tmp/ci-pytest.xml'))
        for name in ('Capture main full environment', 'Upload main full evidence', 'Check repository working tree', 'Verify required validation results'):
            self.assertTrue(condition(step(job('test'), name), {**release, '_success': False}))
        for changes in ({'repository': 'foreign/repo'}, {'event__pull_request__head__repo__full_name': 'foreign/repo'},
                        {'event__pull_request__base__repo__full_name': 'foreign/repo'}, {'event__pull_request__base__ref': 'develop'},
                        {'head_ref': 'codex/release-v5.8.0-prep'}, {'head_ref': 'codex/release-v5.8.0-finalize-extra'}):
            negative = event_context(**({'head_ref': 'codex/release-v5.8.0-finalize', 'event__pull_request__base__ref': 'main'} | changes))
            with self.subTest(changes=changes):
                self.assertEqual(set(planned(negative)), {'grouped', 'test'})
                self.assertFalse(expression(full_flag, negative))
                self.assertNotIn('Run full pytest suite', dict(planned(negative)['test']))
        self.assertFalse(expression(full_flag, event_context('push', 'refs/heads/codex/release-v5.8.0-finalize')))
        self.assertFalse(expression(full_flag, event_context('workflow_dispatch', 'refs/heads/main')))
        for _, (_, command) in selected.items():
            self.assertNotIn('restore-history', command)
            self.assertNotIn('--group gui', command)
            self.assertNotIn('verify-gui', command)

    def test_finalize_summary_requires_every_full_step_success_in_real_powershell(self):
        release = event_context(head_ref='codex/release-v5.8.0-finalize', event__pull_request__base__ref='main')
        ids = ['checkout', 'python', 'version', 'pip', 'dependencies', 'runtime', 'inventory', 'pytest',
               'active', 'compile', 'clean', 'diff_pr', 'main_environment', 'main_evidence']
        success = {key: 'success' for key in ids};success.update(unittest='skipped', diff_push='skipped')
        cases = [(release, success, True)]
        for outcome in ('failure', 'skipped', 'cancelled', ''):
            for key in ids:cases.append((release, {**success, key: outcome}, False))
        for grouped, short in (('success', 'skipped'), ('skipped', 'success'), ('failure', 'skipped'), ('cancelled', 'skipped')):
            context = {**release, 'needs': {'grouped': {'result': grouped}, 'short': {'result': short}}}
            cases.append((context, success, False))
        self.execute_summary(cases)

    def test_required_check_executes_real_failure_sensitive_summary(self):
        pr = event_context(); pr['needs']['grouped']['result'] = 'success'
        develop = event_context('push', 'refs/heads/develop'); develop['needs']['short']['result'] = 'success'
        main = event_context('push', 'refs/heads/main')
        legacy = event_context(event__pull_request__number=29, head_ref='codex/review-confirm-responsive',
                               event__pull_request__base__sha='502414b3b38e004a6d8d9cb693cf21b65148765a')
        ids = ['checkout', 'python', 'version', 'pip', 'dependencies', 'runtime', 'inventory', 'pytest', 'active', 'compile', 'clean', 'diff_push', 'main_environment', 'main_evidence']
        success = {key: 'success' for key in ids}; success.update(unittest='skipped', diff_pr='skipped')
        cases = [(pr, {}, True), (develop, {}, True), (main, success, True),
                 (event_context('workflow_dispatch', 'refs/heads/main'), success, False),
                 (event_context('push', 'refs/heads/other'), success, False)]
        for result in ('failure', 'cancelled', 'skipped', ''):
            for key in ids: cases.append((main, {**success, key: result}, False))
            for context, required in ((pr, 'grouped'), (develop, 'short')):
                changed = {**context, 'needs': {k: dict(v) for k, v in context['needs'].items()}}
                changed['needs'][required]['result'] = result; cases.append((changed, {}, False))
        legacy_success = {**success, 'diff_push': 'skipped', 'diff_pr': 'success', 'unittest': 'success'}
        cases.append((legacy, legacy_success, True))
        for result in ('failure', 'cancelled', 'skipped', ''):
            for key in [name for name in ids if name not in ('diff_push', 'main_environment', 'main_evidence')] + ['unittest', 'diff_pr']:
                cases.append((legacy, {**legacy_success, key: result}, False))
        for context in (pr, develop, main, legacy):
            changed = {**context, 'needs': dict(grouped=dict(result='success'), short=dict(result='success'))}
            cases.append((changed, legacy_success if context is legacy else success, False))
        self.execute_summary(cases)
        self.assertIn('needs: [grouped, short]', job('test'))
        self.assertTrue(condition(job('test').split('    steps:', 1)[0], {**main, '_success': False}))
        self.assertTrue(condition(step(job('test'), 'Verify required validation results'), {**main, '_success': False}))

    def execute_summary(self, cases):
        kind, script = action(step(job('test'), 'Verify required validation results'))
        self.assertEqual(kind, 'run')
        shell = shutil.which('pwsh') or shutil.which('powershell')
        self.assertIsNotNone(shell, 'Windows CI requires PowerShell')
        inputs = [dict(env=summary_environment(context, outcomes), accepted=accepted)
                  for context, outcomes, accepted in cases]
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'cases.json'; path.write_text(json.dumps(inputs), encoding='utf-8')
            driver = """$cases = Get-Content -Raw -LiteralPath $env:SUMMARY_CASES | ConvertFrom-Json
$body = [scriptblock]::Create($env:SUMMARY_BODY)
foreach ($case in $cases) {
  foreach ($property in $case.env.PSObject.Properties) { [Environment]::SetEnvironmentVariable($property.Name, [string]$property.Value, 'Process') }
  try { & $body; $accepted = $true; $errorText = '' } catch { $accepted = $false; $errorText = $_.Exception.Message }
  @{ accepted=$accepted; expected=$case.accepted; env=$case.env; error=$errorText } | ConvertTo-Json -Compress
  if ($accepted -ne $case.accepted) { exit 1 }
}
"""
            result = subprocess.run([shell, '-NoProfile', '-NonInteractive', '-Command', driver],
                                    env={**os.environ, 'SUMMARY_CASES': str(path), 'SUMMARY_BODY': script},
                                    capture_output=True, timeout=60)
        self.assertEqual(result.returncode, 0, (result.stdout + result.stderr).decode('utf-8', errors='replace'))
        records = [json.loads(line) for line in result.stdout.decode('utf-8').splitlines()]
        self.assertEqual(len(records), len(cases))
        self.assertTrue(all(record['accepted'] == record['expected'] for record in records))
        self.assertTrue(all(record['accepted'] or record['error'] for record in records))
        print(result.stdout.decode('utf-8'))  # Preserve actual PowerShell decisions in passing JUnit.

    def test_actual_job_and_step_conditions_route_event_branch_matrix(self):
        pr = event_context(); develop = event_context('push', 'refs/heads/develop'); main = event_context('push', 'refs/heads/main')
        self.assertEqual(set(planned(pr)), {'grouped', 'test'})
        self.assertEqual(set(planned(develop)), {'short', 'test'})
        self.assertEqual(set(planned(main)), {'test'})
        self.assertEqual(set(planned(event_context('workflow_dispatch', 'refs/heads/main'))), {'test'})
        for context in (pr, develop):
            self.assertEqual(set(dict(planned(context)['test'])), {'Check out repository', 'Set up Python', 'Show Python version', 'Verify required validation results'})
        selected = dict(planned(main)['test'])
        required = {'Check out repository', 'Set up Python', 'Show Python version', 'Upgrade pip', 'Install development dependencies',
                    'Validate runtime asset integrity', 'Audit test entrypoint coverage', 'Run full pytest suite', 'Verify active test execution',
                    'Compile Python sources', 'Check committed whitespace (push)', 'Check repository working tree', 'Verify required validation results',
                    'Capture main full environment', 'Upload main full evidence'}
        self.assertEqual(set(selected), required)
        self.assertIn('python -m pytest tests/ -q -rs --junitxml=tmp/ci-pytest.xml', selected['Run full pytest suite'][1])
        self.assertEqual(selected['Verify active test execution'], ('run', 'python scripts/test_entrypoint_audit.py verify-active tmp/ci-test-inventory.json --junit tmp/ci-pytest.xml'))
        self.assertIn('python -m pytest tests/test_runtime_asset_manifest_integrity_v562.py -q', selected['Validate runtime asset integrity'][1])
        self.assertEqual(selected['Check out repository'], ('uses', 'actions/checkout@v7'))
        self.assertEqual(selected['Set up Python'], ('uses', 'actions/setup-python@v7'))
        matrix = re.search(r'^        python-version: (.*)$', job('test'), re.M).group(1)
        self.assertEqual(expression(matrix, main), ['3.13'])
        version = re.search(r'^          python-version: (.*)$', step(job('test'), 'Set up Python'), re.M).group(1)
        self.assertEqual(expression(version, {**main, 'matrix': {'python-version': '3.13'}}), '3.13.0')
        self.assertFalse(condition(step(job('test'), 'Run full unittest suite'), main))
        self.assertFalse(condition(step(job('test'), 'Run full pytest suite'), {**main, '_cancelled': True}))

    def test_exact_legacy_conditions_select_original_validation_steps(self):
        contexts = [event_context(event__pull_request__number=29, head_ref='codex/review-confirm-responsive', event__pull_request__base__sha='502414b3b38e004a6d8d9cb693cf21b65148765a'),
                    event_context(head_ref='codex/simplify-validation', event__pull_request__base__sha='1593e7af65596d320b4427f1b15bb2bc0bdc949c'),
                    event_context('push', 'refs/heads/develop', event__before='502414b3b38e004a6d8d9cb693cf21b65148765a')]
        for context in contexts:
            with self.subTest(event=context['github']):
                self.assertEqual(set(planned(context)), {'test'})
                selected = dict(planned(context)['test'])
                self.assertEqual(selected['Run full unittest suite'], ('run', 'python -m unittest discover -s tests -p "test_*.py"'))
                self.assertTrue('Run full pytest suite' in selected and 'Verify active test execution' in selected)
                matrix = re.search(r'^        python-version: (.*)$', job('test'), re.M).group(1)
                self.assertEqual(expression(matrix, context), ['3.12', '3.13'])
                outcomes = {re.search(r'^        id: (.*)$', body, re.M).group(1): 'success'
                            for label, body in steps(job('test')) if condition(body, context) and re.search(r'^        id: ', body, re.M)}
                self.execute_summary([(context, outcomes, True)])
        base = dict(head_ref='codex/review-confirm-responsive', event__pull_request__number=29,
                    event__pull_request__base__sha='502414b3b38e004a6d8d9cb693cf21b65148765a')
        for changes in ({'event__pull_request__number': 30}, {'event__pull_request__head__repo__full_name': 'other/repo'},
                        {'event__pull_request__base__ref': 'main'}, {'event__pull_request__base__sha': '3' * 40}):
            self.assertEqual(set(planned(event_context(**(base | changes)))), {'grouped', 'test'})

    def test_new_paths_keep_default_capture_and_independent_group_processes(self):
        grouped = job('grouped')
        for section in (grouped, job('short')):
            self.assertEqual(re.findall(r'^      PYTEST_ADDOPTS: (.*)$', section, re.M), ['""'])
            self.assertNotIn('--capture=sys', section)
        self.assertIn('python-version: \'3.13.0\'', grouped)
        body = step(grouped, 'Run core group')
        self.assertIn('--group core --mode validation', body)
        self.assertNotIn('continue-on-error', body)
        self.assertNotIn('!cancelled()', body)
        self.assertLess(grouped.index('Restore validation history'), grouped.index('Run core group'))
        self.assertLess(grouped.index('Run core group'), grouped.index('Aggregate functional coverage'))
        self.assertLess(grouped.index('Aggregate functional coverage'), grouped.index('Verify functional coverage'))
        self.assertIn('verify-coverage tmp/validation-evidence/coverage.json', step(grouped, 'Verify functional coverage'))
        self.assertNotIn('python -m pytest tests/', grouped)
        self.assertNotIn('unittest discover', grouped)

    def test_early_preflight_precedes_core_and_shared_wiring_does_not_open_post_merge_tk(self):
        # All event/ref paths use this one workflow; reject retired launchers globally.
        for forbidden in ('validation_tk_environment.py', 'gui_preflight.py', '--group gui',
                          'verify-gui', 'steps.gui.outcome', 'steps.tk_environment.outcome',
                          'GUI_RESULT', 'TK_ENVIRONMENT_RESULT'):
            self.assertNotIn(forbidden, WORKFLOW)
        self.assertIn('Verify active test execution', job('test'))
        for context in (event_context(), event_context('push', 'refs/heads/develop'),
                        event_context('push', 'refs/heads/main'),
                        event_context('workflow_dispatch', 'refs/heads/main'),
                        event_context(event__pull_request__number=29, head_ref='codex/review-confirm-responsive',
                                      event__pull_request__base__sha='502414b3b38e004a6d8d9cb693cf21b65148765a'),
                        event_context(head_ref='codex/simplify-validation',
                                      event__pull_request__base__sha='1593e7af65596d320b4427f1b15bb2bc0bdc949c')):
            for selected in planned(context).values():
                for label, (_, command) in selected:
                    self.assertNotIn('Tk', label)
                    self.assertNotIn('--group gui', command)
                    self.assertNotIn('verify-gui', command)

    def test_upload_cannot_overwrite_or_export_test_scratch(self):
        for section in (job('grouped'), job('short')):
            upload = step(section, 'Upload validation evidence')
            self.assertIn('if: always()', upload)
            self.assertIn('actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a', upload)
            self.assertIn('if-no-files-found: error', upload)
            self.assertIn('overwrite: false', upload)
            self.assertIn('include-hidden-files: false', upload)
            self.assertIn('!tmp/validation-evidence/**/temp/**', upload)
            self.assertNotIn('path: tmp\n', upload)
            self.assertNotIn('continue-on-error', section)
        self.assertIn('tmp/validation-evidence/**/pr-artifact.zip', job('short'))

    def test_short_path_uses_exact_dependency_lock_and_api_token_name(self):
        for section in (job('grouped'), job('short')):
            self.assertIn('python -m venv tmp/ci-venv', section)
            self.assertIn('-m pip install -r requirements-ci-lock.txt', section)
            self.assertNotIn('pip install --upgrade pip', section)
        short = job('short')
        self.assertIn('GITHUB_TOKEN: ${{ github.token }}', short)
        self.assertIn('validation_evidence.py post-merge', short)
        self.assertNotIn('pytest tests/', short)
        self.assertNotIn('Run GUI group', short)
        self.assertIn('cancel-in-progress: false', WORKFLOW)
        self.assertIn('github.event.pull_request.head.ref || github.ref', WORKFLOW)

    def test_legacy_exception_keeps_exact_original_identity_predicates(self):
        section = job('test')
        expression = re.search(r'^      PYTEST_ADDOPTS: (.*)$', section, re.M).group(1)
        expected = "${{ ((github.event_name == 'pull_request' && github.repository == 'discoveryray/zhuyin-proofreader' && github.event.pull_request.head.repo.full_name == 'discoveryray/zhuyin-proofreader' && github.event.pull_request.number == 29 && github.head_ref == 'codex/review-confirm-responsive' && github.event.pull_request.base.ref == 'develop' && github.event.pull_request.base.sha == '502414b3b38e004a6d8d9cb693cf21b65148765a') || (github.event_name == 'push' && github.repository == 'discoveryray/zhuyin-proofreader' && github.ref == 'refs/heads/develop' && github.event.before == '502414b3b38e004a6d8d9cb693cf21b65148765a')) && '--capture=sys' || '' }}"
        self.assertEqual(expression, expected)
        matrix = re.search(r'^        python-version: (.*)$', section, re.M).group(1)
        self.assertIn("github.head_ref == 'codex/simplify-validation' && github.event.pull_request.base.sha == '1593e7af65596d320b4427f1b15bb2bc0bdc949c'", matrix)
        for name in ('Run full unittest suite', 'Run full pytest suite', 'Verify active test execution'):
            condition = re.search(r'^        if: (.*)$', step(section, name), re.M).group(1)
            for required in ("github.event.pull_request.number == 29", "github.head_ref == 'codex/review-confirm-responsive'", "github.event.before == '502414b3b38e004a6d8d9cb693cf21b65148765a'", "github.head_ref == 'codex/simplify-validation'"):
                self.assertIn(required, condition)
        self.assertNotIn('37000834763', WORKFLOW)
        self.assertNotIn('457707b4c4109c1b10a0da76d8f8a884aca10341', WORKFLOW)



def current_job(name):
    match = re.search(r'^  ' + re.escape(name) + r':\n(.*?)(?=^  [a-z][a-z_]*:|\Z)', LIVE_WORKFLOW, re.M | re.S)
    if match is None: raise AssertionError('current job missing: ' + name)
    return match.group(1)


def current_plan(context):
    predicate = re.search(r'^      FULL_CURRENT_VALIDATION: (.*)$', current_job('test'), re.M).group(1)
    full = expression(predicate, context)
    route = 'full' if full else 'short' if context['github']['event_name'] == 'push' and context['github']['ref'] == 'refs/heads/develop' else ''
    context = {**context, 'env': {'FULL_CURRENT_VALIDATION': str(full).lower()},
               'steps': {'route': {'outputs': {'route': route, 'policy_active': 'false'}}}}
    return {name: [(label, action(body)) for label, body in steps(current_job(name)) if condition(body, context)]
            for name in ('short', 'test') if condition(current_job(name).split('    steps:', 1)[0], context)}


class CurrentValidationWorkflowTests(unittest.TestCase):
    def test_current_four_routes_and_original_legacy_shapes_have_no_live_exemption(self):
        full_names = {'Check out repository', 'Set up Python', 'Show Python version', 'Resolve current validation route', 'Upgrade pip',
            'Install development dependencies', 'Validate runtime asset integrity', 'Audit test entrypoint coverage',
            'Run full pytest suite', 'Verify active test execution', 'Compile Python sources', 'Check repository working tree',
            'Capture main full environment', 'Produce current validation coverage', 'Verify current validation coverage',
            'Upload main full evidence', 'Verify required validation results'}
        contexts = [event_context(), event_context(event__pull_request__base__ref='main'), event_context('push', 'refs/heads/main'),
            event_context(event__pull_request__number=29, head_ref='codex/review-confirm-responsive',event__pull_request__base__sha='502414b3b38e004a6d8d9cb693cf21b65148765a'),
            event_context(head_ref='codex/simplify-validation',event__pull_request__base__sha='1593e7af65596d320b4427f1b15bb2bc0bdc949c')]
        for context in contexts:
            with self.subTest(event=context['github']):
                plan=current_plan(context);self.assertEqual(set(plan),{'test'})
                selected=dict(plan['test']);diff='Check committed whitespace ('+('push' if context['github']['event_name']=='push' else 'pull request')+')'
                self.assertEqual(set(selected),full_names|{diff})
                self.assertNotIn('Run full unittest suite',selected)
                self.assertEqual(re.search(r'^        python-version: (.*)$',current_job('test'),re.M).group(1),"['3.13']")
                self.assertEqual(re.search(r'^          python-version: (.*)$',step(current_job('test'),'Set up Python'),re.M).group(1),"'3.13.0'")
                self.assertEqual(re.search(r'^      PYTEST_ADDOPTS: (.*)$',current_job('test'),re.M).group(1),'""')
                for label in ('Capture main full environment','Upload main full evidence','Check repository working tree','Verify required validation results'):
                    declared={'env':{'FULL_CURRENT_VALIDATION':'true'},'steps':{'route':{'outputs':{'route':'full'}}}}
                    self.assertTrue(condition(step(current_job('test'),label),{**context,**declared,'_success':False}))
                for label in ('Run full pytest suite', 'Verify active test execution', 'Compile Python sources'):
                    self.assertFalse(condition(step(current_job('test'), label), {**context, **declared, '_success': False}), 'failed environment precheck must stop expensive validation')
        for context in (event_context('push','refs/heads/develop'),event_context('push','refs/heads/develop',event__before='502414b3b38e004a6d8d9cb693cf21b65148765a')):
            self.assertEqual(set(current_plan(context)),{'short','test'})
            self.assertEqual(set(dict(current_plan(context)['test'])),{'Check out repository','Set up Python','Show Python version','Resolve current validation route','Verify required validation results'})
        for forbidden in ('restore-history','validation_runner.py','Aggregate functional coverage','Run full unittest suite','--capture=sys','LEGACY_VALIDATION','GROUPED_RESULT','needs.grouped.result','--group gui','verify-gui','gui_preflight','Configure same-installation Tcl/Tk'):
            self.assertNotIn(forbidden,LIVE_WORKFLOW)

    def test_current_full_summary_rejects_every_required_failure_skip_cancel_or_missing(self):
        ids=['checkout','python','version','pip','dependencies','runtime','inventory','pytest','active','compile','clean','main_environment','coverage','coverage_verify','main_evidence']
        cases=[]
        for context in (event_context(),event_context(event__pull_request__base__ref='main'),event_context('push','refs/heads/main')):
            required=ids+['diff_pr' if context['github']['event_name']=='pull_request' else 'diff_push']
            success={key:'success' for key in required};cases.append((context,success,True))
            for outcome in ('failure','skipped','cancelled',''):
                for key in required:cases.append((context,{**success,key:outcome},False))
            for outcome in ('success','failure','cancelled',''):
                cases.append(({**context,'needs':{'short':{'result':outcome}}},success,False))
        self.execute_current_summary(cases)

    def test_current_short_summary_and_unknown_event_cannot_bypass_required_checks(self):
        context=event_context('push','refs/heads/develop');context['needs']['short']['result']='success'
        success={'checkout':'success','python':'success','version':'success'};cases=[(context,success,True)]
        for outcome in ('failure','skipped','cancelled',''):
            cases.append(({**context,'needs':{'short':{'result':outcome}}},success,False))
            for key in success:cases.append((context,{**success,key:outcome},False))
        for other in (event_context('workflow_dispatch','refs/heads/main'),event_context('push','refs/heads/other'),event_context(event__pull_request__base__ref='unknown')):
            cases.append((other,success,False))
        self.execute_current_summary(cases)

    def test_documentation_summary_requires_real_checks_and_rejects_inactive_missing_or_mixed_results(self):
        context=event_context()
        context['steps']={'route':{'outputs':{'route':'docs','policy_active':'true'}},
                          'documentation':{'outputs':{'check_count':'3'}}}
        success={name:'success' for name in ('checkout','python','version','route','documentation','documentation_verify','documentation_evidence')}
        cases=[(context,success,True)]
        for outcome in ('failure','skipped','cancelled',''):
            for key in success:cases.append((context,{**success,key:outcome},False))
        for count in ('','0','1','2','4'):
            changed={**context,'steps':{**context['steps'],'documentation':{'outputs':{'check_count':count}}}}
            cases.append((changed,success,False))
        for active in ('false',''):
            changed={**context,'steps':{**context['steps'],'route':{'outputs':{'route':'docs','policy_active':active}}}}
            cases.append((changed,success,False))
        for key in ('pip','dependencies','main_environment','runtime','inventory','pytest','active','compile','diff_pr','diff_push','clean','coverage','coverage_verify','main_evidence'):
            cases.append((context,{**success,key:'success'},False))
        full={name:'success' for name in ('checkout','python','version','route','pip','dependencies','runtime','inventory','pytest','active','compile','diff_pr','clean','main_environment','coverage','coverage_verify','main_evidence')}
        cases.append((event_context(),{**full,'documentation':'success'},False))
        short=event_context('push','refs/heads/develop');short['needs']['short']['result']='success'
        cases.append((short,{'checkout':'success','python':'success','version':'success','pytest':'success'},False))
        self.execute_current_summary(cases)

    def test_inactive_workflow_has_real_documentation_consumers_without_enabling_an_exemption(self):
        route=step(current_job('test'),'Resolve current validation route')
        self.assertIn('python scripts/pr_flow_ci.py dispatch --output tmp/pr-flow-ci/plan.json',route)
        for name,command in (('Run required documentation checks','documentation-pr --output tmp/pr-flow-ci/docs/checks.json'),
                             ('Verify required documentation checks','verify-pr-documentation tmp/pr-flow-ci/docs/checks.json')):
            body=step(current_job('test'),name)
            self.assertIn("steps.route.outputs.policy_active == 'true'",body)
            self.assertIn("github.event_name == 'pull_request'",body)
            self.assertIn(command,body)
            self.assertIn('if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }',body)
        upload=step(current_job('test'),'Upload documentation evidence')
        self.assertIn("steps.route.outputs.policy_active == 'true'",upload)
        self.assertIn("github.event_name == 'pull_request'",upload)
        self.assertIn('tmp/pr-flow-ci/docs/tested-commit.raw',upload)
        self.assertIn('tmp/pr-flow-ci/transport/originals/',upload)
        for check in ('bytes','local_links','diff'):
            self.assertIn('tmp/pr-flow-ci/docs/'+check+'.stdout.json',upload)
            self.assertIn('tmp/pr-flow-ci/docs/'+check+'.stderr.log',upload)
        for value in ('always()','if-no-files-found: error','overwrite: false','include-hidden-files: false'):
            self.assertIn(value,upload)
        self.assertNotIn('**',upload)
        self.assertNotIn('--ignore',LIVE_WORKFLOW)

    def test_active_full_fallback_summary_requires_both_full_and_neutral_checks(self):
        context=event_context()
        context['steps']={'route':{'outputs':{'route':'full','policy_active':'true'}},
                          'documentation':{'outputs':{'check_count':'3'}}}
        names=('checkout','python','version','route','pip','dependencies','runtime','inventory','pytest','active','compile','diff_pr',
               'clean','main_environment','coverage','coverage_verify','main_evidence','documentation','documentation_verify','documentation_evidence')
        success={name:'success' for name in names}
        cases=[(context,success,True)]
        for outcome in ('failure','skipped','cancelled',''):
            for name in names:cases.append((context,{**success,name:outcome},False))
        for count in ('','0','2','4'):
            changed={**context,'steps':{**context['steps'],'documentation':{'outputs':{'check_count':count}}}}
            cases.append((changed,success,False))
        # Inactive policy preserves the existing PR route and refuses new mixed
        # results. Main push stays full and never claims PR documentation work.
        changed={**context,'steps':{**context['steps'],'route':{'outputs':{'route':'full','policy_active':'false'}}}}
        cases.append((changed,success,False))
        main=event_context('push','refs/heads/main')
        main['steps']={'route':{'outputs':{'route':'full','policy_active':'true'}}}
        main_success={name:value for name,value in success.items() if not name.startswith('documentation') and name!='diff_pr'}
        main_success['diff_push']='success'
        cases.append((main,main_success,True));cases.append((main,{**main_success,'documentation':'success'},False))
        self.execute_current_summary(cases)
        future={**event_context(),'env':{'FULL_CURRENT_VALIDATION':'true'},
                'steps':{'route':{'outputs':{'route':'full','policy_active':'true'}}}}
        for name in ('Run required documentation checks','Verify required documentation checks','Upload documentation evidence'):
            self.assertTrue(condition(step(current_job('test'),name),future))
            inactive={**future,'steps':{'route':{'outputs':{'route':'full','policy_active':'false'}}}}
            self.assertFalse(condition(step(current_job('test'),name),inactive))

    def test_current_commands_lock_capture_scope_and_finite_artifacts_are_explicit(self):
        full=current_job('test');short=current_job('short')
        self.assertEqual(action(step(short,'Verify merge and run short validation')),('run','& $env:CI_PYTHON scripts/validation_evidence.py post-merge --current-only --evidence-root tmp/validation-evidence'))
        self.assertIn('pip==24.2',step(short,'Install locked validation dependencies'))
        self.assertIn('-r requirements-ci-lock.txt',step(short,'Install locked validation dependencies'))
        self.assertEqual(re.search(r'^      PYTEST_ADDOPTS: (.*)$',short,re.M).group(1),'""')
        for first,second in [('Audit test entrypoint coverage','Run full pytest suite'),('Run full pytest suite','Verify active test execution'),('Verify active test execution','Produce current validation coverage'),('Produce current validation coverage','Verify current validation coverage')]:
            self.assertLess(full.index(first),full.index(second))
        for name,expected in [('Audit test entrypoint coverage','collect tmp/ci-test-inventory.json'),('Run full pytest suite','python -m pytest tests/ -q -rs --junitxml=tmp/ci-pytest.xml'),('Verify active test execution','verify-active tmp/ci-test-inventory.json --junit tmp/ci-pytest.xml'),('Compile Python sources',r'python -m compileall -q -x "(^|[\\/])(\.venv|tmp)([\\/]|$)" .')]:
            body=step(full,name);self.assertIn(expected,body);self.assertIn('release_ci_evidence.py run --output tmp/main-full/',body)
            self.assertIn('if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }',body)
        for name in ('Capture main full environment','Produce current validation coverage','Verify current validation coverage'):
            self.assertNotIn('validation_runner.py',step(full,name))
        self.assertIn('environment --current-only',step(full,'Capture main full environment'))
        for section, installer in ((full, 'Upgrade pip'), (short, 'Install locked validation dependencies')):
            body = step(section, installer)
            self.assertIn('$env:CI_PYTHON = (Resolve-Path tmp/ci-venv/Scripts/python.exe).Path', body)
            self.assertIn('"CI_PYTHON=$env:CI_PYTHON"', body)
            self.assertIn('$env:GITHUB_ENV', body)
        self.assertLess(full.index('Capture main full environment'), full.index('Run full pytest suite'))
        self.assertLess(full.index('Install development dependencies'), full.index('Capture main full environment'))
        self.assertIn('verify-environment', step(short, 'Install locked validation dependencies'))
        for name, body in steps(full):
            if name not in ('Show Python version', 'Upgrade pip', 'Resolve current validation route', 'Run required documentation checks', 'Verify required documentation checks') and action(body)[0] == 'run' and name != 'Verify required validation results':
                self.assertIn('& $env:CI_PYTHON', body)
        for section,name in ((full,'Upload main full evidence'),(short,'Upload validation evidence')):
            upload=step(section,name)
            for required in ('always()','if-no-files-found: error','overwrite: false','include-hidden-files: false','actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a'):
                self.assertIn(required,upload)
            self.assertNotIn('path: tmp\n',upload)
        full_upload=step(full,'Upload main full evidence')
        for required in ('tmp/current-coverage.json','tmp/ci-test-inventory.json','tmp/ci-pytest.xml','tmp/main-full/environment.json','tmp/main-full/event.json','tmp/main-full/lock.txt','tmp/main-full/registry.json','tmp/main-full/assets.json'):
            self.assertIn(required,full_upload)
        self.assertNotIn('**',full_upload)
        self.assertIn('tmp/validation-evidence/**/pr-artifact.zip',short)
        self.assertIn('tmp/validation-evidence/**/pr-evidence/main-full/lock.txt',short)
        self.assertNotIn('**/*.txt',short)
        self.assertIn('!tmp/validation-evidence/**/temp/**',short)
        self.assertNotIn('continue-on-error',LIVE_WORKFLOW)
        self.assertIn('cancel-in-progress: false',LIVE_WORKFLOW)

    def test_current_locked_install_and_pytest_propagate_real_powershell_child_exit(self):
        shell=shutil.which('pwsh') or shutil.which('powershell');self.assertIsNotNone(shell)
        for name,expected in [('Upgrade pip','pip==24.2'),('Install development dependencies','requirements-ci-lock.txt'),('Run full pytest suite','-m pytest tests/ -q -rs --junitxml=tmp/ci-pytest.xml')]:
            body=action(step(current_job('test'),name))[1]
            for code in (0,17):
                with tempfile.TemporaryDirectory() as folder:
                    # Command transport only; no package install or functional pytest is started.
                    driver=current_python_transport_driver(body)
                    result=subprocess.run([shell,'-NoProfile','-NonInteractive','-Command',driver],cwd=folder,capture_output=True,env={**os.environ,'FIXTURE_EXIT':str(code),'GITHUB_PATH':str(Path(folder)/'github-path.log'),'GITHUB_ENV':str(Path(folder)/'github-env.log')},timeout=30)
                with self.subTest(name=name,code=code):
                    self.assertEqual(result.returncode,code,result.stderr)
                    self.assertIn(expected,result.stdout.decode())
                    self.assertIn('scripts/release_ci_evidence.py',result.stdout.decode())
                    self.assertNotIn('requirements-ci.txt',result.stdout.decode())
                    self.assertNotIn('--upgrade',result.stdout.decode())

    def execute_current_summary(self,cases):
        body=step(current_job('test'),'Verify required validation results');kind,script=action(body);self.assertEqual(kind,'run')
        bindings=body.split('        env:\n',1)[1].split('        run:',1)[0]
        inputs=[]
        for context,outcomes,accepted in cases:
            full = context['github']['event_name'] == 'pull_request' and context['github']['event']['pull_request']['base']['ref'] in ('develop','main') or context['github']['event_name'] == 'push' and context['github']['ref'] == 'refs/heads/main'
            route = 'full' if full else 'short' if context['github']['event_name'] == 'push' and context['github']['ref'] == 'refs/heads/develop' else ''
            declared={re.search(r'^        id: (.*)$',section,re.M).group(1):{'outcome':'skipped','outputs':{}}
                      for _,section in steps(current_job('test')) if re.search(r'^        id: ',section,re.M)}
            declared['route']={'outcome':'success','outputs':{'route':route,'policy_active':'false'}}
            for key,value in context.get('steps',{}).items():declared[key].update(value)
            for key,value in outcomes.items():declared[key]['outcome']=value
            context={**context,'steps':declared}
            environment={}
            for key,value in re.findall(r'^          ([A-Z_]+): (.*)$',bindings,re.M):
                actual=expression(value,context);environment[key]=str(actual).lower() if isinstance(actual,bool) else str(actual)
            inputs.append(dict(env=environment,accepted=accepted))
        shell=shutil.which('pwsh') or shutil.which('powershell');self.assertIsNotNone(shell)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'cases.json';path.write_text(json.dumps(inputs),encoding='utf-8')
            driver="""$cases = Get-Content -Raw -LiteralPath $env:SUMMARY_CASES | ConvertFrom-Json
$body = [scriptblock]::Create($env:SUMMARY_BODY)
foreach ($case in $cases) {
  foreach ($property in $case.env.PSObject.Properties) { [Environment]::SetEnvironmentVariable($property.Name, [string]$property.Value, 'Process') }
  try { & $body; $accepted = $true; $errorText = '' } catch { $accepted = $false; $errorText = $_.Exception.Message }
  @{ accepted=$accepted; expected=$case.accepted; env=$case.env; error=$errorText } | ConvertTo-Json -Compress
  if ($accepted -ne $case.accepted) { exit 1 }
}
"""
            result=subprocess.run([shell,'-NoProfile','-NonInteractive','-Command',driver],capture_output=True,env={**os.environ,'SUMMARY_CASES':str(path),'SUMMARY_BODY':script},timeout=60)
        self.assertEqual(result.returncode,0,(result.stdout+result.stderr).decode('utf-8',errors='replace'))
        records=[json.loads(line) for line in result.stdout.decode('utf-8').splitlines()]
        self.assertEqual(len(records),len(cases));self.assertTrue(all(record['accepted']==record['expected'] for record in records))
        self.assertTrue(all(record['accepted'] or record['error'] for record in records))
        print(result.stdout.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
